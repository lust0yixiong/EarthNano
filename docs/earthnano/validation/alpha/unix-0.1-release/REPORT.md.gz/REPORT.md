# Explicit Unix Alpha release preparation

HEAD `026053fbae30f3d4af1ba0f9f0909e8424bebd7d` on `feat/alpha-unix-release-scope`, clean; base `a554cde128bad308e0be3c6b4e3239fa53665049`. Five release-script/test files changed. Original branches are preserved in receipt.json.

The original generator still builds version.json, the original Mac helper still merges both architecture feeds, and the original certification aggregator still validates records. No new publisher or release engine was added. No workflow, signing/build configuration, runtime consumer or binary/Compute code changed.

## Explicit interface and consumers

`buildManifest({...options, platforms: 'mac,linux'})` and the generator CLI `--platforms mac,linux` select six original installer keys, both Mac ZIP update artifacts, and exactly the three required Alpha feeds. The existing require-complete and real-byte gates remain mandatory for Alpha. Empty/unknown/duplicate selections fail. Installers, blockmaps, Windows feeds, checksum references and feed references outside scope fail rather than disappearing from output.

The original aggregator accepts the same CLI option, selecting the existing four Unix platform IDs; it retains the original per-platform source SHA, migration certification, actual artifact digest, package-smoke and applicable Windows signature/update checks. Explicit Windows requirements conflict with Unix scope and fail. Extra Windows packages/feeds/platform records/references fail. The aggregate JSON already identifies each included platform; version.json already identifies each download key. No new output schema was introduced.

Omitting scope retains mac,linux,win: seven installer keys and five certification targets. Stable manifests reject narrower scopes. Existing release.yml/nightly.yml/mirror-to-website.yml callers continue using their original full defaults; they were not enabled or edited. Existing update manifest parsing supports the existing optional keys and selectDownload returns null for an omitted platform. The dormant stable S3 publisher remains stable-only and was not converted into an Alpha publisher.

## Commands for a later explicitly authorized EarthNano release entry

These are preparation commands, **not executed here**. The directory must already contain the final verified Unix native bytes, original architecture feeds, real SHA256SUMS.txt and four genuine same-source package certifications. EXPECTED_PACKAGED_SHA must be the source actually used to produce the package evidence, not an unrelated current helper HEAD.

```bash
node scripts/merge-mac-feed.mjs /owned/alpha-assets --channel alpha
VERSION=0.1.0-alpha.1 UPDATE_CHANNEL=alpha \
  ASSET_BASE_URL=https://github.com/lust0yixiong/EarthNano/releases/download/v0.1.0-alpha.1 \
  node scripts/generate-version-manifest.mjs /owned/alpha-assets /owned/alpha-assets/version.json \
  --require-complete --platforms mac,linux
node scripts/ci/release-certification-evidence.mjs aggregate \
  --directory /owned/alpha-assets --output /owned/alpha-assets/RELEASE-CERTIFICATION.json \
  --expected-sha "$EXPECTED_PACKAGED_SHA" --platforms mac,linux
```

A future EarthNano Alpha publication entry must explicitly carry `--platforms mac,linux` through **both** preparation calls and publish only after these complete gates and the genuine native acceptance evidence pass. It must not infer scope from absent Windows files, pass metadata-only/partial flags, reuse the stable publisher as an Alpha publisher, or treat helper tests as installation acceptance. Windows may be explicitly restored with mac,linux,win in 0.2 after its actual acceptance; no such action occurs in this work.

## Validation and limits

Four original/configured suites passed 126/126: alpha-release-feed, generate-version-manifest, release-publication-regressions, release-certification-evidence. Full compiled Node/sandbox/web types, ESLint, Prettier and diff checks exited 0. scope-byteproof.json proves 13 original helper functions, original installer-byte validation, original per-target certification checks, Windows update/signature block and 11 protected files unchanged. Missing/tampered selected files, all three feeds, mismatched source/DB/smoke/digests, scope conflicts and out-of-scope Windows references remain red cases.

Tests hash actual local synthetic fixture bytes and invoke the real preparation CLIs. They do not compile or launch native packages, prove signing/notarization, certify an installation, publish/upload anything or start CI. Local environment: Node v26.0.0 on macOS. Stable publication regression tests exercise a local fake AWS store only. No Windows build, install, CI or diagnostic execution occurred.
