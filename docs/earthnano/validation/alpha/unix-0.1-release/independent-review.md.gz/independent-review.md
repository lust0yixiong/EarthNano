# 独立只读审查：Unix Alpha 发布范围

审查对象为 `feat/alpha-unix-release-scope` 提交 `026053fbae30f3d4af1ba0f9f0909e8424bebd7d`，唯一比较基线 `a554cde128bad308e0be3c6b4e3239fa53665049`。代码通过 `git show` 阅读，未切换工作树、修改仓库、执行测试/构建/CI、Windows installer、发布或模型调用。

## 审查结论

核心 Unix Alpha 选择路径大体保留了原验证门：`mac,linux` 仍要求 6 个安装器键、两份 Mac update ZIP、三份所选 feed 和四个平台认证记录；选定 feed/安装器均保留版本、大小、SHA256/SHA512 检查。认证聚合器仍逐目标检查 source SHA、数据库迁移兼容下限、`packageSmoke === passed` 和 artifact 摘要。测试收据记录 126/126 本地合成 fixture/CLI 测试通过，full compiled types、lint、format、diff 检查退出码均为 0；这些是既有验证记录，不代表原生安装包 smoke 或 CI 已验收。

发现一处范围分类器可被非标准后缀绕过，见下文。其余检查路径没有发现所列标准平台名下的范围缩减绕过。

## 具体问题：Windows 扩展名后缀可逃过平台分类

`/Users/yxmac_mini/Developer/EarthNano-worktrees/alpha-public-sync/scripts/release-artifact-validation.mjs:20-37` 仅把以 `.exe` 或 `.exe.blockmap` 结尾的名称归为 Windows；`validateArtifactName` 在 `:77-96` 只禁止路径分隔符和换行，并允许文件名带 `?`、`#` 等后缀。

因此可构造 `EarthNano-0.1.0-alpha.1-win-x64-setup.exe#tail` 作为实际本地文件及 `alpha-mac.yml` 的 `files[].url`（文件包含 `#tail`，feed 中 size/SHA512 与它一致，另保留两个有效 Mac ZIP）。`buildManifest(... platforms: 'mac,linux', requireComplete: true)` 在 `generate-version-manifest.mjs:145-149` 对这个 URL 调用分类器时不会识别 Windows；后续 `validateUpdateFeed` (`release-artifact-validation.mjs:98-127`) 接受该 release 前缀、文件大小和 SHA512。目录扫描也不会将其分类为 Windows，随后将其作为未知文件警告并跳过 (`generate-version-manifest.mjs:153-173`)。这使一个带 Windows 产品标记的非标准扩展名引用无法触发所要求的“scope 外 Windows 内容拒绝”。这是分类边界缺口，不证明标准 Windows `.exe` 会绕过。

最小收紧方式是在平台分类前对 URL 文件名拒绝 query/fragment 字符，或对分类使用去除 `?`/`#` 后缀的 URL path，同时保持文件必须是受支持的确切 basename。可在 scope 测试增加上述 feed fixture。认证聚合器也复用同一分类器 (`release-certification-evidence.mjs:286-290`)，所以该修正应覆盖它提供的 artifact 名称输入。

## 核对通过的标准路径与边界

- `scripts/release-artifact-validation.mjs:7-16` 默认完整平台集为 `mac,linux,win`；未知、空项、空白项和重复值会失败。`generate-version-manifest.mjs:115-118` 拒绝 stable `latest` 子集；stable 的完整目标集和发布输入约束没有放宽。
- `generate-version-manifest.mjs:135-174,192-214` 对所选 SHA256SUMS 条目及目录产物检查范围、确切原生文件、大小/真实 SHA256；`requireComplete` 对被选平台逐键要求。Mac feed 仍要求两个 Mac ZIP；Linux feed 仍按架构要求 AppImage 和 deb。feed 版本、大小和真实 SHA512 由未改的 `validateUpdateFeed` 执行。
- `scripts/ci/release-certification-evidence.mjs:222-267,269-303,304-369` 对所选平台要求完整记录，保留每目标 source SHA、数据库迁移证据、package smoke、artifact SHA256 和最小 SQLite 兼容版本汇总；只有选 Windows 时才接受相应 Windows 认证记录。显式 Unix scope 与 `--require-signed-windows` / `--require-windows-update` 同用会在 `:228-231` 直接报冲突；选择包含 Windows 时原来的签名和 update drill 检查仍执行。
- 缺少所选认证文件/installer/feed 会失败；已有测试覆盖缺失的四个 Unix 认证目标、缺失或篡改 8 个 Unix 安装器/ZIP、三份 feed 错误和多个 Windows installer/feed/checksum/reference/认证输入。证据目录 `receipt.json` 记录此次测试 126/126 通过；`scope-byteproof.json` 记录多个核心验证函数与稳定发布/更新工作流在 base 上逐字节相同。
- 本提交未修改 `.github/workflows/release.yml`、镜像发布工作流或其调用脚本。base 中 release 聚合调用仍传 `--require-signed-windows`，未显式传 `--platforms`；因此它会保留完整默认并要求 Windows。这个提交提供了工具层显式 Unix scope，尚未使现有发布工作流自动切成 Unix-only。后续调用方若按 Windows 延至 0.2 调整，必须同时向 manifest generator 与 certification aggregator 传 `--platforms mac,linux`，且不能把 Windows 签名/update flags 留在该 Unix-only 调用中。

## 限制

以上是固定 commit 的静态代码审查与既有本地合成测试收据检查。没有用真实签名安装包验证 Windows 延期流程，也没有验证 Unix 原生安装、数据库迁移、feed 发布或 updater smoke；不据此给 Alpha 原生发布通过结论。
