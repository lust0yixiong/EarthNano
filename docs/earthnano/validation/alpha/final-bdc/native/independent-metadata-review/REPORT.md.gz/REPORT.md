# Independent native metadata review

No blocking source/run/certificate/manifest inconsistency found in the supplied four-target evidence. This is a metadata-only review, not a new verifier execution, local package-byte audit, App/GUI test or scientific acceptance. No large package was downloaded or read.

## Fixed new evidence

Retained run.json records run39658781703, attempt1, completed/success, sourcebdc0246383a25990030854f4c2fa100895f29ea6 and tree25d834714406b65aff26b291a790e5c1749f94b1 on ci/earthnano-native. All four original native jobs are completed/success. Source-comparison jobs in this native run are explicitly skipped; this review does not treat them as a new source/science gate pass.

| Target | Native job | Evidence artifact | Archive bytes | Manifest entries |
|---|---:|---:|---:|---:|
| macos-arm64 | 119426007871 | 12373232648 | 531,463 | 11,130 |
| macos-x64 | 119426006612 | 12374391865 | 531,234 | 11,128 |
| linux-x64 | 119426006235 | 12373661690 | 527,560 | 10,941 |
| linux-arm64 | 119426006630 | 12374525176 | 528,245 | 10,939 |

Independently recalculated each local small artifact.zip SHA256/size against both the retained Actions artifacts API digest/size and target receipt. All match. Each archive has exactly four expected files; member bytes equal the existing extracted files. Total small archive bytes2,118,502. The16members are4original release certs,4original DB certs,4original full manifests,4builder-debug files. No files in the old native39629283517 evidence were used as new proof.

## Identity and certificate chain

Every manifest has schema1, exact new source/tree, sourceDirty:false, original UPSTREAMS.json contents (OpenScience9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5; Harness²1cfe254e8d25b15f37048c3730134686abe60335/treeedc756a4d03a2826a248115482084a176e60e751), correct darwin/linux and arm64/x64, productEarthNano/version0.1.0-alpha.1, unsigned-ci and packageArtifactCount2. All13non-dist source-file records per target match exact bdc git bytes/SHA/size, including package/lock/upstreams/licenses/icons/builder configuration. Each manifest lists49Harness files under the new backend/resources/earthnano/harness2 owner location; all49records match fixed source bytes and sizes per target. These are manifest records, not locally read embedded package bytes.

Each original certification has its exact platform, repositorylust0yixiong/EarthNano, refrefs/heads/ci/earthnano-native, sourcebdc, run39658781703 and attempt1. packageSmoke is passed; electronP0/visualRegression/authenticode remain not-applicable. Original job steps record successful original build, package, platform smoke, certificate writer, package upload and source-manifest production. Their numerical order is smoke→certification→package upload→manifest, preserving success-only certification semantics.

Each standalone DB JSON equals the certification's embedded databaseMigration object. All four checks are passed: freshInstall, legacyAdoption, reopen and specialPath. Compatibility floor is original0001_runtime_schema_baseline, checksume29d0483786c3ed2e1c9cd358369b254a54ccf54213931c5ef71a8fd4e161525, SQLite3.46.0. These satisfy the unchanged original writer's schema/checksum/check states. Every downloaded cert, DBcert and builder-debug byte length/SHA matches its own original manifest record; all four DB certs have the same actual SHA050a27daa552a754d3612a22a3718cded6e9dd23be51fdaa31c90c5c81f9bcb1. This certifies the original hosted package-smoke observations; it is not a fresh local migration run.

## Package and runtime metadata boundaries

The certs name exactly8expected distributables: twoMacDMG/twoMacZIP, twoLinuxAppImage and twoarchitectureDEB. Each certified package SHA equals its corresponding original manifest record with positive size. Four alpha feeds have positive manifest records; both Mac targets also record their two real blockmaps. Linux manifests record no blockmaps, which is permitted. The feed contents/URLs/SHA512 and actual package/blockmap byte digests are not present in these downloaded small archives and remain for the original asset preparer's actual-byte checks. The four large package artifacts' existing API identities are retained metadata only.

Electron expected/installed/binary are43.7.5 with status0 for all four manifests, matching the fixed lockfile. Build tooling pin.github/earthnano-node-version is24.22.0; the distinct bundledNode pinbuild/node-runtime.json is22.23.3 with target-specific archiveSHA. All four manifests include nonzeroNode binary/LICENSE/version.json records. Linux x64/ARM64 version.json size/SHA can be reconstructed exactly using the original stageNodeRuntime128–147 JSON shape, that fixed22.23.3 archive identity and manifestNode/LICENSESHA.

The same reconstruction using the post-package MacNode binarySHA does not equal either Macversion.json record. The small archive contains no version.json body, and staging precedes packaging/signing, so this does not establish a product version error or its cause. The source pin and manifest records are available; a direct Macsidecar/binary relation or runtimeversion is not independently established here. Do not describe this review as having read or executed MacNode24.22.0,22.23.3, or any other version. The limitation is explicit in the receipt.

## Scope

No repository, CI, API, model, dependency, native/Keychain or App actions were performed. No original assertions, thresholds or evidence were changed. This review supplies no new GUI/sciencepass and makes no claim about the currently running ARMscience run. A real prepared asset's original aggregate/checksum/feed/manifest/QA gates and actual package-byte validation still must complete. The detailed metadata comparisons and full package/certificate SHA values are in../independent-metadata-receipt.json; the short receipt below binds this report to those facts.
