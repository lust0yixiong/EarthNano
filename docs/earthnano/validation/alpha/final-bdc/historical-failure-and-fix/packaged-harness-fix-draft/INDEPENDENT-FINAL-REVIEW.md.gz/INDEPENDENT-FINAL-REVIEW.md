# Independent final review of packaged Harness resources fix

Result: no actionable P1/P2 found in the reviewed two-file change.

Review base: 4a31b9ae72654cf6ddf7749103abb48b5f85043f, branch fix/alpha-packaged-harness-resources. Working-tree scope observed: one builder destination line plus one new resource-layout test.

The new builder destination backend/resources/earthnano/harness2 matches the existing packaged Node business owner's resourcesPath. The launcher returns Resources/backend/out/backend/index.cjs; the original node-entry derives applicationPath two levels above that entry and appends resources; composition then appends earthnano/harness2. Source directory and filter are unchanged, so this relocates the original method bytes without changing method algorithms, permissions, scopes, scheduler, admission, provider handling or global runtime metadata. The original package smoke identity derives the LICENSE target from the same builder destination.

The regression reads the real builder rule, copies actual vendor files selected by its filter into an owned temporary app layout, derives the actual backend entry through desktopBackendPaths, and calls the original optimizationMethodDigest. It checks the original scheduler/preview Python and schema are included, pins the existing node-entry/composition path conventions, compares the copied method digest with the source digest, and demonstrates that a complete former outer-only layout still cannot be read by the backend owner. It does not mock the digest or claim to execute the Python algorithm or a packaged App. Its finally cleanup is confined to its mkdtemp directory.

Read existing root evidence (not rerun by this reviewer): root-focused-green.json exit0, three suites/21 tests passed; root-original-builder-red.json exit1 and one failure, with ENOENT at the backend-owned Harness path in the original optimizationMethodDigest. This is meaningful old-path red/new-path green evidence for the packaging defect. Original actual39655817932 remains failed; this review does not claim package rebuild, hosted science acceptance or release success. Root's in-progress broader type/lint/format checks are outside this review's result.

Reviewed file SHA256:
- electron-builder.yml: 0ca609580d9749ab129c4123f2ad994b96c2225a7fdbb9298df4af4334a5e6d2
- scripts/packaged-harness-resources.test.ts: f3847f3c6da26bf973480568578395cf96c22d2d6cced540c6472e68f1b03228

Read-only review; no repository edits, test execution, build, dependency installation, CI/API/model, native/Keychain or App operation.
