# Real Compute Core journal reopen evidence

Commit `fcdbed44a106ba107a22137ad5c5a0a592bde6cb` on `test/alpha-compute-journal-reopen`, based on root
`e1461af38` and C test-only teardown fix `1a9d1189de1dfd63eb391da0fd59e9c2e9e6d64a`
(cherry-picked as `2e140f029`). This commit changes only
src/main/earthnano/persistent-compute-candidate.integration.test.ts. Root-approved plan is
in adjacent compute-journal-reopen-plan.md. No production/renderer/source/manager edit.

## Evidence added to the actual existing six cases

The same original native ACP/Node REPL/TCP/SQLite Job/operation/delivery/producer/Version/
Review fixture now uses actual FileExecutionStore, replacing the prior memory store.
Every persisted event/budget assertion reads the real committed execution.json. All six
original case names and original assertions remain, including original input/authority,
stop and source-revocation behavior, binary export/materialization and tamper rejection.
The existing remote submit/harvest transport seam remains injected; no external SSH or
paid model is used. The original SDK talks only to this fixture's localhost SSE provider.

For complete/multi-batch:

1. Require actual original owners.shutdown reaped=true, Core.settle true, and every
   committed record terminal with cleanup confirmed (the original safe-close facts).
2. Snapshot complete original journal and real submit/model/binding/openOwner counters.
   Dispose the old Core and normally close its FileExecutionStore; never steal a lock.
3. Construct a new original owner factory, new FileExecutionStore on the same filename,
   new actual createClaudeCandidateDriver and new ExecutionCore. Submit the identical
   frozen request without increasing/reconfiguring its original one-admission budget.
4. Require original executionId and exact original record/terminal result. Full persisted
   records/events/sequences/budgets equal the prior journal; newDriver.execute is never
   called, binding/openOwner/submit/local-provider request counters do not increase,
   and original native Run inventory is unchanged. New owner export still reconstructs
   the original trajectory; the existing altered-Job-evidence rejection still runs.

For stop-unknown/source-revoked:

- Actual original cancellation/operation remains active and original shutdown returns
  reaped=false. The durable journal contains the exact cancelled/cleanup-unknown record.
- A competing real FileExecutionStore fails with original EEXIST; original journal bytes
  and original PID lock remain unchanged. No second Core or owner is fabricated.
- Same request returns the original handle. A fresh-key request is rejected by the
  original already-exhausted one-admission budget; no second submit/model/driver binding
  or owner construction occurs, and the full journal/budget stays identical.
- This budget-exhausted rejection is explicitly NOT claimed as independent cleanup-fence
  ordering (Core checks budget first). No budget is increased to force a preferred error.
- The existing original operation fulfillment later allows actual owner shutdown to
  confirm physical retirement, but the Core cleanup remains unknown, as before.
  Test teardown does not close an unknown FileStore; after all original drains/runtime
  teardown, removing the isolated temporary fixture tree is only test cleanup.

## Why no unknown takeover/witness was manufactured

Read original FileExecutionStore, reconcilePersistentOptimization, settlement witness
and existing reconciliation/native process fixtures before implementation. This fixture
has no ownerSettled receipt and no verified-dead writer; the original live lock is real.
No PID is forged, no recoverStale/recovery helper is invoked, no snapshot copy/new writer
is used to imply takeover, and no cleanup/witness is synthesized. A NEW Core unknown
recovery requires separate genuine dead-process evidence and remains outside this claim.
This does not prove Harness method/request-index resume or desktop manager resume.

## Results

- `green.json/log`: original six real local native cases **6/6**, zero skipped or global
  errors, process exit 0. complete 5.9s, multi-batch 5.4s, stop-continuation 3.0s,
  prepare-failure 1.5s, stop-unknown 2.6s, source-revoked 2.5s (rounded).
- Full Node + sandbox + Web compiled types PASS (`types-final.log`).
- Focused ESLint PASS (`lint-final.log`); Prettier PASS (`format.log`); diff check PASS.
- `first.json/log`, `types.log` retain an initial test-only binding variable-name collision
  (0 tests collected), corrected to bindCandidate before actual native validation. This
  is not a product regression red result. Final six-case results above are the evidence.
- Full patch `commit.patch`. Worktree clean after commit, no push. Root should pick only
  this new test commit once the original C teardown fix is integrated.

No paid model, external SSH/HPC, Windows, CI, build, new runner/engine/database, shared
package installation or dependency mutation was performed. The proof is local original
persistent Core reuse and unknown-writer exclusion, not remote scheduler acceptance.
