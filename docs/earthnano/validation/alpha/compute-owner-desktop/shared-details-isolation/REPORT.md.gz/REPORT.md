# Restricted Compute shared host knowledge isolation

Commit `7222292c24467c5aaca1e1ab818fa90b96ca86d5` on `fix/alpha-compute-shared-details`, parent
`2a4537962520a7265689c3c41315d5e506a28f99`. Only the original local RPC server and its
existing capabilities test file changed. No service, Job/command algorithm, SSH execution,
root workflow, dependency or paid/native/Windows/CI operation was changed or invoked.

## Confirmed causal boundary

The original `computeCall` details branch routes append/replace directly to
AgentComputeService.appendDetails/replaceDetails. The facade checks enabled host access
but then calls the original ComputeService → HostProfiles → global host repository
updateDetails, without a per-Session knowledge copy or approval. The new trial's original
control token policy limits RPC names but previously allowed both write modes inside
computeCall. Thus a private candidate could alter the shared instructions observed by
ordinary Sessions and sibling candidates on the same host.

The fixture uses an actual TCP NotebookLocalRpcServer, issued host-bound control tokens,
original AgentComputeService, original ComputeService/HostProfiles and a repository
updateDetails spy that enforces original provider/host-id/old-text matching and actually
mutates its shared host row. No fake RPC response or invented parser establishes success.

`red.json/log`: both append and replace fail the expected isolation assertion. The actual
restricted token returns status 200 and invokes repository updateDetails once, changing
the shared document; expected status is 403, zero writes and the original document.
This was recorded before the 3-line production guard was added.

## Minimal correction and retained upstream behavior

Inside the existing authenticated computeCall + sessionBinding.controlPolicy branch,
reject only details append/replace with RpcHttpError(403). Authority comes from the
original server-side token binding, never the JSON interactionPolicy/controlPolicy fields.
Details read (including default mode) is unchanged, as are frozen-host checks, invocation
identity, token retirement and the ordinary handler. No arbitrary shell command filter,
remote sandbox, new approval state, new API or service-level restriction was introduced.

The same fixture proves restricted read succeeds before and after an ordinary Session
writes. Ordinary control tokens without a trusted policy still append/replace through
the same original repository, with author=agent, even when body JSON claims
interactionPolicy=deny-unresolved. Restricted body JSON claims interactive cannot escape.
Existing exact original test titles and judgments were retained.

The actual original details dispatch branch is byte-identical to both parent 2a and fixed
OpenScience `9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5`; SHA256 comparison is saved in
`original-details-branch-comparison.json`. Only the prior restricted-policy admission
seam gained the guard; ordinary original capability remains available.

## Validation

- Red: 2 selected real TCP isolation cases fail (0 pass); old tests were unselected.
- Green: original capabilities suite 22 + original mcpCall suite 40 = **62/62**, 0 skip.
  Raw `green.json/log`.
- Full Node + sandbox + Web compiled types: PASS (`types.log`).
- Focused ESLint: PASS (`lint.log`); Prettier: PASS (`format.log`); diff check PASS.
- Full reviewable patch: `commit.patch`. Worktree clean after commit; no push.

This proves local original host knowledge write isolation and ordinary compatibility.
It does not claim an external SSH machine, scheduler, paid model, remote command
containment or complete Compute candidate acceptance.
