# Desktop original-owner routing implementation

Branch `feat/alpha-compute-routing` starts at root `ff7443853`, with C driver correction
`29d912d57ffe7e0ada40427472fd068477a662ea` cherry-picked as `1f3775c0e`. The prior
`96e2e0395` delivery-availability branch and all Windows branches remain preserved.

## Concrete behavior

The actual IPC application creates stable routing closures before the original background
result owner, supplies its delivery resolver at original construction, supplies control
resolution to the original Notebook bridge, and passes the same host-only registration
through desktop composition → original manager prepared-options spread → persistent run.
The callback is exactly:

```ts
(ports: Pick<PersistentCandidateOwners,
  'resolveCandidateDelivery' | 'resolveControlPolicy' | 'shutdown'>) => (() => void) | void
```

It registers synchronously immediately after the original factory is created, before
later await/dispatch. Only the original factory shutdown's reaped=true releases this
registration. Unknown cleanup retains the same original shutdown callable; original
manager shutdown/update-gate teardown can retry it. The returned reaped outcome is the
AND of the original manager and original owners; no Core cleanup/witness/lock is changed
or unlocked by routing. The original manager hasActiveWork function remains unchanged.

A factory's non-ordinary delivery route identifies its authority. Control resolution then
uses only that same factory's hook. Explicit undefined for its verified live non-Compute
profile preserves the original Python/R behavior; missing hook, retired private identity,
multiple claiming factories, or incomplete history never creates broad ordinary control.
Original private target promises and B's unavailable routing/error semantics are reused.
No model producer/Session fields establish this host authority.

Cold classification reads original config earthnano-desktop histories and original current
data-root earthnano/desktop-runs histories (including orphan data runs without desktop.json).
It uses exact resume.json identity/digest, Core execution.json schema/requestDigest,
project/optimization/budget and immutable candidate prompt→Core identity. Desktop progress
IDs are only conservative consistency hints; they cannot create a live target. All roles'
private identities remain private after completed cleanup. No title/cwd inference, new
persisted registry, Task/Job DB, runtime or automatic submit/resume/reconciliation exists.

The original acquireDataRootWriter lifetime lease covers resolving the current root and
all reads, including failure. No cached pre-move negative survives a root change. Trusted
host roots canonicalize system aliases while children/journal links fail closed. Exact
committed atomic JSON files are read without constructing FileExecutionStore, acquiring,
stealing or deleting its lock. Original manifest validation is reused. Incomplete/corrupt
classification blocks unknown routing/token authority; active actual owner recognition
continues to take precedence. Structural unavailable errors avoid exposing malformed
journal bodies through control resolution.

## Normal setup failure is not corrupt execution evidence

Original source order queues/persists desktop.json before awaiting createOptions. Setup
rejection may never create any execution journal. The old final projection loses that
boundary and cannot safely distinguish this case from missing started evidence.

With root-approved minimal manager extension, the existing private SavedRun JSON initially
persists `executionStarted:false`. It atomically persists true before resolving/creating
execution directories or entering the runner; resume conservatively sets true and never
sets it back. True only means work may have begun, never Core/provider success. Existing
renderer progress shape is unchanged. Present non-boolean values reject; absent legacy
values remain unknown. The cold reader permits only explicit false plus no data run,
empty executions and zero admitted/completed/active budget. Conflicting directories/IDs
or missing truly started history remain fenced. Failed setup therefore does not
permanently block ordinary routes; genuine absent execution authority is not disguised.

## Evidence

- `setup-boundary-red.json/log`: actual original ff744 manager file, with the new real
  manager provider/setup failure fixture, fails because the durable false boundary is
  absent (1 selected fail, 29 existing unselected). Candidate file was backed up externally
  and restored in a Python finally; root/peer/shared files were never changed.
- `green.json/log`: 7 suites **172 pass / 0 fail / 0 skip**. Includes original manager,
  sweep manager, persistent-run, desktop composition, background routing, ACP driver,
  and new cold/router tests. Exact original test names are retained.
- `refined.json/log`: 2 suites **56/56** after tightening setup metadata consistency and
  lease ordering. `router-final.json/log`: **17/17** after structural IO-error normalization.
- Actual original FileExecutionStore + Core fixture creates the private identity and
  lock; cold completed/interrupted reads leave exact journal bytes and lock unchanged.
  Original manager fixture proves a normal setup failure/reopen is classified setup-only,
  while entering the original runner boundary without a journal is denied.
- Cold malformed JSON/digest/identity/projection, missing journal/manifest/unknown legacy
  boundary, links, orphan data history, current-root change and migration acquisition
  failure are covered. Live same-factory undefined, absent hook/duplicate authority,
  retained unknown cleanup retry, and exact original target are covered.
- Original registration forwards unchanged in single and sweep options; actual run calls
  it before Core construction; original factory still shuts down if callback throws;
  release is absent on unknown cleanup and follows original shutdown acknowledgment.
- `types-final.log`: complete Node + sandbox + Web compiled types PASS.
- `lint-final.log`: focused ESLint PASS. `format-final.log`: Prettier PASS. diff check PASS.
- Main optimization module/test registrations updated; original derived-consumer generator
  refreshed the generated graph (large mechanical import-closure change), with no rule,
  exclusion or CI workflow modification. `consumer-check.log`: original check PASS.
  Root must regenerate again after integrating peer source/owner changes.

## Boundaries and limitations

This implements actual caller/control/delivery registration, not the pending C Compute
owner itself or desktop Compute input selection/renderer source UI. Those remain root/C
work. The local fixtures prove original persistence, routing and host policy lifecycles;
they do not claim a live paid model, external SSH/Slurm machine or remote retirement.
Old missing pre-execution boundary evidence remains conservatively unknown; only the new
explicit false boundary proves harmless setup failure. Routing does not repair corruption,
adopt historical results, relax original resume gates or release unknown resource locks.

No Windows, paid, SSH, network model, build, shared dependency installation/mutation, CI
operation, new database or push was performed. Ordinary callbacks and original six method
algorithm sources were not edited. Earlier original-pin callback bytes/AST evidence remains
in the adjacent delivery-availability report; this patch only supplies their optional seam.

## Commit

`2a4537962520a7265689c3c41315d5e506a28f99` (11 files; includes mechanically regenerated consumer index).
Worktree clean after commit. `commit.patch` preserves the full source/reviewable change.
Only this commit needs picking if root already has C29d.

Committed-source full Node + sandbox + Web compiled typecheck also passed, exit 0
(`types-committed.log`); worktree remained clean.
