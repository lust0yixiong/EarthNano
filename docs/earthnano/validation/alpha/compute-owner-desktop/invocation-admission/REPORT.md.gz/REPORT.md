# Restricted Compute invocation admission

Commit `b8e6ca2c173144a99291d56542fe649192f13f9a` on `fix/alpha-compute-invocation-admission`, parent
`7222292c24467c5aaca1e1ab818fa90b96ca86d5`. Only local-rpc-server.ts and its existing
capabilities test file changed. Prior routing/shared-details branches remain intact.

## Source/path finding

Fixed OpenScience `9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5` already captures
initialControlInvocation before reading the HTTP body in NotebookLocalRpcServer.handleRequest.
Its original delegatedWork guard uses that snapshot; its original ordinary Compute route
does not require an active invocation. That ordinary compatibility remains intentional
and unchanged by this patch.

The newer restricted controlPolicy branch had captured a fresh current invocation only
AFTER body parsing, and compared it to itself across the asynchronous source check.
Undefined→undefined therefore passed; so did an initial invocation ending/replaced while
the body was pending. The request would receive the successor's current producerRunId.
Neither RPC dispatch nor original AgentComputeService.submitJob supplies an independent
initial invocation requirement. Original ComputeService/jobWorkflow accepts optional
producerRunId; ComputeJobWorkflowOwner writes lineage-unavailable facts when absent,
rather than making producer presence a universal ordinary Job admission rule. Existing
permission/approval checks may reject other reasons, but do not close this identity gap
when the Session has the required original access/grants.

## Real TCP red/green

The new 2×5 matrix uses the actual original TCP server and original AgentComputeService
with the existing RawComputeService.submitJob fixture spy. Node's actual HTTP request
event is observed after sending an incomplete JSON body; only then is the original
invocation ended/replaced/begun and the final byte sent. No timing sleep or fabricated
transport response is used. The submit spy records actual dispatched producer context.

Timings: none; none→current; replaced; ended; current. Before correction:
- Scoped none, none→current, replaced and ended all dispatch and return 200, where the
  required scoped outcomes are 403/403/409/409 and zero dispatches.
- Scoped current plus all five ordinary-token cases already pass.
- Raw `red.json/log`: **6 pass / 4 fail** among the ten selected cases.

After correction the existing restricted-policy branch requires the original pre-body
snapshot's nonempty toolInvocationId, exact initial binding and current invocation object,
then retains the original post-source-await token/identity/lifetime checks. Missing
original invocation yields 403; replaced/ended yields 409; same active original invocation
still dispatches with its exact original producer and deny-unresolved policy. Forged
body identity/policy does not authorize anything. No new Job, SSH, permission, command or
producer registry rule was introduced; no ordinary-token path was changed.

One existing source-host retirement fixture had made a restricted Compute call without
beginning an invocation. It now supplies a real trusted invocation as a prerequisite,
so it continues to exercise its original source-await race, token 401, source failure
500 and zero-dispatch assertions. Its original test title and judgments are unchanged;
without this fixture correction the new earlier guard would hide the intended race.

## Validation/limits

- Original capabilities suite 32 + original mcpCall suite 40: **72/72**, zero skip
  (`green.json/log`). This includes previous shared-details isolation and all five
  original ordinary timing outcomes, including optional producer and successor behavior.
- Full Node + sandbox + Web compiled types PASS (`types.log`).
- Focused ESLint PASS (`lint.log`), Prettier PASS (`format.log`), git diff check PASS.
- Full reviewable patch: `commit.patch`; worktree clean after commit; no push.

The fixture proves real local RPC admission through the original facade and downstream
submit API context. It does not submit an actual remote Job or claim external scheduler,
SSH, model/paid or complete Compute candidate acceptance. No Windows, CI, build or shared
dependency operation was performed. Shared-details 722 must be integrated before this
commit because it is the explicit parent and uses the same narrow admission seam.
