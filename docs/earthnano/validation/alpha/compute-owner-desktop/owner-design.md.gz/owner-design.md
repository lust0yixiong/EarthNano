# Compute candidate owner — source design for approval

Read-only review at clean `feat/alpha-compute-lifecycle` / `620c096e3abfc0347a4510199efc9367009dad7f`; next implementation base, after root approval, is **`56c083b1b909026b2cfebc386acab3173bcc453b`**, new branch `feat/alpha-compute-owner`. No source changes or runtime execution during this review.

Reviewed original `persistent-candidate-owner.ts`, `claude-candidate-driver.ts`, actual `ipc-application-composition.ts` (the desktop dependency root; there is no `desktop-bootstrap.ts` here), `composition/desktop-optimization.ts`, `composition/compute.ts`, `composition/notebook-bridge.ts`, `composition/background-results.ts`, original Session finalizer/admission/RuntimeSession owner, Job/operation/delivery repositories, original producer capture, scope reader, and resume/reconciliation. Read B `210bdc9726119d74b791fc0e0a5fe7e4db69243b` and root `abd5f1c35a648b7430834ffa1faa8fdb9700099e` without cherry-picking; new base already integrates B/C and exact module ownership.

## Minimal file/API scope

1. **`src/main/earthnano/persistent-candidate-owner.ts`**: primary implementation, optional `PersistentCandidateComputeOptions` in the existing options, existing runtime/Session owner extension, Compute-specific evidence validation and export. Pure text and Python/R branches retain their old shape/bytes and tests.
2. **`src/main/earthnano/candidate-owner-contract.ts`**: optional host-only query capabilities on the existing `PersistentCandidateOwners`, directly using the shared `ResolveCandidateDelivery` and `TrustedControlPolicy` types. No duplicate target/dispatch/policy DTO.
3. **`src/main/earthnano/persistent-compute-candidate.integration.test.ts`**: new meaningful local integration fixtures. Use real original SQLite Job/operation/delivery owners, Node control REPL and pipe, local injected transport, real JSON/PNG producer/Version/Review. Reuse original native/provider fixtures without paid or external connections. Any test-support extraction remains under existing top-level `test/earthnano`, if genuinely necessary.

No edits to shared snapshot/source/method/desktop manager or general Job/Task state machines. Root performs those callers and exact registration. B owns the narrow generic private-unavailable delivery race fix; this owner will use B's settled signal and will not create another failClaim policy.

Proposed existing-owner dependency view, optional only for the Compute profile:

```ts
interface PersistentCandidateComputeOptions {
  hosts: Pick<ComputeHostRepository, 'get'>
  hostAccess: Pick<SessionEnabledComputeHostsOwner, 'withReservation' | 'createSession'>
  jobs: Pick<ComputeJobRepository, 'findByOwner' | 'get'>
  operations: Pick<ComputeJobOperationRepository, 'get'>
  service: Pick<ComputeService, 'cancelJob'>
  deliveries: Pick<BackgroundResultDeliveryRepository,
    'find' | 'findBySource' | 'listContinuation'>
  events: ApplicationEventSource
  cancelApprovals: OriginalComputeHandlers['approvalCancelSession']
}
```

`OriginalComputeHandlers` is a type query of the existing module's real handler, not a copied API. Existing `options.notebook` remains the real shared `NotebookRuntimeService` / `NotebookLocalRpcServer` / MCP entry dependency; Compute requires it and rejects if missing. `operations.get(jobId,'cancel')` already exists. No new repository/read API appears necessary initially.

Return capabilities on the factory:

```ts
resolveCandidateDelivery?: ResolveCandidateDelivery
resolveControlPolicy?(
  binding: Parameters<Parameters<NotebookRuntimeService['setMcpRpcConnectionResolver']>[0]>[0]
): Promise<TrustedControlPolicy | undefined>
```

The resolver can answer ordinary only when known ordinary; an unavailable known private owner must not produce `undefined`/ordinary. Delivery uses the existing three-state route. Control throws a structural unavailable denial for a known private Session instead of issuing the original broad control token. Root's combined resolver needs the original durable Core/Session ownership index for cold private Sessions; this implementation does not infer privacy from a title or create a new persisted flag/registry. Current factory's ephemeral runtime map may be extended with capabilities; it is not result authority.

Desktop already constructs every required original owner: compute admission yields `computeService`, `jobRepository`, `operationRepository`, `hostRepository`, `sessionEnabledComputeHostsOwner`; background results yields its original delivery repository; application root owns the event source; Compute IPC exposes exact per-Session approval cancellation. Root can pass these through its existing caller chain, and route control via B's existing optional `resolveControlPolicy` seam. This implementation does not construct a second Compute service, dispatcher, Job repository, approval broker, or delivery owner.

## Private Session and original control

- Normalize the existing frozen `environment.compute` and optional managed inputs, reject notebook/Compute mixing and non-baseline/candidate roles, and use root `assertFrozenComputeContext` against the original source Session and host rows.
- Use original `hostAccess.withReservation(enabledProviderIds, operation)` around private Session creation only. Inside, persist/project the frozen enabled/selected access with original **`hostAccess.createSession(session, coordinator.saveSession)`**, preserving explicit empty selection and original legacy defaults. Do not emulate this with only `registry.set` or a user-facing `set` that changes selected semantics. No source permission grant is copied.
- Bind the original Node REPL through existing Notebook binding/`executeControl`; never fabricate Python/R runtime identity. B's token policy is exactly the allowed control-method intersection (`computeCall`, `capabilitiesCall`, `hostSdkHelp`), deny-unresolved, and root source validator. Source revoke blocks future work; cancelling already owned Jobs bypasses model-facing visibility checks.
- The actual callbacks currently overwrite `runtimeExecutionId` and `promptAttemptId` on every Turn. Compute must freeze those fields at the initial admitted prompt, retaining the original Core identity, and use current exact Session/Turn/token only as transient cancellation/dispatch capability. Original persisted admissions remain the durable facts.

## Initial Turn release and readResult

The actual original order is `prompt-outcome-finalizer`: terminal commit → interaction release → prompt-ended callback → post-release completion. `readResult` runs after the original prompt promise; it must then flush the original RuntimeSession owner and check the original initial activeRun/promptPreparation lease is absent and the exact terminal admission/outcome exists. **There is no `settleLogicalTurn` API in this tree.** If helpful this is only an owner-local function name; no new runtime API or manual lease release is needed.

For Compute, do not invoke the workspace importer or complete Core immediately. Keep the same driver/Core running, same admission slot and absolute deadline. Subscribe to original events before the first readiness query, then re-read original rows on relevant Job/delivery/Session/Notebook changes with a lost-wakeup-safe versioned Promise. The version is only wake bookkeeping, never Job status. No timer, polling loop of `.status()`, new dispatch queue, or replayed submit.

Read all Jobs by exact Project/private Session; accept only those whose original `producer_run_id` is a real admitted control Run from an owned original Turn/Frame/Branch/segment, and whose provider belongs to the frozen host identity. The dedicated private Session is not permission to claim foreign producers injected into it. Enumerate all Job batches and re-read after every analysis Turn, which may itself create new Jobs. Original `isComputeJobResultFinal` distinguishes terminal status from final harvest; original delivery rows distinguish waiting/pending/dispatching/needs-attention/consumed. A `job_id`, status read, or absent row is never completion. Existing full result observation is the only suppression path; this owner does not mark observed/consumed to avoid analysis.

Only settle the candidate after every actually owned Job's original result and required disposition, every owned native Turn terminal commit, fixed output inventory and original Review commits are available. `needs-attention`, missing producer/delivery, or unconfirmed resource facts fail conservatively or remain unavailable; no synthetic completed facts. Multiple Jobs and zero/multiple managed inputs remain supported; no new scientific requirement is invented beyond task checks/Review.

## Original application continuation

The existing shared `CandidateContinuationTarget` is implemented against the same private runtime. Before dispatch, load every requested delivery from the original repository; require exact Project/Session, unique IDs, original continuation message correlation and owned Job/producer. Construct original attribution and original continuation prompt. Only after those async checks install an ephemeral exact dispatch capability for C's synchronous `ownsApplicationDispatch`; model-added fields do not establish it.

Use original `sendApplicationPrompt` and return independent original admission/result promises. C's application observer validates actual admission, without updating initial mission identity. `isContinuationSaved` reads the original Session graph plus exact original delivery rows; `canStartSessionTurn` tests original runtime idle/lease state and owner liveness. The canStart→send retirement race uses B's generic unavailable signal so pending claims do not consume a failure attempt. No fallback ordinary Send and no new Core/TaskRun are allowed.

## Single cancellation owner and shutdown

Use only C's `cancelOwnedBackground`; never register another Core handler. Close private new-Turn/control admission first, revoke only owned control capabilities and cancel only that private Session's original pending approvals. Cancel the current continuation only after matching its exact persisted active prompt and live token; C's initial branch must not send the initial token to a later Turn.

Read the exact current owned Job set and call original **internal** `ComputeService.cancelJob(jobId,{projectId,sessionId,providerId})`, even after source access revocation. Join the actual prompt cancellation/acknowledgment and original cancellation requests. **Never await `readResult`, its completion Promise, or the same `context.signal` to become aborted inside this hook**: Core awaits the handler before aborting. Remote cancellation that remains active/unknown is not upgraded by return; original reaper/operation rows remain authority. Failures propagate structurally and retained owner handles support later cleanup retry. A lost submit receipt remains submitted/unknown under the original recovery rules, never causes re-submit.

`readResult` independently observes original Job/reaper/harvest changes. Stop wake-up has its own synchronous admission fence; it cannot depend on the later Core abort. Deadline abort can end local waiting with unknown cleanup, retaining original Job rows. The hook cannot wait indefinitely for this same owner result.

Extend existing per-runtime shutdown result to require original local ACP+Notebook retirement **and** every owned Job/operation to be demonstrably stopped/settled. Read finality with the original `isComputeJobResultFinal`; inspect original cancel operation (`active`, `settled/fulfilled`, `superseded`) and actual Job facts, never treat a request acknowledgment, arbitrary `status:'error'`, local process/socket exit or directory deletion as remote retirement. In particular, `superseded` alone is not confirmation. Original stop-evidence validation is reused where applicable; ambiguous dispatch/error/remote outcome keeps `reaped=false`. Retaining a harvested remote work directory for original result/history is not evidence of an active process and must not cause an automatic destructive cleanup operation. No new remote command is invented.

The outer Claude driver overwrites outcome.cleanup with shutdown.reaped; therefore this combined result is essential. Compute-only failed shutdown must remain retryable rather than caching false forever or deleting liveness/policy handles. Only full original resource retirement allows existing ownerSettled attestation.

## Multi-Turn producer, Version/Review and reopen

Original `pinnedTurn` enforces artifact equality with one initial Turn and cannot validate aggregate Compute artifacts. Add a Compute-only branch in the existing owner export verifier: reconstruct the initial plus legitimate original application Turns from exact durable admissions, attributed graph messages, correlated original delivery rows and Job/producer tuples; call the existing scopeSnapshot/artifact readers for each Turn. Require each original per-Turn reference and the complete deduplicated union of exact fixed Versions/checksums to match the Core evidence; never relax the generic single-Turn verifier.

A single Compute evidence Ref may digest these original immutable projections (admissions, exact relevant Job/result/producer evidence, per-Turn refs and final version inventory) in Core's existing Ref[]; it is not another persisted result store or Job model. Exclude mutable UI/notification timestamps from immutable result identity, while preserving actual terminal/harvest/result evidence. Re-export reconstructs and verifies from original owners. Initial identity stays unchanged, trajectory includes each admitted Turn in original order, and multi-Turn usage stays unknown with an explicit limitation unless an existing authoritative aggregate applies. Python/R and plain text trajectory/JSON bytes stay unchanged.

Original producer capture already supports eligible earlier messages/Branches and permits an earlier producer in a later analysis Turn. Do not force every producer.promptMessageId to initial prompt. Verify original completed Node `repl` Run, Frame/Branch/segment/native admission, owned Job `producer_run_id`, original compute output evidence/explicit transfer, Version native capture and read leases. Then use original ReviewRepository and bounded file inventory. Binary descriptors/materialize retain their exact original contract; no fabricated text.

Reopen/export reads only the original Core journal, settlement witness, Session admissions, Job/operation/delivery rows, producer, pinned Versions and Reviews. Completed records revalidate without creating a runtime, running REPL or calling submitJob. Interrupted/unknown records remain fenced by original resume reconciliation; known private delivery stays unavailable until root explicitly restores a validated live owner. This phase will not silently auto-adopt or retry an unknown execution, and does not loosen the existing resume gate. Tests must prove zero model/native/submit calls on reopen and no foreign Job cancellation.

## Planned bounded checks

1. Real local original Node control REPL + SQLite Job/operation/delivery/producer/Version/Review happy path with asynchronous Job result causing an actual private second Turn, initial identity/budget unchanged and initial lease demonstrably released.
2. Multiple Jobs/batches, full-result suppression vs status-only, cancellation during pending approval/initial Turn/continuation/harvest; source revoke still permits exact owned cleanup, another Session Job untouched.
3. Wrong Session/Core/turn/delivery/source/producer/provider and unavailable owner race; arbitrary `trusted` fields rejected; original control minimum methods and missing grant deny without UI wait.
4. Original remote unknown/active cancel operation/local cleanup failure → reaped false, no ownerSettled; later actual owner confirmation retry; no cancellation/readResult abort cycle.
5. Real JSON+PNG fixed Version exports/materialize and multi-Turn evidence tampering red; earlier valid producer allowed, foreign producer or metadata-only evidence rejected; original independent Review remains required.
6. Reopen completed/unknown records does zero submits/model/native starts; old plain/Python/R/binary/delegation fixtures and full compiled types retained. Local transport proof is not external SSH/Slurm acceptance.
