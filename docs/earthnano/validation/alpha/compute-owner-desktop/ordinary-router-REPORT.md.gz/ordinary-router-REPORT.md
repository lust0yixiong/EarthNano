# Non-Compute factory routing correction and fixture drain join

Production scope: unconditional exposure of existing resolveCandidateDelivery / resolveControlPolicy from every persistent candidate factory. No Compute service is added to ordinary, Python or R owner options. The existing knownPrivateSessions/live-runtime classification is reused unchanged. A live non-Compute owner explicitly returns undefined control policy before the desktop cold index; known private delivery remains private-unavailable and never falls back to ordinary. Retired private control still rejects.

Prerequisite integration: existing B router2a4537962520a7265689c3c41315d5e506a28f99 was cherry-picked unchanged locally as fd5418ee745cb19c48227d2b82c1a4867bc9fcc0 solely for actual shared-router testing. Root already holds the source commit; only the two new fix SHAs are to be picked.

Meaningful regression: the added non-compute-routing scenario uses the real original native ordinary candidate owner with no Compute options, actual createDesktopCandidateOwnerRouting and original routeCandidateContinuations. Its injected read-only cold identity set models the already classified private Session; this is not a new Core journal restoration test. It asserts live policy undefined without reading the cold index, all three delivery callbacks fail closed without ordinary invocation, actual ordinary task completion/Artifacts/Review through the unchanged original fixture, and retired control rejection. The parent is separately adding actual persistent Core restoration coverage.

Red/green evidence:
- ordinary-router-red-correct-fixture.json/log: exact same meaningful scenario against ca153 production resolver condition fails candidate preparation before native admission. Targeted selection means the other21 original scenarios were intentionally not selected.
- ordinary-router-green.json/log: same scenario after unconditional exposure passes; process exit0.
- ordinary-router-byteproof.json: TypeScript printer AST equality proves both resolver function initializers are identical before/after. Only the outer Compute condition is removed; original functions/guards are not broadened.
- ordinary-router-shared-only.json/log: original desktop router17 + background composition7 tests,24/24 pass, process exit0.

An additional actual fixture lifecycle error was discovered and is not marked green: ordinary-router-focused-green.json/log and ordinary-router-focused-final.json/log have52 passed assertions but process exit1. The default reporter in the second report identifies one unhandled Prisma initialization code14 from original BackgroundResultDeliveryOwner.drainSession after the Compute fixture removed its DB. JSON reporter success:true alone is insufficient. Both raw failed runs remain preserved.

Independent test-only correction: original dispose():void stops timers but does not join an already executing drain. The newly added Compute fixture now records passthrough original drainSession promises, stops scheduling before teardown, shuts down its original owners, joins those actual promises using Promise.all, and only then disconnects/removes its SQLite database. No sleep, swallowed failure, mocked outcome or production delivery API change. This is committed separately so the root and peer can apply it before persistent recovery fixture work.

Final local verification is in ordinary-router-joined-final.json/log, ordinary-router-joined-types.log, ordinary-router-joined-lint.log and ordinary-router-joined-format.log. Commands retain original Vitest assertions, full compiled types, ESLint, Prettier and diff checks. Environment is macOS arm64/Node26. No Windows/SSH/paid/CI/build/install/push operations occurred.

Final result:52/52, zero skip/global errors, process exit0. Full compiled types/lint/format/diff all exit0. Teardown-only commit 1a9d1189de1dfd63eb391da0fd59e9c2e9e6d64a; resolver production+ordinary integration commit 245fb2840017cc65acd8c1e835a0b06a6e06d296. Worktree clean.
