# Compute candidate owner: local implementation handoff

Scope: existing persistent candidate owner and one new integration test. No new Job/Task state machine, queue, persisted private marker, external transport, Windows activity, dependency build, CI, model API, signing or publication.

## Actual implementation

- `PersistentCandidateOwnersOptions.compute` reuses exact existing host/read repository, Session reservation/create owner, Job/read repository, cancellation operation/read repository, Compute service cancel operation, delivery/read repository, application event source and original approval-cancel handler. Existing Notebook service/RPC is shared.
- Compute preparation validates the frozen source context and original immutable managed Versions. Private Session creation runs within the original host reservation and persists original enabled/selected host access. Immediately after successful persistence, original `context.identity` records initial Session and prompt IDs, before any subsequent preparation can fail. Original native admission supplies its remaining immutable fields. Python/R/plain preparation does not gain this event.
- Exact control binding uses original `getNotebookDataRoot` and original root Frame/Session/Project/no-Attempt checks. No arbitrary cwd or root-prefix admission. Live non-Compute control remains undefined; retired known private control throws; known unavailable private delivery never falls back to ordinary.
- Original result delivery accepts only exact original delivery IDs, continuation message, application attribution, admitted parent Turns and owned Job producers. Application continuations retain initial Core identity/budget and use the original native runtime, admission, finalizer/flush and result promise. Ownership is reconstructed from original persisted Session/admissions/Notebook Runs/Jobs/delivery rows, not another registry.
- Result waiting uses existing event notifications and original facts, with no polling service. Every owned Job must be original-final and its delivery consumed. Actual artifact Version producers must be original completed control Runs; earlier-Turn producers can be published in a later actual Turn. Frozen result reference binds all original Turn references, original Job result tails/harvest/producer facts and the complete Version union.
- Deterministic/integrity/semantic findings use each actual Turn scope and Version ownership. Independent semantic assessment artifacts remain in the full binding. Returned reviewIds retain every original per-Turn Review with a real primary reviewId; old paths keep old return shape.
- Stop retires original approvals, Session capabilities, scoped Notebook control epoch and actual current native continuation, then requests original cancellation only for proven owned Jobs. It never waits for readResult or context.signal. Unknown/active remote cancellation or foreign ownership keeps reaped=false and permits owner shutdown retry; later confirmation never rewrites terminal Core cleanup unknown.

## Exact caller API

```
compute?: {
  hosts: Pick<ComputeHostRepository, 'get'>
  hostAccess: Pick<SessionEnabledComputeHostsOwner, 'withReservation' | 'createSession'>
  jobs: Pick<ComputeJobRepository, 'findByOwner'>
  operations: Pick<ComputeJobOperationRepository, 'get'>
  service: Pick<ComputeService, 'cancelJob'>
  deliveries: Pick<BackgroundResultDeliveryRepository, 'findBySource' | 'listContinuation'>
  events: ApplicationEventSource
  cancelApprovals: ReturnType<typeof createComputeIpcModule>['handlers']['approvalCancelSession']
}
```

Original options.notebook remains required for Compute. Public optional routing signatures were already shared separately in d93cc7c3eb41e5bcd159d5b7a7ec4a5a81a81ae3; root owns caller composition, serializer and module registration. Root snapshot0354708fcb1bd0c5f8b8245ffe5603fcff63af87 is used by the fixture as a real freeze/resolve/materialize store.

## Verification and actual level

- owner-compute-final.json/log: 6/6 pass, zero skip. Real pinned native Claude executable plus local deterministic Messages HTTP fixture; original real Node control REPL/TCP RPC, original SQLite Job/operation/delivery repositories and delivery owner, original producer capture/Version leases/PNG bytes/Reviews. Remote submit and harvest are injected at original Compute service/Job repository boundaries; no SSH or remote dispatcher/reaper execution is claimed.
- Cases: completed result with actual .result() read and cross-Turn earlier producer; two Jobs delivered in separate batches (waits for all original results); Stop during real second-Turn Node execution; successful private persistence then preparation failure with zero model/Job and original Core identity journal; Stop after native initial settlement with active remote cancellation; frozen Host change followed by owned cancellation. Wrong delivery, Project/Frame/Attempt/cwd, stale result bytes, retired routing and reopen-with-zero-resubmit are asserted.
- owner-original-final.json/log: original ordinary owner/native/binary/semantic/driver four suites105/105 pass, zero skip. Includes unchanged original native late Stop assertion protected by independent29d912d57ffe7e0ada40427472fd068477a662ea.
- owner-scientific-compute-final.json/log: original Python/R scientific three cases plus Compute six,9/9 pass, zero skip. Python /opt/homebrew/opt/python@3.12/bin/python3.12; existing Rscript /Users/yxmac_mini/Developer/EarthNano-validation/r-restoration-20261021/storage/runtime/envs/default-r/bin/Rscript (4.4.3). Earlier Python-only run1pass/2skip retained separately in owner-scientific-original; it is not presented as all-runtime validation.
- owner-head-types.log (exact committed ca15397e15f69b60c1b0b8967854776a0d522ab3), with earlier owner-full-types-final.log retained: npm run typecheck:compiled (node/sandbox/web), exit0. owner-lint-final.log and owner-format-final.log: ESLint/Prettier for two files, exit0; git diff --check exit0.

Environment: macOS arm64, local Node v26.0.0/Vitest4.1.11. No Linux/Windows/hosted CI or actual remote Compute acceptance claim. Shared dependency overlay remained read-only; no install/build.

## Preserved failures and source findings

Original failed attempts1–7 remain as raw JSON/log. Attempts1–3: fixture used dynamic import(node:fs/promises), correctly rejected by original code-risk approval; static require(node:fs) with exclusive creation follows existing original fixtures and requires no new permission. Original exact control binding received Notebook dataRoot rather than candidate workspace; owner now reuses original path helper. Attempts4–5: original foreground control result lacks top-level runId, but returns original fileEvidence.activityId with activityKind notebook-run; fixture reads that exact returned producer rather than querying a hidden DB or fabricating an identity. No Notebook API was changed. Attempt7: fixture read nonexistent final.stdout instead of original stdout_tail; corrected fixture to original result field, original rejection retained. Attempt6/8/9/10 green intermediate reports retained.

Root must register the new test in original ownership inventory and atomically attach this owner with actual source/serializer/caller changes. This commit alone does not enable desktop Compute selection.
