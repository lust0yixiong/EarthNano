# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: task-optimization.spec.ts >> starts, polls and stops a typed optimization at 390px
- Location: e2e/browser/task-optimization.spec.ts:4:7

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('status')
Expected substring: "Used 2 of 12 executions"
Error: strict mode violation: getByRole('status') resolved to 2 elements:
    1) <div role="status" class="space-y-2" aria-live="polite">…</div> aka getByText('BaselineUsed 2 of 12')
    2) <div role="status" data-testid="optimization-sweep-preview">…</div> aka getByTestId('optimization-sweep-preview')

Call log:
  - Expect "toContainText" with timeout 20000ms
  - waiting for getByRole('status')

```

# Page snapshot

```yaml
- main [ref=e3]:
  - button "Switch source chat" [ref=e4]
  - group [ref=e5]:
    - generic "Optimize task · Baseline" [ref=e6] [cursor=pointer]
    - generic [ref=e7]:
      - status [ref=e8]:
        - paragraph [ref=e9]: Baseline
        - paragraph [ref=e10]: Used 2 of 12 executions · 1 active
        - generic [ref=e11]:
          - paragraph [ref=e12]: "Domain experiment: research"
          - paragraph [ref=e13]: Sequential
          - generic [ref=e14]:
            - paragraph [ref=e15]: Task 1 · task-0001
            - paragraph [ref=e16]: Awaiting task result
        - button "Stop optimization" [ref=e17]
        - button "Open result chat 1" [ref=e18]
        - button "Open result chat 2" [ref=e19]
      - generic [ref=e20]:
        - generic [ref=e21]:
          - text: Task ID
          - textbox "Task ID" [disabled] [ref=e22]: task-0001
        - generic [ref=e23]:
          - text: Task description
          - textbox "Task description" [disabled] [ref=e24]: Compute a synthetic CSV sum
        - generic [ref=e25]:
          - text: Text input files
          - button "Text input files" [disabled] [ref=e26]
        - paragraph [ref=e27]: Choose up to 32 text files with simple names, at most 64 KB each and 128 KB total.
        - generic [ref=e28]:
          - generic [ref=e29]: values.csv
          - button "Remove" [disabled] [ref=e30]
        - generic [ref=e31]:
          - text: Acceptance criteria (one per line)
          - textbox "Acceptance criteria (one per line)" [disabled] [ref=e32]: The output is valid JSON The sum is correct
        - paragraph [ref=e33]: Write 1–16 independent checks, one per line.
        - generic [ref=e35]:
          - checkbox "Check expected JSON output" [disabled] [ref=e36]
          - text: Check expected JSON output
        - generic [ref=e37]:
          - text: Domain
          - textbox "Domain" [disabled] [ref=e38]: research
      - paragraph [ref=e39]: Each catalog task owns its source, inputs and acceptance checks.
      - generic [ref=e40]:
        - button "Add next task" [disabled] [ref=e41]
        - button "Add Notebook task from another chat" [disabled] [ref=e42]
      - generic [ref=e43]:
        - text: Optimization mode
        - combobox "Optimization mode" [disabled] [ref=e44]:
          - option "Sequential" [selected]
          - option "Parallel"
      - generic [ref=e45]:
        - checkbox "Compare both optimization modes" [disabled] [ref=e46]
        - text: Compare both optimization modes
      - generic [ref=e47]:
        - text: Recursion parameter (k)
        - spinbutton "Recursion parameter (k)" [disabled] [ref=e48]: "1"
      - generic [ref=e49]:
        - text: Concurrent executions
        - spinbutton "Concurrent executions" [disabled] [ref=e50]: "1"
      - generic [ref=e51]:
        - text: Shuffle seed (empty uses original order)
        - textbox "Shuffle seed (empty uses original order)" [disabled] [ref=e52]
      - generic [ref=e53]:
        - text: Domain filter
        - textbox "Domain filter" [disabled] [ref=e54]
      - generic [ref=e55]:
        - text: Task filter
        - textbox "Task filter" [disabled] [ref=e56]
      - paragraph [ref=e57]: Separate filter IDs with commas or spaces; empty includes all.
      - generic [ref=e58]:
        - text: Tasks per domain (empty means all)
        - textbox "Tasks per domain (empty means all)" [disabled] [ref=e59]
      - generic [ref=e60]:
        - text: Domain workers
        - spinbutton "Domain workers" [disabled] [ref=e61]: "1"
      - button "Preview task stream" [disabled] [ref=e62]
      - status [ref=e63]:
        - paragraph [ref=e64]: First attempts require 10 executions including assessments; retries use the same limit.
        - paragraph [ref=e65]: "Planned domain research: task-0001"
      - generic [ref=e66]:
        - text: Execution limit (includes two assessments)
        - spinbutton "Execution limit (includes two assessments)" [disabled] [ref=e67]: "12"
      - button "Start optimization" [disabled] [ref=e69]
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test'
  2   | 
  3   | for (const width of [1100, 390])
  4   |   test(`starts, polls and stops a typed optimization at ${width}px`, async ({ page }) => {
  5   |     await page.setViewportSize({ width, height: 1100 })
  6   |     await page.goto('/task-optimization.html')
  7   |     await page.getByText('Optimize task', { exact: true }).click()
  8   |     await expect(page.getByLabel('Task description', { exact: true })).toHaveValue(
  9   |       'Synthetic task session'
  10  |     )
  11  |     await page.getByLabel('Task description', { exact: true }).fill('Compute a synthetic CSV sum')
  12  |     await page
  13  |       .getByLabel('Acceptance criteria (one per line)', { exact: true })
  14  |       .fill('The output is valid JSON\nThe sum is correct')
  15  |     await page.getByLabel('Execution limit (includes two assessments)', { exact: true }).fill('12')
  16  |     await page.getByLabel('Text input files', { exact: true }).setInputFiles({
  17  |       name: 'values.csv',
  18  |       mimeType: 'text/csv',
  19  |       buffer: Buffer.from('value\n1\n2\n')
  20  |     })
  21  |     await expect(page.getByText('values.csv', { exact: true })).toBeVisible()
  22  |     await page.getByRole('button', { name: 'Preview task stream', exact: true }).click()
  23  |     await page.getByRole('button', { name: 'Start optimization', exact: true }).click()
> 24  |     await expect(page.getByRole('status')).toContainText('Used 2 of 12 executions')
      |                                            ^ Error: expect(locator).toContainText(expected) failed
  25  |     await expect(
  26  |       page.getByText('Used 2 of 12 executions · 1 active', { exact: true })
  27  |     ).toBeInViewport({ ratio: 1 })
  28  |     await expect(
  29  |       page.getByRole('button', { name: 'Stop optimization', exact: true })
  30  |     ).toBeInViewport({ ratio: 1 })
  31  |     await expect
  32  |       .poll(() => page.getByTestId('task-optimization-panel').evaluate((node) => node.scrollTop))
  33  |       .toBe(0)
  34  |     await expect
  35  |       .poll(() =>
  36  |         page.evaluate(
  37  |           () =>
  38  |             (window as unknown as { optimizationFixture: { get: number } }).optimizationFixture.get
  39  |         )
  40  |       )
  41  |       .toBeGreaterThan(0)
  42  |     expect(
  43  |       await page.evaluate(
  44  |         () =>
  45  |           (window as unknown as { optimizationFixture: { sweeps: unknown[] } }).optimizationFixture
  46  |             .sweeps[0]
  47  |       )
  48  |     ).toMatchObject({
  49  |       projectId: 'project',
  50  |       sourceSessionId: 'session',
  51  |       executionLimit: 12,
  52  |       catalog: [
  53  |         {
  54  |           taskId: 'task-0001',
  55  |           domain: 'research',
  56  |           sourceSessionId: 'session',
  57  |           source: {
  58  |             kind: 'text',
  59  |             prompt: 'Compute a synthetic CSV sum',
  60  |             files: [{ path: 'values.csv', content: 'value\n1\n2\n' }]
  61  |           }
  62  |         }
  63  |       ]
  64  |     })
  65  |     const polled = await page.evaluate(
  66  |       () => (window as unknown as { optimizationFixture: { get: number } }).optimizationFixture.get
  67  |     )
  68  |     const scrolled = await page.getByTestId('task-optimization-panel').evaluate((node) => {
  69  |       node.scrollTop = 80
  70  |       return node.scrollTop
  71  |     })
  72  |     expect(scrolled).toBeGreaterThan(0)
  73  |     await expect
  74  |       .poll(() =>
  75  |         page.evaluate(
  76  |           () =>
  77  |             (window as unknown as { optimizationFixture: { get: number } }).optimizationFixture.get
  78  |         )
  79  |       )
  80  |       .toBeGreaterThan(polled)
  81  |     expect(
  82  |       await page.getByTestId('task-optimization-panel').evaluate((node) => node.scrollTop)
  83  |     ).toBe(scrolled)
  84  |     await page.getByRole('button', { name: 'Stop optimization', exact: true }).click()
  85  |     await expect(page.getByRole('status')).toContainText('Cancelled')
  86  |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  87  |   })
  88  | test('shows independent assessments, opens owner-backed views and resets on Session switch', async ({
  89  |   page
  90  | }) => {
  91  |   await page.goto('/task-optimization.html?complete')
  92  |   await page.getByText('Optimize task', { exact: true }).click()
  93  |   await page
  94  |     .getByLabel('Acceptance criteria (one per line)', { exact: true })
  95  |     .fill('The output is valid')
  96  |   await page.getByRole('button', { name: 'Preview task stream', exact: true }).click()
  97  |   await page.getByRole('button', { name: 'Start optimization', exact: true }).click()
  98  |   await expect(page.getByText('Baseline assessment', { exact: true })).toBeVisible()
  99  |   await expect(page.getByText('Candidate assessment', { exact: true })).toBeVisible()
  100 |   await page.getByRole('button', { name: 'Open assessment', exact: true }).last().click()
  101 |   await page.getByRole('button', { name: 'Open result chat 2', exact: true }).click()
  102 |   expect(
  103 |     await page.evaluate(
  104 |       () =>
  105 |         (window as unknown as { optimizationFixture: { reviews: string[]; sessions: string[] } })
  106 |           .optimizationFixture
  107 |     )
  108 |   ).toMatchObject({ reviews: ['review-candidate'], sessions: ['candidate-session'] })
  109 |   await page.getByRole('button', { name: 'Switch source chat', exact: true }).click()
  110 |   await page.getByText('Optimize task', { exact: true }).click()
  111 |   await expect(page.getByLabel('Task description', { exact: true })).toHaveValue(
  112 |     'Synthetic task next'
  113 |   )
  114 |   await expect(page.getByText('Baseline assessment', { exact: true })).toHaveCount(0)
  115 | })
  116 | test('keeps errors credential-free and hides unsupported web entry', async ({ page }) => {
  117 |   await page.goto('/task-optimization.html?error')
  118 |   await page.getByText('Optimize task', { exact: true }).click()
  119 |   await page
  120 |     .getByLabel('Acceptance criteria (one per line)', { exact: true })
  121 |     .fill('The output is valid')
  122 |   await page.getByRole('button', { name: 'Preview task stream', exact: true }).click()
  123 |   await page.getByRole('button', { name: 'Start optimization', exact: true }).click()
  124 |   await expect(page.getByRole('alert')).toContainText('Check the selected model')
```