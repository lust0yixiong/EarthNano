# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: task-optimization.spec.ts >> keeps domain admission scoped to each task and submits private JSON expectations
- Location: e2e/browser/task-optimization.spec.ts:161:5

# Error details

```
Error: expect(locator).not.toContainText(expected) failed

Locator: getByRole('status')
Expected substring: not "output-check-failed"
Error: strict mode violation: getByRole('status') resolved to 2 elements:
    1) <div role="status" class="space-y-2" aria-live="polite">…</div> aka getByText('CompletedUsed 9 of 20')
    2) <div role="status" data-testid="optimization-sweep-preview">…</div> aka getByTestId('optimization-sweep-preview')

Call log:
  - Expect "not toContainText" with timeout 20000ms
  - waiting for getByRole('status')

```

# Page snapshot

```yaml
- main [ref=e3]:
  - button "Switch source chat" [ref=e4]
  - group [ref=e5]:
    - generic "Optimize task · Completed" [ref=e6] [cursor=pointer]
    - generic [ref=e7]:
      - status [ref=e8]:
        - paragraph [ref=e9]: Completed
        - paragraph [ref=e10]: Used 9 of 20 executions · 0 active
        - generic [ref=e11]:
          - paragraph [ref=e12]: "Domain experiment: csv-count"
          - paragraph [ref=e13]: Sequential
          - generic [ref=e14]:
            - paragraph [ref=e15]: Task 1 · task-0001
            - generic [ref=e16]:
              - paragraph [ref=e17]: Output checks passed
              - paragraph [ref=e18]: Eligible for further configuration validation
            - paragraph [ref=e19]: Results compare independent assessments; improvement is not guaranteed.
            - generic [ref=e20]:
              - paragraph [ref=e21]: Baseline assessment
              - paragraph [ref=e22]: "Score: 80 · Passed"
              - paragraph [ref=e23]: Baseline satisfies the independent criteria.
              - button "Open assessment" [ref=e24]
            - generic [ref=e25]:
              - paragraph [ref=e26]: Candidate assessment
              - paragraph [ref=e27]: "Score: 80 · Passed"
              - paragraph [ref=e28]: Candidate satisfies the same independent criteria.
              - button "Open assessment" [ref=e29]
            - paragraph [ref=e30]: Selected c2 from 1 candidates
            - paragraph [ref=e31]: Trivial selection
            - paragraph [ref=e32]: Selected from the fixed candidate outputs.
          - generic [ref=e33]:
            - paragraph [ref=e34]: Task 2 · task-0002
            - generic [ref=e35]:
              - paragraph [ref=e36]: Output checks failed
              - paragraph [ref=e37]: Configuration admission blocked
              - paragraph [ref=e38]: "Output check result.json: Expected value did not match"
              - paragraph [ref=e39]: An expected output check failed.
            - paragraph [ref=e40]: Results compare independent assessments; improvement is not guaranteed.
            - generic [ref=e41]:
              - paragraph [ref=e42]: Baseline assessment
              - paragraph [ref=e43]: "Score: 80 · Passed"
              - paragraph [ref=e44]: Baseline satisfies the independent criteria.
              - button "Open assessment" [ref=e45]
            - generic [ref=e46]:
              - paragraph [ref=e47]: Candidate assessment
              - paragraph [ref=e48]: "Score: 80 · Passed"
              - paragraph [ref=e49]: Candidate satisfies the same independent criteria.
              - button "Open assessment" [ref=e50]
            - paragraph [ref=e51]: Selected c2 from 1 candidates
            - paragraph [ref=e52]: Trivial selection
            - paragraph [ref=e53]: Selected from the fixed candidate outputs.
        - button "Open result chat 1" [ref=e54]
        - button "Open result chat 2" [ref=e55]
      - generic [ref=e56]:
        - generic [ref=e57]:
          - text: Task ID
          - textbox "Task ID" [ref=e58]: task-0001
        - generic [ref=e59]:
          - text: Task description
          - textbox "Task description" [ref=e60]: Synthetic task session
        - generic [ref=e61]:
          - text: Text input files
          - button "Text input files" [ref=e62]
        - paragraph [ref=e63]: Choose up to 32 text files with simple names, at most 64 KB each and 128 KB total.
        - generic [ref=e64]:
          - text: Acceptance criteria (one per line)
          - textbox "Acceptance criteria (one per line)" [ref=e65]: Correct count
        - paragraph [ref=e66]: Write 1–16 independent checks, one per line.
        - generic [ref=e67]:
          - generic [ref=e68]:
            - checkbox "Check expected JSON output" [checked] [ref=e69]
            - text: Check expected JSON output
          - generic [ref=e70]:
            - text: Output JSON file
            - textbox "Output JSON file" [ref=e71]: result.json
          - generic [ref=e72]:
            - text: JSON pointer (empty checks the whole file)
            - textbox "JSON pointer (empty checks the whole file)" [ref=e73]
          - generic [ref=e74]:
            - text: Expected JSON value
            - textbox "Expected JSON value" [ref=e75]: "{\"count\":3}"
        - generic [ref=e76]:
          - text: Domain
          - textbox "Domain" [ref=e77]: csv-count
      - paragraph [ref=e78]: Each catalog task owns its source, inputs and acceptance checks.
      - group "Next task 1" [ref=e79]:
        - generic [ref=e81]:
          - text: Task ID
          - textbox "Task ID" [ref=e82]: task-0002
        - generic [ref=e83]:
          - text: Domain
          - textbox "Domain" [ref=e84]: csv-count
        - generic [ref=e85]:
          - text: Task description
          - textbox "Next task description 1" [ref=e86]: Count the second data set
        - button "Copy current text inputs" [ref=e87]
        - generic [ref=e88]:
          - text: Text input files
          - button "Text input files" [ref=e89]
        - generic [ref=e90]:
          - text: Acceptance criteria (one per line)
          - textbox "Next task criteria 1" [ref=e91]: Correct second count
        - generic [ref=e93]:
          - checkbox "Check expected JSON output" [ref=e94]
          - text: Check expected JSON output
        - button "Remove next task" [ref=e95]
      - generic [ref=e96]:
        - button "Add next task" [ref=e97]
        - button "Add Notebook task from another chat" [ref=e98]
      - generic [ref=e99]:
        - text: Optimization mode
        - combobox "Optimization mode" [ref=e100]:
          - option "Sequential" [selected]
          - option "Parallel"
      - generic [ref=e101]:
        - checkbox "Compare both optimization modes" [ref=e102]
        - text: Compare both optimization modes
      - generic [ref=e103]:
        - text: Recursion parameter (k)
        - spinbutton "Recursion parameter (k)" [ref=e104]: "1"
      - generic [ref=e105]:
        - text: Concurrent executions
        - spinbutton "Concurrent executions" [ref=e106]: "1"
      - generic [ref=e107]:
        - text: Shuffle seed (empty uses original order)
        - textbox "Shuffle seed (empty uses original order)" [ref=e108]
      - generic [ref=e109]:
        - text: Domain filter
        - textbox "Domain filter" [ref=e110]
      - generic [ref=e111]:
        - text: Task filter
        - textbox "Task filter" [ref=e112]
      - paragraph [ref=e113]: Separate filter IDs with commas or spaces; empty includes all.
      - generic [ref=e114]:
        - text: Tasks per domain (empty means all)
        - textbox "Tasks per domain (empty means all)" [ref=e115]
      - generic [ref=e116]:
        - text: Domain workers
        - spinbutton "Domain workers" [ref=e117]: "1"
      - button "Preview task stream" [ref=e118]
      - status [ref=e119]:
        - paragraph [ref=e120]: First attempts require 20 executions including assessments; retries use the same limit.
        - paragraph [ref=e121]: "Planned domain csv-count: task-0001, task-0002"
      - generic [ref=e122]:
        - text: Shared execution limit (all task assessments and reflections)
        - spinbutton "Shared execution limit (all task assessments and reflections)" [ref=e123]: "20"
      - button "Start optimization" [ref=e125]
```

# Test source

```ts
  91  |   await page.goto('/task-optimization.html?complete')
  92  |   await page.getByText('Optimize task', { exact: true }).click()
  93  |   await page
  94  |     .getByLabel('Acceptance criteria (one per line)', { exact: true })
  95  |     .fill('The output is valid')
  96  |   await page.getByRole('button', { name: 'Preview task stream', exact: true }).click()
  97  |   await page.getByRole('button', { name: 'Start optimization', exact: true }).click()
  98  |   await expect(page.getByText('Baseline assessment', { exact: true })).toBeVisible()
  99  |   await expect(page.getByText('Candidate assessment', { exact: true })).toBeVisible()
  100 |   await page.getByRole('button', { name: 'Open assessment', exact: true }).last().click()
  101 |   await page.getByRole('button', { name: 'Open result chat 2', exact: true }).click()
  102 |   expect(
  103 |     await page.evaluate(
  104 |       () =>
  105 |         (window as unknown as { optimizationFixture: { reviews: string[]; sessions: string[] } })
  106 |           .optimizationFixture
  107 |     )
  108 |   ).toMatchObject({ reviews: ['review-candidate'], sessions: ['candidate-session'] })
  109 |   await page.getByRole('button', { name: 'Switch source chat', exact: true }).click()
  110 |   await page.getByText('Optimize task', { exact: true }).click()
  111 |   await expect(page.getByLabel('Task description', { exact: true })).toHaveValue(
  112 |     'Synthetic task next'
  113 |   )
  114 |   await expect(page.getByText('Baseline assessment', { exact: true })).toHaveCount(0)
  115 | })
  116 | test('keeps errors credential-free and hides unsupported web entry', async ({ page }) => {
  117 |   await page.goto('/task-optimization.html?error')
  118 |   await page.getByText('Optimize task', { exact: true }).click()
  119 |   await page
  120 |     .getByLabel('Acceptance criteria (one per line)', { exact: true })
  121 |     .fill('The output is valid')
  122 |   await page.getByRole('button', { name: 'Preview task stream', exact: true }).click()
  123 |   await page.getByRole('button', { name: 'Start optimization', exact: true }).click()
  124 |   await expect(page.getByRole('alert')).toContainText('Check the selected model')
  125 |   await expect(page.locator('body')).not.toContainText('synthetic-secret')
  126 |   await page.goto('/task-optimization.html?web')
  127 |   await expect(page.getByTestId('task-optimization-panel')).toHaveCount(0)
  128 | })
  129 | 
  130 | for (const mode of ['sequential', 'parallel']) {
  131 |   test(`submits ${mode} k2 and displays the original selector result`, async ({ page }) => {
  132 |     await page.goto('/task-optimization.html?complete')
  133 |     await page.getByText('Optimize task', { exact: true }).click()
  134 |     await page.getByLabel('Optimization mode', { exact: true }).selectOption(mode)
  135 |     await page.getByLabel('Recursion parameter (k)', { exact: true }).fill('2')
  136 |     await page.getByLabel('Concurrent executions', { exact: true }).fill('2')
  137 |     const budget = page.getByLabel('Execution limit (includes two assessments)', { exact: true })
  138 |     await expect(budget).toHaveValue('12')
  139 |     await budget.fill('20')
  140 |     await page
  141 |       .getByLabel('Acceptance criteria (one per line)', { exact: true })
  142 |       .fill('The requested output is complete')
  143 |     await page.getByRole('button', { name: 'Preview task stream', exact: true }).click()
  144 |     await page.getByRole('button', { name: 'Start optimization', exact: true }).click()
  145 |     await expect(page.getByText('Selector comparison', { exact: true })).toBeVisible()
  146 |     await expect(
  147 |       page.getByText(`Selected ${mode === 'parallel' ? 'agg2' : 'c2'} from 2 candidates`, {
  148 |         exact: true
  149 |       })
  150 |     ).toBeVisible()
  151 |     expect(
  152 |       await page.evaluate(
  153 |         () =>
  154 |           (window as unknown as { optimizationFixture: { sweeps: unknown[] } }).optimizationFixture
  155 |             .sweeps[0]
  156 |       )
  157 |     ).toMatchObject({ sweep: { modes: [mode], k: 2, concurrency: 2 }, executionLimit: 20 })
  158 |   })
  159 | }
  160 | 
  161 | test('keeps domain admission scoped to each task and submits private JSON expectations', async ({
  162 |   page
  163 | }) => {
  164 |   await page.goto('/task-optimization.html?complete')
  165 |   await page.getByText('Optimize task', { exact: true }).click()
  166 |   await page.getByLabel('Acceptance criteria (one per line)', { exact: true }).fill('Correct count')
  167 |   await page.getByLabel('Domain', { exact: true }).first().fill('csv-count')
  168 |   await page.getByRole('button', { name: 'Add next task', exact: true }).click()
  169 |   await page
  170 |     .getByLabel('Next task description 1', { exact: true })
  171 |     .fill('Count the second data set')
  172 |   await page.getByLabel('Next task criteria 1', { exact: true }).fill('Correct second count')
  173 |   await page.getByLabel('Check expected JSON output', { exact: true }).first().check()
  174 |   await page.getByLabel('Expected JSON value', { exact: true }).fill('{"count":3}')
  175 |   await expect(
  176 |     page.getByLabel('Shared execution limit (all task assessments and reflections)', {
  177 |       exact: true
  178 |     })
  179 |   ).toHaveValue('12')
  180 |   await page.getByRole('button', { name: 'Preview task stream', exact: true }).click()
  181 |   await page.getByRole('button', { name: 'Start optimization', exact: true }).click()
  182 |   const results = page.getByTestId('domain-results')
  183 |   const tasks = results.locator('section')
  184 |   await expect(tasks.first()).toContainText('Eligible for further configuration validation')
  185 |   await expect(tasks.last()).toContainText('Configuration admission blocked')
  186 |   await expect(tasks.last()).toContainText('An expected output check failed.')
  187 |   await expect(page.getByTestId('research-outcome')).toHaveCount(2)
  188 |   await expect(
  189 |     page.getByText('Eligible for further configuration validation', { exact: true })
  190 |   ).toHaveCount(1)
> 191 |   await expect(page.getByRole('status')).not.toContainText('output-check-failed')
      |                                              ^ Error: expect(locator).not.toContainText(expected) failed
  192 |   expect(
  193 |     await page.evaluate(
  194 |       () =>
  195 |         (window as unknown as { optimizationFixture: { sweeps: unknown[] } }).optimizationFixture
  196 |           .sweeps[0]
  197 |     )
  198 |   ).toMatchObject({
  199 |     executionLimit: 20,
  200 |     catalog: [
  201 |       {
  202 |         taskId: 'task-0001',
  203 |         domain: 'csv-count',
  204 |         checks: [{ kind: 'json-value', path: 'result.json', pointer: '', expected: { count: 3 } }]
  205 |       },
  206 |       {
  207 |         taskId: 'task-0002',
  208 |         domain: 'csv-count',
  209 |         criteria: 'Correct second count',
  210 |         source: { kind: 'text', prompt: 'Count the second data set', files: [] }
  211 |       }
  212 |     ]
  213 |   })
  214 | })
  215 | 
```