# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: earthnano-notebook-catalog.spec.ts >> runs two independent Notebook sources through one original sweep and resumes without source crossover
- Location: e2e/earthnano-notebook-catalog.spec.ts:20:5

# Error details

```
TimeoutError: locator.fill: Timeout 30000ms exceeded.
Call log:
  - waiting for getByTestId('task-optimization-panel').getByTestId('optimization-catalog-task-task-0002').getByLabel('Acceptance criteria (one per line)', { exact: true })

```

# Page snapshot

```yaml
- generic [ref=f3e2]:
  - main [ref=f3e4]:
    - generic [ref=f3e5]:
      - generic [ref=f3e6]:
        - complementary "Workspace navigation" [ref=f3e9]:
          - generic [ref=f3e10]:
            - generic [ref=f3e12]:
              - button "All projects" [ref=f3e13] [cursor=pointer]
              - button "EarthNano independent Notebook sources" [ref=f3e16] [cursor=pointer]
              - button "Collapse sidebar panel" [expanded] [ref=f3e20] [cursor=pointer]
            - navigation "Sessions" [ref=f3e23]:
              - button "New" [ref=f3e25] [cursor=pointer]
              - button "Customize" [ref=f3e30] [cursor=pointer]
              - button "Files" [ref=f3e37] [cursor=pointer]
              - button "Compute" [ref=f3e45] [cursor=pointer]
              - button "Library" [ref=f3e52] [cursor=pointer]
              - generic [ref=f3e59]:
                - generic [ref=f3e60]: Active
                - generic [ref=f3e62]:
                  - 'button "Session status: Idle Observation set B: Analyze the attached measurem..." [ref=f3e63] [cursor=pointer]':
                    - generic [ref=f3e66]: "Session status: Idle"
                    - generic [ref=f3e67]: "Observation set B: Analyze the attached measurem..."
                  - 'button "Open actions for Observation set B: Analyze the attached measurem..." [ref=f3e68]'
                - generic [ref=f3e75]:
                  - 'button "Session status: Idle Observation set A: Analyze the attached measurem..." [ref=f3e76] [cursor=pointer]':
                    - generic [ref=f3e79]: "Session status: Idle"
                    - generic [ref=f3e80]: "Observation set A: Analyze the attached measurem..."
                  - 'button "Open actions for Observation set A: Analyze the attached measurem..." [ref=f3e81]'
              - generic [ref=f3e88]:
                - button "Settings" [ref=f3e89] [cursor=pointer]
                - button "Messages, 4 unread" [ref=f3e94]
                - link "Star EarthNano on GitHub" [ref=f3e99] [cursor=pointer]:
                  - /url: https://github.com/lust0yixiong/EarthNano
        - separator "Resize left panel" [ref=f3e101]
        - generic [ref=f3e104]:
          - generic [ref=f3e105]:
            - heading [level=1] [ref=f3e106]:
              - 'button "Session information: Observation set B: Analyze the attached measurem..." [ref=f3e107]':
                - generic [ref=f3e108]: "#2"
                - 'generic "Observation set B: Analyze the attached measurem..." [ref=f3e109]'
            - button "Export diagnostics…" [ref=f3e110]
            - button "Session actions" [ref=f3e116]
          - group [ref=f3e121]:
            - generic "Optimize task" [ref=f3e122] [cursor=pointer]
            - generic [ref=f3e123]:
              - generic [ref=f3e124]:
                - generic [ref=f3e125]:
                  - checkbox "Repeat this task with Notebook Python" [checked] [ref=f3e126]
                  - text: Repeat this task with Notebook Python
                - generic [ref=f3e127]:
                  - generic [ref=f3e128]:
                    - text: Source chat
                    - combobox "Source chat" [ref=f3e129]:
                      - option "Choose a source chat"
                      - 'option "Observation set B: Analyze the attached measurem..." [selected]'
                      - 'option "Observation set A: Analyze the attached measurem..."'
                  - generic [ref=f3e130]:
                    - text: Source task
                    - combobox "Source task" [ref=f3e131]:
                      - option "Choose an original Notebook task"
                      - 'option "Observation set B: Analyze the attached measurements.csv using Notebook Python. List runtimes and bind the enabled external Python runtime. Use Python csv and s" [selected]'
                - generic [ref=f3e132]:
                  - text: Task ID
                  - textbox "Task ID" [ref=f3e133]: task-0001
                - generic [ref=f3e134]:
                  - text: Task description
                  - textbox "Task description" [disabled] [ref=f3e135]: "Observation set B: Analyze the attached measurements.csv using Notebook Python. List runtimes and bind the enabled external Python runtime. Use Python csv and statistics to calculate count, sum and arithmetic mean. Save numeric count, sum, mean in research-results.json. Publish this exact local file with write_artifact_file and the actual Notebook producerRunId. Do not use native Bash or native Write or create extra artifacts. After publication reply: Research analysis complete."
                - generic [ref=f3e136]:
                  - text: Acceptance criteria (one per line)
                  - textbox "Acceptance criteria (one per line)" [ref=f3e137]: The published numeric report matches this task’s fixed source observations.
                - paragraph [ref=f3e138]: Write 1–16 independent checks, one per line.
                - generic [ref=f3e139]:
                  - generic [ref=f3e140]:
                    - checkbox "Check expected JSON output" [checked] [ref=f3e141]
                    - text: Check expected JSON output
                  - generic [ref=f3e142]:
                    - text: Output JSON file
                    - textbox "Output JSON file" [ref=f3e143]: research-results.json
                  - generic [ref=f3e144]:
                    - text: JSON pointer (empty checks the whole file)
                    - textbox "JSON pointer (empty checks the whole file)" [ref=f3e145]
                  - generic [ref=f3e146]:
                    - text: Expected JSON value
                    - textbox "Expected JSON value" [ref=f3e147]: "{\"count\":2,\"sum\":30,\"mean\":15}"
                - generic [ref=f3e148]:
                  - text: Domain
                  - textbox "Domain" [ref=f3e149]: research
              - paragraph [ref=f3e150]: Each catalog task owns its source, inputs and acceptance checks.
              - group "Next task 1" [ref=f3e151]:
                - generic [ref=f3e153]:
                  - text: Task ID
                  - textbox "Task ID" [ref=f3e154]: task-0002
                - generic [ref=f3e155]:
                  - text: Domain
                  - textbox "Domain" [ref=f3e156]: research
                - generic [ref=f3e157]:
                  - generic [ref=f3e158]:
                    - text: Source chat
                    - combobox "Source chat" [ref=f3e159]:
                      - option "Choose a source chat"
                      - 'option "Observation set B: Analyze the attached measurem..."'
                      - 'option "Observation set A: Analyze the attached measurem..." [selected]'
                  - generic [ref=f3e160]:
                    - text: Source task
                    - combobox "Source task" [ref=f3e161]:
                      - option "Choose an original Notebook task"
                      - 'option "Observation set A: Analyze the attached measurements.csv using Notebook Python. List runtimes and bind the enabled external Python runtime. Use Python csv and s" [selected]'
                - generic [ref=f3e162]:
                  - text: Acceptance criteria (one per line)
                  - textbox "Next task criteria 1" [ref=f3e163]
                - generic [ref=f3e165]:
                  - checkbox "Check expected JSON output" [ref=f3e166]
                  - text: Check expected JSON output
                - button "Remove next task" [ref=f3e167]
              - generic [ref=f3e168]:
                - button "Add next task" [ref=f3e169]
                - button "Add Notebook task from another chat" [active] [ref=f3e170]
              - generic [ref=f3e171]:
                - text: Optimization mode
                - combobox "Optimization mode" [ref=f3e172]:
                  - option "Sequential" [selected]
                  - option "Parallel"
              - generic [ref=f3e173]:
                - checkbox "Compare both optimization modes" [ref=f3e174]
                - text: Compare both optimization modes
              - generic [ref=f3e175]:
                - text: Recursion parameter (k)
                - spinbutton "Recursion parameter (k)" [ref=f3e176]: "1"
              - generic [ref=f3e177]:
                - text: Concurrent executions
                - spinbutton "Concurrent executions" [ref=f3e178]: "1"
              - generic [ref=f3e179]:
                - text: Shuffle seed (empty uses original order)
                - textbox "Shuffle seed (empty uses original order)" [ref=f3e180]
              - generic [ref=f3e181]:
                - text: Domain filter
                - textbox "Domain filter" [ref=f3e182]
              - generic [ref=f3e183]:
                - text: Task filter
                - textbox "Task filter" [ref=f3e184]
              - paragraph [ref=f3e185]: Separate filter IDs with commas or spaces; empty includes all.
              - generic [ref=f3e186]:
                - text: Tasks per domain (empty means all)
                - textbox "Tasks per domain (empty means all)" [ref=f3e187]
              - generic [ref=f3e188]:
                - text: Domain workers
                - spinbutton "Domain workers" [ref=f3e189]: "1"
              - button "Preview task stream" [disabled] [ref=f3e190]
              - paragraph [ref=f3e191]: Preview the current task stream before starting.
              - generic [ref=f3e192]:
                - text: Shared execution limit (all task assessments and reflections)
                - spinbutton "Shared execution limit (all task assessments and reflections)" [ref=f3e193]: "12"
              - button "Start optimization" [disabled] [ref=f3e195]
          - generic [ref=f3e196]:
            - region "Conversation" [ref=f3e197]:
              - log [ref=f3e198]:
                - generic [ref=f3e201]:
                  - generic [ref=f3e202]:
                    - generic [ref=f3e203]:
                      - button "Copy message" [ref=f3e204]
                      - button "Edit message" [ref=f3e209]
                    - generic [ref=f3e213]:
                      - button "Preview uploaded attachment measurements.csv" [ref=f3e215]:
                        - generic [ref=f3e220]:
                          - generic [ref=f3e221]: measure
                          - generic [ref=f3e222]: ments
                          - generic [ref=f3e223]: .csv
                      - generic [ref=f3e224]: "Observation set B: Analyze the attached measurements.csv using Notebook Python. List runtimes and bind the enabled external Python runtime. Use Python csv and statistics to calculate count, sum and arithmetic mean. Save numeric count, sum, mean in research-results.json. Publish this exact local file with write_artifact_file and the actual Notebook producerRunId. Do not use native Bash or native Write or create extra artifacts. After publication reply: Research analysis complete."
                  - time [ref=f3e228]: Sent Oct 21, 1:41 AM
                - generic [ref=f3e231]:
                  - button "Saved a file, completed a Notebook run, ran 2 tools 4 steps · 4s" [expanded] [ref=f3e232]:
                    - generic [ref=f3e236]: Saved a file, completed a Notebook run, ran 2 tools
                    - generic [ref=f3e237]: 4 steps · 4s
                  - generic [ref=f3e239]:
                    - button "Notebook runtimes" [ref=f3e241]
                    - button "Bind notebook runtime" [ref=f3e248]
                    - button "Notebook run completed" [ref=f3e255]:
                      - generic [ref=f3e259]: Notebook run
                      - generic [ref=f3e261]: completed
                    - button "Write file · research-re sults .json 39 B" [ref=f3e263]:
                      - generic [ref=f3e267]:
                        - generic [ref=f3e268]: Write file
                        - generic [ref=f3e269]: ·
                        - generic [ref=f3e271]:
                          - generic [ref=f3e272]: research-re
                          - generic [ref=f3e273]: sults
                          - generic [ref=f3e274]: .json
                      - generic [ref=f3e275]: 39 B
                - generic [ref=f3e278]:
                  - paragraph [ref=f3e284]: Research analysis complete.
                  - generic [ref=f3e285]:
                    - generic [ref=f3e286]: GENERATED · 1
                    - button "Preview generated file research-results.json" [ref=f3e289] [cursor=pointer]:
                      - generic [ref=f3e290]: "{\"count\": 2, \"sum\": 30.0, \"mean\": 15.0}"
                      - generic [ref=f3e298]:
                        - generic [ref=f3e299]:
                          - generic [ref=f3e300]: research-re
                          - generic [ref=f3e301]: sults
                          - generic [ref=f3e302]: .json
                        - generic [ref=f3e303]: 39 B
                - generic [ref=f3e307]:
                  - generic [ref=f3e308]:
                    - button "Copy message" [ref=f3e309]
                    - button "Branch in new session" [ref=f3e314]
                  - time [ref=f3e319]: Completed Oct 21, 1:41 AM
                  - generic [ref=f3e320]: Elapsed 6s
                  - button "Token usage for this response" [ref=f3e322]: Calls
            - button:
              - generic: First message
            - button "Scroll to end"
            - generic [ref=f3e327]: Response completed.
          - generic [ref=f3e332]:
            - button "Open notebook" [ref=f3e334] [cursor=pointer]: Notebook
            - generic [ref=f3e340]:
              - generic [ref=f3e342]:
                - textbox "Ask anything" [ref=f3e343]
                - generic [ref=f3e344]: At the start of the input, use Up and Down Arrow to browse prompt history.
                - status [ref=f3e345]
                - generic: "Ask anything — / skills · @ files · # sessions · ⌘K search · ↑↓ history"
              - generic [ref=f3e346]:
                - button "Add attachment, save as skill, view context window, or request review" [ref=f3e347]
                - 'button "Agent controls: Ask for approval, auto-review Off, Delegation On" [ref=f3e349]':
                  - generic "1 allowed this session" [ref=f3e351]: "1"
                - 'button "Context used: 0%" [ref=f3e352]':
                  - generic [ref=f3e356]: 0%
                - button "Select model" [ref=f3e357]:
                  - generic [ref=f3e358]: deepseek-flash
                - group "Send message options" [ref=f3e360]:
                  - button "Send message" [disabled]
                  - button "More send options" [ref=f3e361]
        - separator [disabled]
        - generic:
          - generic:
            - generic:
              - generic:
                - complementary:
                  - generic [ref=f3e362]:
                    - generic:
                      - tablist "Open previews" [ref=f3e363]:
                        - tab "Notebook" [selected] [ref=f3e364]
                        - tab "Notebook" [ref=f3e368]
                      - button "Close preview of Notebook" [ref=f3e372]
                      - button "Close preview of Notebook" [ref=f3e376]
      - button "Expand preview panel" [ref=f3e380] [cursor=pointer]
  - generic:
    - generic:
      - status: Notebook environment ready
```

# Test source

```ts
  99  |     projectId = await createProject(page, projectName)
  100 |     dataRoot = (await page.evaluate(() => window.api.storage.getInfo())).dataRoot
  101 |     const datasets = [
  102 |       {
  103 |         name: 'Observation set A',
  104 |         csv: 'sample,value\nA,2\nB,4\nC,6\n',
  105 |         expected: { count: 3, sum: 12, mean: 4 }
  106 |       },
  107 |       {
  108 |         name: 'Observation set B',
  109 |         csv: 'sample,value\nX,10\nY,20\n',
  110 |         expected: { count: 2, sum: 30, mean: 15 }
  111 |       }
  112 |     ]
  113 |     const sources: Array<{
  114 |       session: PersistedChatSession
  115 |       prompt: string
  116 |       promptMessageId: string
  117 |       csv: string
  118 |       expected: { count: number; sum: number; mean: number }
  119 |     }> = []
  120 |     for (const [index, dataset] of datasets.entries()) {
  121 |       if (index) await page.getByRole('button', { name: 'New', exact: true }).click()
  122 |       await page.locator('input[type="file"][multiple]').setInputFiles({
  123 |         name: 'measurements.csv',
  124 |         mimeType: 'text/csv',
  125 |         buffer: Buffer.from(dataset.csv)
  126 |       })
  127 |       const prompt = `${dataset.name}: Analyze the attached measurements.csv using Notebook Python. List runtimes and bind the enabled external Python runtime. Use Python csv and statistics to calculate count, sum and arithmetic mean. Save numeric count, sum, mean in research-results.json. Publish this exact local file with write_artifact_file and the actual Notebook producerRunId. Do not use native Bash or native Write or create extra artifacts. After publication reply: Research analysis complete.`
  128 |       await submitPromptViaUi(page, prompt)
  129 |       await expect(
  130 |         page
  131 |           .getByRole('region', { name: 'Conversation' })
  132 |           .getByText('Research analysis complete.', { exact: true })
  133 |       ).toBeVisible({ timeout: 180_000 })
  134 |       const readSource = (): Promise<PersistedChatSession | undefined> =>
  135 |         page.evaluate(
  136 |           async ({ projectId, prompt }) =>
  137 |             (await window.api.sessions.loadAll()).sessions.find(
  138 |               (entry) =>
  139 |                 entry.projectId === projectId &&
  140 |                 entry.messages.some(
  141 |                   (message) => message.role === 'user' && message.content === prompt
  142 |                 )
  143 |             ),
  144 |           { projectId: projectId!, prompt }
  145 |         )
  146 |       await expect.poll(async () => (await readSource())?.artifacts?.length).toBe(1)
  147 |       const session = (await readSource())!
  148 |       const message = session.messages.find(
  149 |         (message) => message.role === 'user' && message.content === prompt
  150 |       )!
  151 |       expect(message.uploads).toHaveLength(1)
  152 |       const state = await page.evaluate((request) => window.api.notebook.state(request), {
  153 |         projectId,
  154 |         sessionId: session.id,
  155 |         workspaceCwd: session.cwd ?? ''
  156 |       })
  157 |       expect(state.runtimeBindings?.python).toBeDefined()
  158 |       sources.push({
  159 |         session,
  160 |         prompt,
  161 |         promptMessageId: message.id,
  162 |         csv: dataset.csv,
  163 |         expected: dataset.expected
  164 |       })
  165 |     }
  166 |     expect(sources[0].session.id).not.toBe(sources[1].session.id)
  167 |     expect(
  168 |       sources[0].session.messages.find((entry) => entry.id === sources[0].promptMessageId)!
  169 |         .uploads![0].versionId
  170 |     ).not.toBe(
  171 |       sources[1].session.messages.find((entry) => entry.id === sources[1].promptMessageId)!
  172 |         .uploads![0].versionId
  173 |     )
  174 |     await page.removeLocatorHandler(page.getByTestId('permission-card'))
  175 |     const navigation = sources[1]
  176 |     const sourceByTask = new Map([
  177 |       ['task-0001', sources[1]],
  178 |       ['task-0002', sources[0]]
  179 |     ])
  180 |     const panel = page.getByTestId('task-optimization-panel')
  181 |     await panel.locator('summary').click()
  182 |     await panel.getByLabel('Repeat this task with Notebook Python', { exact: true }).check()
  183 |     await panel
  184 |       .getByLabel('Acceptance criteria (one per line)', { exact: true })
  185 |       .fill('The published numeric report matches this task’s fixed source observations.')
  186 |     await panel.getByLabel('Check expected JSON output', { exact: true }).check()
  187 |     await panel.getByLabel('Output JSON file', { exact: true }).fill('research-results.json')
  188 |     await panel
  189 |       .getByLabel('Expected JSON value', { exact: true })
  190 |       .fill(JSON.stringify(navigation.expected))
  191 |     await panel
  192 |       .getByRole('button', { name: 'Add Notebook task from another chat', exact: true })
  193 |       .click()
  194 |     const extra = panel.getByTestId('optimization-catalog-task-task-0002')
  195 |     await extra.getByLabel('Source chat', { exact: true }).selectOption(sources[0].session.id)
  196 |     await extra.getByLabel('Source task', { exact: true }).selectOption(sources[0].promptMessageId)
  197 |     await extra
  198 |       .getByLabel('Acceptance criteria (one per line)', { exact: true })
> 199 |       .fill('The published numeric report matches this task’s fixed source observations.')
      |        ^ TimeoutError: locator.fill: Timeout 30000ms exceeded.
  200 |     await extra.getByLabel('Check expected JSON output', { exact: true }).check()
  201 |     await extra.getByLabel('Output JSON file', { exact: true }).fill('research-results.json')
  202 |     await extra
  203 |       .getByLabel('Expected JSON value', { exact: true })
  204 |       .fill(JSON.stringify(sources[0].expected))
  205 |     await panel.getByLabel('Compare both optimization modes', { exact: true }).check()
  206 |     await panel.getByLabel('Recursion parameter (k)', { exact: true }).fill('1')
  207 |     await panel.getByLabel('Concurrent executions', { exact: true }).fill('2')
  208 |     await panel.getByLabel('Shuffle seed (empty uses original order)', { exact: true }).fill('0')
  209 |     await panel.getByLabel('Tasks per domain (empty means all)', { exact: true }).fill('2')
  210 |     await panel
  211 |       .getByLabel('Shared execution limit (all task assessments and reflections)', { exact: true })
  212 |       .fill(String(bounds.coreAdmissions))
  213 |     const callsBeforePreview = provider.stats.requests
  214 |     await panel.getByRole('button', { name: 'Preview task stream', exact: true }).click()
  215 |     await expect(panel.getByTestId('optimization-sweep-preview')).toContainText('36')
  216 |     expect(provider.stats.requests).toBe(callsBeforePreview)
  217 |     await panel.getByRole('button', { name: 'Start optimization', exact: true }).click()
  218 |     const latest = (): Promise<OptimizationProgress | null> =>
  219 |       page.evaluate((request) => window.api.optimization.latest(request), {
  220 |         projectId: projectId!,
  221 |         sourceSessionId: navigation.session.id
  222 |       })
  223 |     await expect.poll(() => provider.stats.pausedBeforeForward, { timeout: 180_000 }).toBe(1)
  224 |     const beforeStop = (await latest())!
  225 |     await panel.getByRole('button', { name: 'Stop optimization', exact: true }).click()
  226 |     await expect.poll(async () => (await latest())?.resumeAvailable, { timeout: 60_000 }).toBe(true)
  227 |     const stopped = (await latest())!
  228 |     const work = join(dataRoot, 'earthnano', 'desktop-runs', stopped.runId, 'execution')
  229 |     const stoppedJournal = JSON.parse(
  230 |       await readFile(join(work, 'execution.json'), 'utf8')
  231 |     ) as ExecutionState
  232 |     expect(
  233 |       Object.values(stoppedJournal.records).some(
  234 |         (record) => record.request.role === 'baseline' && record.phase === 'completed'
  235 |       )
  236 |     ).toBe(true)
  237 |     await writeFile(
  238 |       testInfo.outputPath('stopped-journal.json'),
  239 |       JSON.stringify(stoppedJournal, null, 2)
  240 |     )
  241 |     const callsBeforeReopen = provider.stats.requests
  242 |     page = await app.restart()
  243 |     await openProjectSession(page, projectName, navigation.prompt)
  244 |     expect(await latest()).toEqual(stopped)
  245 |     expect(provider.stats.requests).toBe(callsBeforeReopen)
  246 |     const reopenedPanel = page.getByTestId('task-optimization-panel')
  247 |     await reopenedPanel.locator('summary').click()
  248 |     await reopenedPanel.getByRole('button', { name: 'Resume optimization', exact: true }).click()
  249 |     await expect
  250 |       .poll(async () => (await latest())?.state, { timeout: 600_000, intervals: [1000, 2000] })
  251 |       .toMatch(/^(completed|failed|interrupted)$/)
  252 |     const completed = (await latest())!
  253 |     report.progress = completed
  254 |     expect(completed.error).toBeUndefined()
  255 |     expect(completed.state).toBe('completed')
  256 |     expect(completed.runId).toBe(beforeStop.runId)
  257 |     expect(completed.budget.limit).toBe(bounds.coreAdmissions)
  258 |     expect(completed.budget.admitted).toBeLessThanOrEqual(bounds.coreAdmissions)
  259 |     expect(completed.budget.active).toBe(0)
  260 |     const journal = JSON.parse(
  261 |       await readFile(join(work, 'execution.json'), 'utf8')
  262 |     ) as ExecutionState
  263 |     const manifest = JSON.parse(
  264 |       await readFile(join(work, 'resume.json'), 'utf8')
  265 |     ) as PersistentOptimizationResume
  266 |     const routing = JSON.parse(await readFile(join(work, 'request-tasks.json'), 'utf8')) as {
  267 |       schemaVersion: number
  268 |       entries: Record<string, { taskId: string; scope: string }>
  269 |     }
  270 |     expect(routing.schemaVersion).toBe(2)
  271 |     expect(manifest.identity.sweep!.request.sweep.stream.seed).toBe(0)
  272 |     expect(manifest.identity.sweep!.request.previewPlanDigest).toBe(completed.sweep!.planDigest)
  273 |     expect(manifest.identity.sweep!.plan.digest).toBe(completed.sweep!.planDigest)
  274 |     expect(completed.sweep!.order.flatMap((domain) => domain.taskIds).sort()).toEqual([
  275 |       'task-0001',
  276 |       'task-0002'
  277 |     ])
  278 |     expect(manifest.identity.sweep!.tasks).toHaveLength(2)
  279 |     const reviewerSources = new Map<string, string>()
  280 |     for (const [taskId, source] of sourceByTask) {
  281 |       const originalUpload = source.session.messages.find(
  282 |         (entry) => entry.id === source.promptMessageId
  283 |       )!.uploads![0]
  284 |       const frozen = manifest.identity.sweep!.tasks.find((task) => task.taskId === taskId)!
  285 |       expect(frozen.sourceSessionId).toBe(source.session.id)
  286 |       expect(frozen.sourcePromptMessageId).toBe(source.promptMessageId)
  287 |       expect(frozen.input.task.prompt).toBe(source.prompt)
  288 |       expect(frozen.input.task.managedInputs).toMatchObject([
  289 |         {
  290 |           sourceSessionId: source.session.id,
  291 |           inputFileVersionId: originalUpload.versionId,
  292 |           checksum: originalUpload.sha256
  293 |         }
  294 |       ])
  295 |       const tasks = completed.sweep!.domains.map(({ mode, summary }) => ({
  296 |         mode,
  297 |         task: summary.tasks.find((task) => task.taskId === taskId)!
  298 |       }))
  299 |       expect(tasks).toHaveLength(2)
```