# Shared original Compute workflow fixture

Base f528ca17177d61a50c24ecc681d66aba4d4f8ba3; branch test/alpha-compute-workflow-fixture. Only original workflow integration test is refactored and test/earthnano/compute-workflow.ts is added. All production files and the already delivered compute-transport.ts remain unchanged.

## Interface

`createComputeWorkflowFixture({mode:'authorized'|'no-grant'|'protection-unavailable',sourcePrompt?:string}):Promise<ComputeWorkflowFixture>`

Returns root/configRoot/projectId/sourceSessionId, optional sourcePromptMessageId; original same client/getClient, sessions, ports(sessionPersistence/settings), versions; notebook:{service,rpc,mcpEntryPath}; compute:PersistentCandidateComputeOptions; onOwnersReady:CandidateOwnersReady; transport, jobs, operations, deliveries, events, grants, approvalId/approvalBroadcast counters, service/runtime/execution/changes/frozenCompute; start() delegates to original runtime.start; close() joins original teardown.

The helper constructs no candidate factory, Core, snapshot store, model provider, Harness method or second Job engine. The caller directly feeds onOwnersReady to existing runPersistentOptimization. The existing test manually constructs/registers two real factories (one creates work, one idle), and releases each only after its original shutdown reports reaped.

If sourcePrompt is provided, the helper's initial original saveSession contains one real complete user Message with sourcePromptMessageId and an original createLinearConversationGraph graph. The authorized case verifies the persisted graph message, role, text and complete status. Without sourcePrompt, no message identity is fabricated and sourcePromptMessageId is omitted.

RPC control-policy acquisition and all result-delivery callbacks use the **same original createDesktopCandidateOwnerRouting** instance. Its cold callback retains the original data-root lease and original readDesktopPrivateSessions reader with explicit fixture config/data roots; no custom classification/registry or routing algorithm is defined. Multiple factory registration is exercised through the actual successful native/Node two-Turn workflow.

Original queue remains stopped until caller start(). Cipher/Project grant, real submit/queue/dispatch/poll/harvest/notifier/Delivery/producer/Version/Review assembly is moved from the delivered test without a service spy or Job/operation state write. Existing three cases retain the encrypted-row, denied-Run, zero-Job/operation/transport, no approval-ID/card, native identity/budget and actual JSON/PNG assertions. Remote numeric wire fields and cipher remain protocol/test ports only, not SSH/Linux/process/OS-keychain evidence.

close(): stop original delivery scheduling; ask the original shared router to shut down its registered owners; stop original Job runtime; join original dispatch plus recorded notifier/publish/drain promises; close local RPC/Notebook/Prisma. Any rejection or owner reaped=false is propagated as AggregateError and the evidence directory is retained. Closing local ports never changes Core cleanup/Job/operation facts or asserts remote retirement. Only fully successful teardown unlocks/removes the owned fixture directory. close() is idempotent after success and can retry after failure.

## Verification

workflow-shared-final.json/log: original shared router17 + refactored workflow3 =20/20, zero skip/global errors, process exit0. Each workflow case registers two factories; authorized case also verifies actual source prompt persistence. Actual native/Node/SQLite/Version/Review layers remain the same as the earlier workflow report.
workflow-shared-final-types.log: full npm run typecheck:compiled, Node/sandbox/web exit0.
workflow-shared-final-lint.log, workflow-shared-final-format.log, git diff --check: exit0.

Preserved first extraction error: workflow-extraction-attempt1.json/log had2 pass/1 fail because the consumer forgot to destructure deliveries. workflow-extraction-types-attempt1.log reports that missing name plus unused operations destructuring. This was a test extraction bookkeeping error, not a production regression; raw remains preserved. workflow-extraction-final.json/log3/3 also retained as intermediate success.

No paid models, SSH, Windows, CI, build, install or shared dependency changes. Root owns the independent Desktop/Harness/DeepSeek acceptance test and existing module registration; these files were not touched.

Commit 6200bdfb01423df8a3e196994b1cb460e763a7fe; worktree clean.
