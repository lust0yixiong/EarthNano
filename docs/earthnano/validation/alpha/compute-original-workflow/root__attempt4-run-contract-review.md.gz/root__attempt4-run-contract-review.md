# Attempt4: Native tool Run contract and closed-experiment verification

Read-only review of clean7419262c21e74059cd4a6c16ebeb431a69456e9d, original report/native-runs JSON and preserved earthnano-compute-workflow-fPjoPa root. No source/state/score/budget edits or API replay. Historical test exit1 remains failure; it is not rewritten as exit0.

## Finding

The new assertion persistent-compute-sweep.integration.test.ts:365, runs.every(status===completed), is stronger than the original upstream Notebook/Task contract. Original fixed9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5 host-compute.integration.test.ts:260–263 explicitly expects a failed control call followed by a completed call using the same executor. This file's blob is byte-identical at9e18 and741(equals6bb3c1284bc83e1b4544ef34991219e9ef49ecf6). Original runtime-service tests also persist executor failures as failed summaries instead of promoting them to fatal task exceptions.

TaskRunner terminal logic takes the actual native prompt/session completion and cancellation outcome; it does not scan every historical Notebook Run and require success. The terminal decision block from terminalCancellation through persistTerminalRun is unchanged between9e18 and741, although the whole TaskRunner file has the intended shared-boundary/owner changes. Notebook tool failures are recoverable model-visible results; actual prompt failure, ownership/commit failure, unresolved cleanup or cancellation still affect their original owners.

The existing Compute owner already enforces the correct producer boundary in persistent-candidate-owner.ts computeEvidence (~566–616): original admitted scope, no foreign producer Jobs, completed original job producer, final Job result, terminal original Turns, every Version's exact Turn and completed original control producer. verifyExportRecord(~2020) additionally checks original request digest, immutable initial identity, runtime admission, pinned Compute/Turn/Job/Version references and reply. It does not require unrelated failed historical calls to vanish.

## Actual preserved experiment

Report:21/24 Core admissions completed, active0; manager completed and all recorded Core cleanup confirmed;198upstream responses all200,0proxy rejection. Independent baseline88pass/candidate93pass and artifact passed/configuration eligible are retained facts; they do not change the encompassing test's exit1.

Count correction: supplied attempt4-native-runs.json contains11failed, not12. Independent read of all original8 Session Notebook documents confirms50completed+11failed=61, with no queued/running or missing endedAt. Failed counts by the supplied Session order:3,3,1,1,0,3,0,0. Original failure records/scripts/permission denials remain untouched. The selected candidate has0failed Runs.

New read-only JSON proof covers all24 final versions (metrics-source.json/research-results.json/measurements.png for each of8task executions): content SHA and byte length match original evidence; every version is explicitly referenced by its original Core record; producer notebook Session matches; actual producer Run is completed and ended. No producer was inferred from filename/title or promoted from failed to completed. This corroborates successful recovery from intermediate tool failures, not an error-free trajectory.

## Appropriate final assertions

Retain existing Core phase/cleanup/budget, exact Job finality/harvest/notify, initial+continuation identity, original producer scope/file evidence, immutable Version SHA/size, source bytes against original harvested metrics, report arithmetic, PNG bytes/native Read, independent Review refs/score, no-selector-fallback and source-session isolation checks. For historical Native Runs require actual terminal status plus durable endedAt, no queued/running remainder, and preserve failures for diagnostics; do not blanket require every historical tool to succeed. This fixture observed only completed/failed, while the original terminal enum additionally has timeout/interrupted/cancelled. Those statuses alone must never imply confirmed cleanup: retain the original owner cleanup/finality proof.

For each Job/actual published Version specifically require its referenced producer to be completed, admitted to the exact Project/Session/Turn/frame/branch/runtime, and backed by immutable file observations. A failed or foreign/missing producer remains fatal regardless of eventual text reply. Keep failed attempts in provenance and the Core's scientific/compute evidence hash. Do not reinterpret denied copyFileSync as granted, add auto-approval, synthesize a producer or suppress errors.

This does not claim full source-code reproducibility: original artifacts/code-reconstruction.ts:~273 deliberately treats dispatched failed supporting cells as potentially contributing state unless a sealed replay plan proves otherwise. Keep that supporting-code-incomplete guard and any unavailable reproduction conclusion. Final content/producer validity and reproducible end-to-end reconstruction are different evidence claims.

## Handoff and closure

All24 producer references were additionally checked against the actual original Notebook document: producer prompt equals the Version conversation prompt, differs from the immutable initial Core prompt, appears in the Core's exact pinned session-turn references, and rootFrame/agentFrame/branch/runtime match the Version conversation. All24 pass these checks; see attempt4-readonly-integrity-review.json.

No new reader/replay framework was created. Existing readDesktopOptimizationResume, owner exportResult/readReviews, original Version read leases and completed-manager get/shutdown are sufficient for the existing tail checks. No Core start/resume, Job submission, dispatcher restart or model retry was run during this review.

Root subsequently reports a minimal one-file fixture correction d77d6cae: preserve all failed intermediate Runs, require original terminal status+endedAt, require each Version's actual completed/ended continuation producer, clarify full Compute attachJob API and Buffer read/write copy without new permission. Root reports original offline whole workflow1/1, real RUN_KERNEL=1 host-compute15/15, full types/lint0. These are root's separate follow-up checks, not a retroactive change to attempt4. Root's static registration fix is separately integrated as e916b7dee.

The original attempt4 remains test exit1. Baseline88pass/candidate93pass, artifact passed/configuration eligible and selected candidate0failed Native Runs remain observed intermediate experiment facts. Any next real acceptance uses a new clean source and the same fixed budget; this review does not replay API calls or edit old outcomes.
