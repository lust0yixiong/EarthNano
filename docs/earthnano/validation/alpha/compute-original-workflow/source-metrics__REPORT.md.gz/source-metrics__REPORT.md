# Compute fixture source evidence

Commit 2209de4baa3855a1325bc61b1736e7fbeef158e3; base99122746f1b7f39c0decc74dbbf4497f9c36a36f. Only the three authorized acceptance fixture/test files change. Production, H2, independent Review code, shared helper/transport/PNG bytes, request limits and budgets are untouched.

The same frozen task now asks every baseline/candidate to preserve harvested metrics.json exact Buffer bytes as metrics-source.json, derive count/sum/mean from those bytes and publish all three files through original write_artifact_file with the original continuation producer. Numerical criteria require the original source Version; they make no visual/scientific PNG claim. Separate Native Read and exact PNG byte assertions remain. The offline reviewer recomputes from the actual source artifact content, attaches its ref as evidence and retains its original 100/0 scoring. Missing/invalid source fails closed.

Local fixture tests: changed [10,20] source passes only for2/30/15; fixed3/12/4 is flagged against it; absent source and string-valued metrics rejected. Existing Compute case verifies source copy instruction and every publication's original producer/localPath. Original16 cases retained. Old991 provider:15pass/5fail exit1; fixed20/20 exit0.

Original full DesktopSweep/Harness k=2/real Core/native Node/SQLite Compute workflow:1/1 exit0, no global errors, ~75s. Eight task executions (2baseline+6candidate) each have a real successful harvested/notified Job, source/report/PNG Versions, source bytes equal their actual protocol-transport metrics.json, original Reviews and confirmed cleanup.18/24 admissions completed; independent numerical assessments pass, artifact passed/configuration eligible; reopen does not replay.0upstream requests,0proxy rejections. receipt.json records per-execution byte hashes and byteproof of unchanged numeric checks, phase/budget, comparison/cleanup/reopen assertions. Initial external receipt aggregation mistakenly accessed nonexistent job.id; corrected to original job.job_id, without rerunning/changing tests.

Commands:
- node node_modules/vitest/vitest.mjs run scripts/ci/earthnano-messages-provider.test.ts --reporter=default --reporter=json --outputFile=<evidence>/provider-final.json
- EARTHNANO_LIVE_DEEPSEEK=0 EARTHNANO_RESEARCH_PYTHON=/opt/homebrew/opt/python@3.12/bin/python3.12 EARTHNANO_COMPUTE_ACCEPTANCE_REPORT=<evidence>/offline-acceptance.json node node_modules/vitest/vitest.mjs run src/main/earthnano/persistent-compute-sweep.integration.test.ts --reporter=default --reporter=json --outputFile=<evidence>/offline-sweep.json
- npm run typecheck:compiled
- targeted ESLint/Prettier and git diff --check (all0).

This remains fixture scientific-data-flow evidence: SSH/remote Linux commands and cipher are simulations; no real remote science or paid model improvement is claimed. Third live run's flagged Review and long reflection failure are not reclassified or edited. No real API, CI, Windows, build/install or publish operation performed.
