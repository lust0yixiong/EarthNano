# Compute continuation terminal-failure probe

Conclusion: no reproduced production false completion. No production change is proposed. The added local fixture preserves the original delivery retry/state machine and separates failed Notebook tools from a failed native application Turn.

## Source and scope

- Isolated branch `test/alpha-compute-continuation-terminal-failure`, from root `8ec476031040763f6718be6abd7e2c21be392fd6`; only `src/main/earthnano/persistent-compute-candidate.integration.test.ts` changed. Root alpha-method was not written.
- Owner, original delivery owner, original continuation saved predicate, native finalizer and runtime projection exactly match 8ec. `source-hashes.json` records 9e18 / PR20 / 905 / 8ec blobs and hashes. The saved predicate, native finalizer and terminal projection also match fixed OpenScience `9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5` byte for byte.
- Real local native Claude ACP, Node REPL/TCP RPC, original SQLite Job/delivery repositories, producer capture, Version publication and FileExecutionStore. Model HTTP and remote transport are deterministic local fixtures. No external model API, SSH, CI, build, installation or Windows activity.

## Final cases

`final-vitest.json` and `final-vitest.log`: 2 passed, 6 existing cases intentionally filtered, no failures/global errors, process exit 0. Native terminal-failure case took 60.7s; repaired-tool case 5.7s.

1. `continuation-failure`: initial Turn submits one original Job and publishes receipt.json. The real harvested Job becomes success. Its original application continuation executes a real analysis Run and publishes result.json, then every subsequent local model response returns HTTP 400 `invalid_request_error`. The persisted application Turn is `failed`. Original default three delivery attempts are retained. Core ends **failed / cleanup confirmed**, preserving initial identity, with `owner-result-unavailable: Original Compute delivery requires attention`; it does not complete from the initial receipt or partial continuation artifact. The case allows 75s solely so original retries can settle before the Core deadline.
2. `tool-failure-repaired`: continuation first executes a real throwing Notebook Run, then another real Run reads the original final Job and publishes outputs. Real Run statuses are completed / failed / completed; the two original logical Turns both complete. Core completes with confirmed cleanup and its original identity. Existing full producer, fixed Version, Review, binary materialization, FileStore reopen/no redispatch and changed-evidence rejection assertions remain exercised.

`observed-journals/` retains read-only snapshots of actual atomic Session/journal/Notebook JSON during the final native-failure case; `observations-summary.json` summarizes them. These observations do not replace or mutate any owner state. The journal records one admitted budget unit. They are observations of the live fixture, not a simulated takeover or cleanup witness.

## Earlier bounded probes are not production red

The three earlier probes (`initial-*`, `after-tool-*`, `after-artifact-*`) used the existing 45s Core deadline and returned failed native Turn + pending delivery/attemptCount 2, followed by Core **interrupted / cleanup unknown** at deadline. Their assertion expecting immediate failed/confirmed was red because original delivery retries had not finished. All three fail closed; none shows completed. They must not be cited as a production regression or as proof of confirmed cleanup at 45s.

## Why the static concern did not reproduce

`persistent-candidate-owner.ts:1401` accepts an existing terminal Turn outcome in its waiting predicate, but it also requires every exact original delivery consumed. Original `background-result-delivery/continuation.ts:30–53` requires exact application attribution/IDs and a saved complete agent response; original native terminal projection (`runtime-session-projection.ts:174–207`) marks streaming responses error on native failure. In the real failure path the delivery is not consumed; original retry exhaustion yields needs-attention and the candidate owner fails. A failed Notebook tool by itself is deliberately not a failed Turn, as the positive control proves.

The test does not claim every possible provider, partial-stream/transport failure, artifact cleanup failure or dead-process recovery was exercised. There is no basis here to change original delivery semantics or require every historical Notebook Run to have succeeded.

## Checks

- Node compiled TypeScript: exit 0 (`typecheck-node.log`), no shared dependency build.
- Focused ESLint: exit 0 (`lint.log`). Prettier check and git diff --check passed.
- The six existing parameterized test identities remain unchanged; they were not rerun in this narrow probe.

Command: `node node_modules/vitest/vitest.mjs run src/main/earthnano/persistent-compute-candidate.integration.test.ts -t 'continuation-failure|tool-failure-repaired' --maxWorkers=1 --reporter=verbose --reporter=json --outputFile.json=<external>/final-vitest.json`.

Test-only follow-up commit: `b3cb05200837d0a0a4fe92368ff55cfec55e1f73`; worktree clean after commit.
