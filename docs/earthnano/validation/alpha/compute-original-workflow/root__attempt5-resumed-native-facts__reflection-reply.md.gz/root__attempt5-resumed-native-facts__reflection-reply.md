I'll start by reading the task material and the evidence.
Now the decisions and the rollouts.
Now the rollouts. Let me start with the two baselines.
Baselines both hit the producer-id rejection and recovered. Now the agg1 rollout (runner-up) and the domain-only candidates.
agg1 and dom1 confirm the producer-id effect. Now inv1, inv2, dom2, and the adopted agg2.
Now the adopted agg2 and dom2.
I've read all eight rollouts. Let me check the remaining decision files and the deliverables (one last confirmation that the outputs are the same across labels).
The adoption note says A/B map to agg2/agg1, so I'll check which harness each of the six candidates actually carries and how agg1's rollout diverges at the anchor points.
Key finding: the `rollouts/dom2.md` file is byte-identical to `rollouts/agg2.md` (same job id `df09617a…`, same blocks), even though `pool/dom2/` carries a different, unedited harness and `rollouts/agg2.md` equals `pool/agg2/rollout.md`. I'll treat what each file actually labels, and say so. Two quick byte-level checks to finish:
I have what I need from all eight trajectories. Writing the reflection now.
The outputs directory exists and is empty; this round's product is the committed reply itself, so I return it directly. Here is the reflection.

<edits>
component: instructions.md — "Publishing: the producer run is the run that wrote the file" section (producer-id attribution rule)
candidates: agg1, inv1, inv2 (adopted agg2 is the base harness: `pool/agg2/harness.diff` is 0 bytes and `pool/agg2/harness/instructions.md` is byte-identical to `context/base_harness/instructions.md`)
change: All three state that `write_artifact_file` binds each artifact to the `repl_execute` run that executed `fs.writeFileSync` for it, that the submit run and the `attachJob(...).result()` run own no files, and that the `producer_run_id` echoed inside the job result is the *submit* run and must not be used. agg1 recommends writing all three files in one call and publishing with that call's id; inv1 prescribes the split form (copies → P1, report → P2); inv2 states the rule per-file without a prescribed write layout. All quote the rejection string `Declared producer source belongs to another Notebook run: …` as the signal to retry with the named id.
observed: Every rollout whose harness lacks this text (base1, base2, dom2, and agg2, which is the unchanged base text) publishes first with the submit-run id and is rejected three times: base1 blocks 5–7 (`notebook-run-1792592547343-2` → `…562437-5`), base2 blocks 8–10 (`…547069-1` → `…563129-6` / `…564951-7`), dom2 blocks 3–5 (`…713844-21` → `…727757-24`). agg2 avoids it only by taking `fileEvidence.activityId` from the call that wrote the files in one pass (`…787529-29` and `…789675-31`, blocks 5–7) when it is not the submit run. Every rollout carrying the text publishes all three accepted on the first attempt with zero rejections: agg1 blocks 6–8, inv1 blocks 8–10, inv2 blocks 6–8. The same rule is stated in two forms and both worked: one writing call / one id (agg1 block 4 → id `…788205-30`, three accepted publishes) and two writing calls / two ids (inv1 blocks 8–10 with P1 `…697487-14` and P2 `…699180-16`; inv2 blocks 6–8 with one id).
verdict: helped

component: instructions.md — "Harvest paths" section (literal `'../' + <featured path>` from the `data/` cwd, select by `endsWith`, never an absolute session/output root)
candidates: agg1, inv2 (near-verbatim sentence), inv1 (same rule plus extra fixture facts)
change: Replaces the base's instruction to "rebuild the path with plain string concatenation, never with absolute roots or `path.join` against `local_output_root`" — which named `path.join` as the hazard but left the cwd ambiguous — with an explicit statement that the REPL cwd is the notebook's `data/` directory, that harvested files sit one level up, and a `'../' + featuredPath` snippet, with `find(p => p.endsWith(...))` selection instead of positional indexing. inv1 adds example paths and the exact bytes/size of the fixture files.
observed: Only one divergence exists in the record. dom2 block 4 (base harness text) builds `path.join(root, '..', 'hpc/<job>/featured/metrics.json')` against the absolute `local_output_root`, hits `ENOENT` (`…/notebooks/compute-project/hpc/<job>/featured/metrics.json`), and recovers in block 6 with the literal `'../hpc/...'` form. Every rollout carrying the explicit rule hits the file on the first read: agg1 block 4, inv2 block 4, inv1 block 4. The base rollouts base1 (block 3) and base2 (block 4) also used the literal form and did not fail, so the rule is not what made them succeed — they had already reached the right path from the base text. The difference rests on a single failed rollout (dom2), and two of the three candidates carrying the edit (agg1, inv2) changed many other things at the same time, so this rollout cannot isolate the path sentence from the rest of their text.
verdict: confounded

component: instructions.md — "What counts as done" completion checklist and the Turn 1/Turn 2 protocol (submit once positionally, end the turn at the receipt, require `result_final === true`)
candidates: agg1, inv1 (agg2 also carries this, in a shorter "Execution discipline / Check state before acting" form; it is the base text)
change: agg1 and inv1 promote the base's prose bullets into a numbered seven-item completion gate and an explicit two-turn script with the exact submit call and a `if (res.result_final !== true) throw` continuation. agg2 keeps the shorter rule ("End the initial turn after the receipt", "require finality") without a checklist.
observed: No behaviour difference is attributable. Every one of the eight rollouts — base1 block 3, base2 block 3, agg1 block 3, inv2 block 2, inv1 block 3, dom2 block 3, agg2 block 3 — submits exactly once positionally and ends the initial turn at the receipt; every continuation calls `attachJob(<id>).result()` and each result reports `result_final: true, status: success, exit_code: 0`. No rollout issued a `.status()` probe in turn 1, and none resubmitted. The base text without the checklist already produced this in 2/2, so the strengthened form is not the cause of any observed difference.
verdict: no observed effect

component: instructions.md — byte-copy / derived-report rules (Buffer passed unchanged to `fs.writeFileSync`; report is exactly the three numeric fields; PNG copied not redrawn) and the `Buffer.compare` verification step
candidates: agg1, inv1, inv2 (agg2 keeps the base wording and adds the `Buffer.compare` assertion "Optionally")
change: agg1 additionally prescribes `JSON.stringify({count, sum, mean})` for the report; inv2 adds "no trailing newline" to the base's "Do not re-serialize, re-indent, re-encode or append a newline"; inv1 and agg2 make the byte-identity check a step/optional assertion.
observed: The deliverables do not separate: every label's `metrics-source.json` is the 18-byte byte `{"values":[2,4,6]}` and every label's `research-results.json` carries exactly `count/sum/mean`, with the PNG at 68 bytes copied from the fixture. The only visible variation runs the other way from the edits: the two rollouts that produced a 43-byte report (base2 block 6, `JSON.stringify(report, null, 2) + '\n'`; inv2 block 4, `JSON.stringify({count, sum, mean}, null, 2) + '\n'`) did so under both base and edited text, and inv2's own "no trailing newline" sentence did not prevent it. The byte-identity outcome is identical in base rollouts that had no such stated check (base1 did not call `Buffer.compare` and still wrote exact bytes) and in those that did (agg2 block 2, `metricsIdentical: true`).
verdict: no observed effect

component: instructions.md — host/local workspace facts in inv1 (exact harvested bytes `{"values":[2,4,6]}`, 18/68-byte sizes, "Verified result: count = 3, sum = 12, mean = 4", default `../hpc/<job>/featured` paths)
candidates: inv1
change: Inserts the fixture's answer and file layout into the harness, alongside the instruction to still compute from the array.
observed: No execution contrast is visible: inv1 block 4 reads the actual `values` array and computes `count/sum/mean`, so the memorized answer did not replace the computation in this run; the deliverables are identical to the other labels. inv1 simultaneously carries the path rule, the producer-id rule and the checklist, so its one trajectory cannot isolate any contribution of these facts.
verdict: confounded

component: instructions.md — shape change with no content retained (dom1, dom2; `pool/dom1/harness/instructions.md` and `pool/dom2/harness/instructions.md` are both 136 bytes, the bare `Read the frozen task inputs…` line)
candidates: dom1, dom2
change: Strips every rule from the harness, leaving only the base one-line instruction.
observed: The stripped harness changes nothing observable relative to base. dom1 and dom2 both submit once, end turn 1, require `result_final`, and deliver the same three files; dom2 shows the same submit-run-id rejections as base1/base2 (blocks 3–5), and dom1
dom1 (bare harness) shows the same ENOENT at block 4 as dom2, then recovers. Resuming the edit block from the stripped-harness row.

<edits>
component: instructions.md — "Publishing: the producer run is the run that wrote the file" section (producer-id attribution rule)
candidates: agg1, inv1, inv2 (adopted agg2 carries the base text: `pool/agg2/harness.diff` is 0 bytes and `pool/agg2/harness/instructions.md` is byte-identical to `base_harness/instructions.md`)
change: All three state that `write_artifact_file` binds each artifact to the `repl_execute` run that executed `fs.writeFileSync` for it, that the submit run and the `attachJob(...).result()` run own no files, and that the `producer_run_id` echoed inside the job result is the submit run and must not be used. agg1 recommends writing all three files in one call and publishing all with that call's id; inv1 prescribes the split form (copies → P1, report → P2); inv2 states the rule per-file with no prescribed write layout. All quote `Declared producer source belongs to another Notebook run: …` as the retry signal.
observed: Every rollout whose text lacks this rule publishes first with the submit-run id and is rejected three times — base1 blocks 5–7 (`notebook-run-1792592547343-2` → `…562437-5`), base2 blocks 8–10 (`…547069-1` → `…563129-6`/`…564951-7`), dom1 blocks 10–12 (`…681963-10` → `…699967-17`/`…701942-18`), dom2 blocks 3–5 (`…713844-21` → `…727757-24`). agg2 (base text) never attempts the submit id: it takes `fileEvidence.activityId` from the call that wrote the files (`…787529-29`, `…789675-31`) and publishes all three accepted first try (blocks 5–7). Every rollout carrying the rule publishes all three first try with zero rejections: agg1 blocks 6–8, inv1 blocks 8–10, inv2 blocks 6–8. Both stated forms worked: one writing call / one id (agg1 block 4 → `…788205-30`) and two writing calls / two ids (inv1 P1 `…697487-14`, P2 `…699180-16`; inv2 one id).
verdict: helped

component: instructions.md — "Harvest paths" rule (literal `'../' + featuredPath` from the `data/` cwd; select by `endsWith`; never build the path from absolute session/output roots)
candidates: agg1, inv2 (near-verbatim), inv1 (same rule plus extra fixture facts)
change: Replaces the base's "plain string concatenation, never absolute roots or `path.join` against `local_output_root`" wording, which names the hazard but leaves the cwd ambiguous, with an explicit cwd statement, a one-line `'../' + featuredPath` snippet, and suffix selection instead of index selection. inv1 adds example paths and fixture byte sizes.
observed: The one divergence in the record is the stripped harness, which retains no path rule at all: dom1 block 4 and dom2 block 4 both join the absolute `local_output_root` with `'..'`, hit `ENOENT` at `…/notebooks/compute-project/hpc/<job>/featured/metrics.json`, and recover in block 6 / block 6 respectively with the literal form. Every rollout carrying an explicit path rule reads on the first attempt (agg1 block 4, inv2 block 4, inv1 block 4), and so do base1 block 3 and base2 block 4, which used the literal form under the base text. Since base rollouts succeed without the edit, the success side does not discriminate; only the dom failures do, and no candidate isolated the path sentence from its other additions.
verdict: confounded

component: instructions.md — completion checklist ("What counts as done") and the Turn 1/Turn 2 protocol (submit once positionally, end turn at the receipt, require `result_final === true`)
candidates: agg1, inv1 (agg2 keeps the base's shorter "Execution discipline / Check state before acting" bullets)
change: agg1 and inv1 turn the base's prose bullets into a numbered seven-item completion gate plus an explicit two-turn script with the exact submit call and a `if (res.result_final !== true) throw` continuation.
observed: No attributable difference. All eight rollouts submit exactly once positionally and end the initial turn at the receipt (base1 block 3, base2 block 3, agg1 block 3, inv2 block 2, inv1 block 3, dom1 block 3, dom2 block 3, agg2 block 3), and every continuation attaches the saved id and observes `result_final: true, status: success, exit_code: 0`. No turn-1 `.status()` probe, no resubmission anywhere. The base text without the checklist already produced this 2/2, and the stripped harness produced it 2/2.
verdict: no observed effect

component: instructions.md — byte-copy / derived-report rules and the `Buffer.compare` verification step
candidates: agg1, inv1, inv2 (agg2 keeps the base wording and adds the assertion as "Optionally")
change: agg1 prescribes `JSON.stringify({count, sum, mean})`; inv2 adds "no trailing newline"; inv1 and agg2 make the byte-identity check explicit.
observed: Deliverables do not separate — every label's `metrics-source.json` is the 18-byte byte `{"values":[2,4,6]}` and every `research-results.json` carries exactly count/sum/mean; all PNGs are 68 bytes copied from the fixture. The only variation runs against the edits: the two 43-byte reports come from base2 block 6 (`JSON.stringify(report, null, 2) + '\n'`) and inv2 block 4 (`JSON.stringify({count, sum, mean}, null, 2) + '\n'`), so inv2's own "no trailing newline" sentence did not prevent it. Exact bytes are produced both with the stated check (agg2 block 2, `metricsIdentical: true`) and without it (base1 block 3, no `Buffer.compare`, exact bytes).
verdict: no observed effect

component: instructions.md — host/local workspace facts in inv1 (exact harvested bytes, 18/68-byte sizes, "Verified result: count = 3, sum = 12, mean = 4", default `../hpc/<job>/featured` paths)
candidates: inv1
change: Inserts the fixture's answer and layout into the harness while still telling the agent to compute from the array.
observed: inv1 block 4 reads the real `values` array and computes the numbers, so the answer was not substituted for the computation in this run; its deliverables are identical to every other label. inv1 also carries the path rule, producer-id rule and checklist, so its single trajectory cannot isolate these facts.
verdict: confounded

component: instructions.md — shape with all rules removed (dom1 and dom2 harnesses are both the bare 136-byte line)
candidates: dom1, dom2
change: Strips every rule, leaving only "Read the frozen task inputs carefully. Follow the task requirements, verify the deliverables and write the requested files under OUTPUT."
observed: Deliverables unchanged — both submit once, end turn 1, require finality, and produce the same 18/29/68-byte exact set. The stripped text also reproduces both base failure modes: dom1 block 4 / dom2 block 4 ENOENT from absolute-path rebuilding, and dom1 blocks 10–12 / dom2 blocks 3–5 submit-id publish rejections. That is consistent with the base text, not a new effect.
verdict: no observed effect

component: instructions.md — overall harness length and framing (40 → 38 to 125 lines; added headers, checklists, code blocks)
candidates: agg1 (112 lines), inv1 (125), inv2 (38), dom1/dom2 (1), agg2 (40)
change: Varies how much procedural text and structure surrounds the task prompt.
observed: No run's behaviour tracks length. The one-line and 125-line harnesses both deliver all three artifacts and hit the same two failure modes when the specific rule is absent; the 38-line inv2 and the 112-line agg1 both publish first try because both name the producer rule. This row records that length itself is not the lever, as a control for the rule-level rows above.
verdict: no observed effect
</edits>

<experience>
cue: When a harness describes an identifier the agent must supply from outside the prompt itself — a producer/owner/attribution id, a session handle, a "use the one returned by the tool" reference — and the same tool surfaces several run ids across the workflow, check whether the harness names which specific call's id is meant and whether it says the tempting id (the first one, the one echoed in a result) is wrong.

I still owe the `<experience>` properties: `lesson`, `evidence` and `confidence`. Here are the remaining lines:

lesson: In the harness's "Publishing" component (the producer-run section), write the binding rule as an explicit predicate, not a reference — "`write_artifact_file` binds each file to the `repl_execute` run whose code executed the `fs.writeFileSync` for that file; the submit run and the `attachJob(...).result()` run wrote no files and cannot publish, including the `producer_run_id` echoed inside the job result" — then add the one mechanical layout that makes it checkable (write all deliverables in a single `repl_execute` call, record that call's `fileEvidence.activityId`, publish every file with it), and name the rejection string `Declared producer source belongs to another Notebook run: <runId>` as the signal to retry with the named id and disclose it. Verify by checking the harness text against the rollouts it would govern: any run that lacks the predicate will publish with the submit id and be rejected; any run that has it publishes on the first attempt.

evidence: The producer-run row only. Absent the rule, four rollouts publish with the submit-run id and take three rejections each (base1 blocks 5–7, base2 blocks 8–10, dom1 blocks 10–12, dom2 blocks 3–5); present, three rollouts publish all three files first try with no rejection (agg1 blocks 6–8, inv1 blocks 8–10, inv2 blocks 6–8), and agg2, which is the unchanged base text, succeeds only because it happens to take `fileEvidence.activityId` from the writing call (blocks 5–7) rather than the submit id. Both the single-call and split-call layouts are demonstrated by accepted publishes (agg1 block 4 → one id for three files; inv1 blocks 8–10 → P1/P2 split), so the lesson rests on the predicate, not on one layout. The path, checklist, byte-copy and fixture-fact rows are not used: they are `confounded` or `no observed effect`, and the adoption of agg2 (base harness) supplies no contrast at all.

confidence: medium — the direction and mechanism are consistent across seven rollouts and the rejection string is unambiguous platform evidence, but the causal attribution rests on comparing separate runs, not on a single run that toggles only the producer sentence; the stripped dom1/dom2 harnesses simultaneously lack the path rule, so the producer rejection is the only failure common to every rule-absent run and is the cleanest single observation, not an isolated one.