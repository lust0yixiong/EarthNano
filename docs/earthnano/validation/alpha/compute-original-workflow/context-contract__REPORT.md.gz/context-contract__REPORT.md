# Immutable invocation context files

Commit: ae21e387156aae4551ba709e1895571119499ab3
Branch: feat/alpha-invocation-context-files
Base: 99122746f1b7f39c0decc74dbbf4497f9c36a36f
Worktree: /Users/yxmac_mini/Developer/EarthNano-worktrees/alpha-ci-runtime (clean after commit)

Only four authorized files changed:
- src/main/earthnano/candidate-snapshot.ts
- src/main/earthnano/candidate-snapshot.test.ts
- src/main/acp/claude-candidate-preparation.ts
- src/main/acp/claude-candidate-preparation.test.ts

CandidateInvocation now accepts optional readonly contextFiles?: readonly CandidateTextFile[]. Normalization includes it only when the property exists; absence preserves the old exact canonical envelope/digest. TaskSnapshot, full original Session evidence and ExecutionRequest identity are unchanged by this primitive.

The existing portable text/path normalization now checks task files, context files and binary asset destinations together, including Unicode/casefold and prefix collisions. Materialization preflights original file/turn resource budgets including text, then writes context to INPUT at the frozen relative paths using the original exclusive writer, readback, read-only directory lifecycle and digest manifest. There is no extra context/ prefix, parser shell expansion, host target choice or extra state registry.

Native preparation's exact expected manifest includes context text entries. The original text byte/UTF8/identity reader verifies them; unexpected entries remain errors. @ and backticks are valid in evidence file contents; native prompt guards and tool gate permissions remain unchanged.

Validation:
- red.log: old production implementation plus added tests: 7 failed / 99 passed, process 1. The seven failures show unknown contextFiles rejection, not an unrelated runtime failure. The legacy envelope golden already passes on old implementation.
- green.log: 3 suites / 108 tests passed, process 0. Includes unchanged claude-candidate-preparation.integration.test.ts real native runtime with local model fixture.
- typecheck.log, typecheck-web.log, typecheck-sandbox.log: full existing node/web/sandbox compiled TypeScript checks exit 0, no diagnostics.
- lint.log: four changed files exit 0.
- Prettier check and git diff --check exit 0.

New regressions cover exact legacy envelope/digest absence, immutable freeze/resolve/reopen, sorted context identity, Unicode/CRLF/expansion-syntax byte preservation, real INPUT digest/size manifest, cancellation before allocation, path/Unicode/prefix/task/asset collisions, NUL/surrogate rejection, original combined turn budget refusal before asset owner I/O, and native-preparation byte/digest/missing/extra manifest tampering. Original test titles and assertions were preserved.

Scope limits:
Binding opt-in contextFileMode and exact legacy resume reconstruction are owned by root and not in this commit. This commit alone does not change fresh method prompts or prove the retained 547k reflection can complete; it provides the immutable on-disk capability used by that caller change. No full build, shared dependency modification, API/paid model call, remote SSH, CI or Windows work was performed.

