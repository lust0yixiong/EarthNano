# Ordinary CLI / Web scientific entry review at 99122746f

Read-only source review on 2026-10-21. Reviewed exact clean HEAD 99122746f1b7f39c0decc74dbbf4497f9c36a36f in /Users/yxmac_mini/Developer/EarthNano-worktrees/alpha-method, against fixed OpenScience 9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5 available in the repository object database. No API requests, model calls, tests, builds, SSH, Windows work or production edits were performed.

## Finding

No concrete loss or missing assembly of the original ordinary CLI/Web Notebook/Compute task entry was found in the inspected call paths. This is source evidence, not a claim that the full installed CLI/browser runtime has been exercised at this head. The existing desktop optimization acceptance does not substitute for an actual public HTTP/CLI smoke.

## Actual ordinary entry chains

1. CLI: packages/open-science/cli.mjs runTaskCommand line 1628 calls the original SDK client.startRun with project, prompt, cwd/session, permissions, skills, plan/review/specialist/delegation configuration and Compute enabled/selected host preferences. Wait/cancel continue through the original Run API (1666–1674). The packages/open-science directory has no source diff against the fixed upstream.

2. Public HTTP: web-service/http-server.ts lines 1166–1183 parse POST /api/v1/runs, recheck external authorization and use the original idempotent Task submission. HeadlessTaskApi.startRun (task-api.ts 532–533) delegates directly to the original TaskRunner.startRun; no candidate profile/config projection intervenes. get/wait/cancel remain the original Run façade (536–545).

3. Backend construction: node-entry.ts 593 invokes createCoreRuntime(headless:true); 665–671 supplies the resulting original runtime interfaces directly to createWebServiceController. That controller constructs HeadlessTaskApi with applicationCommands.task, taskAgent, taskControls, computePreferences and the original FileTaskRunJournal (web-service/index.ts 118–131). core-runtime.ts 15–34 builds createApplicationModules for both hosts; only Electron transport installation is optional. ipc-application-composition.ts returns the same agentWorkflows.taskAgent at 883 and original sessionEnabledComputeHostsOwner at 890.

4. Original Task/ACP owner: composition/agent-completion.ts 232–239 still constructs createAcpTaskAgentPort(runtime, original createSessionWorkflow, notifications, archive and target resolvers). HeadlessTaskApi routes session create/resume/prompt/cancel directly to that port (task-api.ts 142–160); original Session admission, artifact finalization and Review owners remain on the façade. TaskRunner remains the original orchestrator.

5. Shared Core: createAcpRuntime now universally installs createAcpExecutionBoundary/createSessionExecutionHost at runtime-composition.ts 1021–1052, therefore this applies to ordinary CLI, browser Send and desktop Send alike. TaskRunner's ownerCompletion bridge links the original execution ID/cancel/settled lifecycle to the Run journal (task-runner.ts 2002–2080). runtime-coordinator.ts 1594–1603 passes the original request/operation/runtimeReviewOwner/ownerCompletion/dispatch into that boundary. The original dispatch continues at 1548–1554; the Core does not replace the original runtime or tools.

6. Ordinary metadata versus candidate constraints: session-execution-host.ts 143–175 freezes the rich original request/configuration rather than rewriting it for dispatch. It creates role task, automation/interactive origin based on the original Task/renderer review owner, and retains permissionPrompts semantics (202–212). Its per-attempt journal/budget adds durable identity; the ordinary request is not turned into workspace-only/provider-only or Compute trial policy. Target/provider configuration remains original; desktop optimization's custom/messages/native-Claude capture checks do not run in this ordinary chain.

## Notebook / R / RPC / Compute assembly

The original root-session Notebook wiring was extracted into acp/notebook-binding.ts, not dropped. It still issues the original Session RPC capability (32–35), runtime-binding admission (24–31), Session alias/release/specialist authorization, artifact turn binding, prepare/register Notebook inputs and handoff context (39–60). runtime-composition.ts uses that helper with the same original arguments; the diff shows these were moved from the inline object rather than replaced with the candidate allowlist.

composition/notebook-runtime.ts and notebook-environment.ts are byte unchanged against the fixed upstream, including per-language runtime enablement/catalog and original R recovery/sandbox paths. No R-specific CLI/Web exclusion was introduced.

composition/notebook-bridge.ts still sets the original NotebookRuntimeService control-connection resolver. The new optional resolveControlPolicy is resolved by the host-owned candidate router; ordinary Sessions return undefined after original authority classification. issueControlConnection retains the original main/delegate method set when no policy is present. Restricted trial policy is an intersection with that set; local-rpc-server.ts guards scoped invocations/global details writes only under an existing controlPolicy. It does not globally downgrade ordinary CLI/Web computeCall.

Original Compute production owners are composed in the shared graph. The Task API receives the original enabled-host preference/reservation owner; it does not copy a source grant to a private Session. A normal Task remains subject to original grants/approvals. The deny-unresolved trial path cannot be generalized into an ordinary CLI/Web restriction.

The ordinary Web renderer RPC route also remains: http-server.ts 1544–1548 validates the original Web channel catalog, then dispatches through localWeb/remoteWeb views. The existing renderer ACP and Notebook contracts still declare acp:send-prompt and notebook:execute. This differs from the public text-oriented Task API, as it did upstream.

## Direct original comparison evidence

git diff --numstat 9e18... -- the following paths was empty:
- packages/open-science (entire package)
- src/main/node-entry.ts
- src/main/core-runtime.ts
- src/main/web-service/http-server.ts
- src/main/web-service/index.ts
- src/main/composition/agent-completion.ts
- src/main/composition/notebook-runtime.ts
- src/main/composition/notebook-environment.ts

The nonempty ordinary integration diffs were inspected for task-agent-port/task-prompt-execution, task-runner, task-api Reviewer linkage, runtime-composition, notebook-bridge, IPC shared graph and command composition. They add shared execution/settlement and private candidate routing rather than remove the upstream entry points.

## Scope distinctions; not new requirements

optimization:previewSweep/startSweep/start/get/latest/stop/resume are explicitly ELECTRON_NATIVE_COMMAND_NAMES (application-command-composition.ts 165–172). No CLI optimization command or public HTTP optimization endpoint was added. This is the established scope of the new desktop optimization product entry, not a loss of a pre-existing upstream optimization endpoint. It does not make the original public run/Session/Artifact/Plan/Compute interfaces unavailable.

The public Task API/CLI does not expose every rich renderer interaction or native document rendering action. The original node-entry remote desktop adapters already require a connected desktop for native file/shell interactions and DOCX/PPTX page rendering (565–590); these unchanged limitations cannot be described as EarthNano regressions. Likewise, absence of a new Web/CLI optimization UI is not an ordinary-science functionality defect.

## Minimal existing validation suggestions

These are suggested commands only; none was executed by this review. Use the existing read-only node_modules, not npm scripts that may build/install packages. Clear live opt-in variables and keep maxWorkers=1 for global singleton fixtures.

1. Original public entry contract/caller/idempotency and startup assembly:

```sh
env -u EARTHNANO_LIVE_DEEPSEEK -u EARTHNANO_LIVE_DEEPSEEK_KEY_FILE node node_modules/vitest/vitest.mjs run packages/open-science/cli.test.ts packages/open-science/client.test.ts src/main/web-service/http-server.test.ts src/main/web-service/task-api.test.ts src/main/node-entry.test.ts --maxWorkers=1
```

Existing cases cover host flags, resume, permission controls, wait/cancel authority, remote authorization lifetime, caller context and automatic Review abort/cleanup. These use test ports and do not prove a packaged native CLI research run.

2. Original Task/Notebook/runtime connection and shared Core lifecycle:

```sh
env -u EARTHNANO_LIVE_DEEPSEEK -u EARTHNANO_LIVE_DEEPSEEK_KEY_FILE node node_modules/vitest/vitest.mjs run src/main/tasks/task-runner.test.ts src/main/acp/task-agent-port.test.ts src/main/acp/runtime-composition.test.ts src/main/notebook/local-rpc-server.capabilities.test.ts src/main/earthnano/desktop-candidate-owner-routing.test.ts --maxWorkers=1
```

3. Existing local native ordinary Send/Core evidence, intentionally excluding the paid opt-in test:

```sh
env -u EARTHNANO_LIVE_DEEPSEEK -u EARTHNANO_LIVE_DEEPSEEK_KEY_FILE node node_modules/vitest/vitest.mjs run src/main/earthnano/ordinary-session-execution.integration.test.ts --maxWorkers=1 -t 'runs native ordinary Send|cancels the exact native ordinary Send|reconciles original interrupted owner'
```

That last fixture uses real native CLI with local model transport and original Core/Session evidence, but enters ordinary Send directly, not through an actual external HTTP client. A true installed public CLI scientific round trip remains a distinct coverage item; this review does not invent a missing implementation to fill that test gap or authorize a paid run.

