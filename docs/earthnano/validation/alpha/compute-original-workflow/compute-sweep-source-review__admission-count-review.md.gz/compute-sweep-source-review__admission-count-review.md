# Compute sweep admission-count assertion review

Read-only review, 2026-10-21. No tests, model calls, builds, CI, Windows or SSH were run; no repository source was modified.

## Conclusion

The Compute sweep acceptance assertion `admitted === preview.minimumExecutions` is too strict for a successful original-method run that legitimately retries a proposal. For this full-path acceptance, use:

```ts
expect(completed.budget.limit).toBe(request.executionLimit)
expect(completed.budget.admitted).toBeGreaterThanOrEqual(preview.minimumExecutions)
expect(completed.budget.admitted).toBeLessThanOrEqual(request.executionLimit)
```

This changes only the acceptance count predicate. Preserve the original comparison/assessment criteria, every actual attempt record, budget accounting, zero-active condition, producer assertions and confirmed cleanup. Do not truncate records to 18, drop rejected attempts, coalesce executions, force first-attempt success or increase the configured limit during the run.

## Fixed original-source evidence

The original checkout /Users/yxmac_mini/Developer/EarthNano-validation/alpha-r-evidence/harness-original is exactly Harness commit 1cfe254e8d25b15f37048c3730134686abe60335 (rev-parse verified). Its recorded baseline report identifies tree edc756a4d03a2826a248115482084a176e60e751.

- Original harness2/core/recursion.py:17–18 explicitly describes 4k rollouts, 3k improvement stages and one retry for invalid proposals.
- Original recursion.py:36 sets STAGE_ATTEMPTS=2; lines 180–194 issue a separate call labeled .a1/.a2 with the rejected-attempt feedback.
- Original recursion.py:205–229 retries missing workspaces, empty/invalid/off-surface harnesses; lines 201–203 accumulate spent calls/cost. Thus logical stage count is not actual invocation count.
- Original harness2/core/proposer.py:150–154 separately permits transport attempts; 166–168 retries empty output, 185–188 records failures, and 197–207 reports actual attempts.
- Original recursion.py SHA256: b299813b5334f2c0f89024a7f14162f0fdd5418ebd4413be93920b5334a204c1.
- Original proposer.py SHA256: 475ef49d72228e249d7172d793f8362913774412402dfd259ae6e01c6586e175.

The current integration preserves those semantics through core/recursion.py:187–207 and PortMethodExecution._call:239–255. Every attempt enters _record, uses a new request key, retains retryOfExecutionId, and cannot reuse the prior execution identity (method_execution.py:135–158). The original platform control errors/unknown cleanup still stop admissions (170–199); this assertion change must not bypass them.

## Existing EarthNano contract and test evidence

- src/shared/earthnano/optimization-sweep.ts:66 calls minimumExecutions first-attempt capacity only and says retries consume the shared limit.
- Lines 185–186 explicitly say failure/fallback can use fewer admissions and retries more. minimumSweepExecutions is capacity planning, not an exact execution-count guarantee.
- For this one-task, parallel k=2, two-assessment full path, the formula yields 2 + (12+1+1) + 2 = 18. A valid retry may make 19 or 20 within the already configured cap.
- execution-core.ts:197–198 rejects a new admission at the limit; line 244 increments the original admission reservation. State validation checks each budget admission counter against all actual records (90–117).
- desktop-optimization-manager.ts:552–567 projects admitted from the complete records.length and completed from all original terminal phases. No filtered or synthetic count is needed.
- Existing binary desktop e2e/earthnano-notebook-optimization.spec.ts:667 asserts admitted <= optimizationExecutions, not equality to a preview count. It retains complete journal/execution-ID equality (669–671). Its live run has a preconfigured retry allowance (line 29 uses 24).

The current Compute test's journal length == admitted, active == 0, completed == admitted, and every-record completed + cleanup confirmed predicates can remain unchanged for the reported retry: a completed native proposer invocation can produce a harness rejected later by original method validation. A method-level rejected proposal is not automatically a failed Core execution.

Separate caveat: original transport retry can include an actual failed Core attempt. Do not rewrite such an attempt to completed if observed; report it and decide the acceptance scope explicitly. The requested narrow correction does not silently widen the existing phase predicate or weaken cleanup.

The lower bound is appropriate to this intended complete full-path acceptance. It is not a universal assertion for every original method outcome: an allowed fallback may omit calls after evidence construction failure. The original shared contract already states that caveat. Preserve the acceptance's role, nonfallback-selection and output/assessment coverage rather than using count alone to claim all stages ran.

## Evidence limits

I reviewed source and the fixed original checkout, not the current live journal or model payload. Root reported the second live run's two completed baselines and later legitimate additional proposer attempt; those observations are not independently re-executed here. The first live object-parameter failure remains a separate retained failure and must not be relabeled by this test correction.

