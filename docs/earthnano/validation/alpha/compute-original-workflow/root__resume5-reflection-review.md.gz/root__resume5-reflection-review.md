# Resume5 reflection/experience read-only review

Reviewed clean905eb504cc56cf1f5bed323215a83ac07fb04b77 and preserved actual run0e66ecad-1847-498f-906c-2c86924cd66e. No code/state changes, API or CI reruns. The old test still exits1 at its unconditional experience assertion.

## Conclusion

This is an acceptance-fixture overconstraint, not missing reflection in resume. Original attempt5 already had summary.task.experience absent, and the same reflection record is byte-for-byte unchanged after resume: a35e05c7-2d3e-4492-adc8-faa0a933f82f, phase completed, cleanup confirmed, evidence complete. It is the sole reflection record and remains routed to the original task's agg mode scope in request-tasks.json. The original reply artifact content exactly equals the recorded reply and matches both Core artifactRef SHA and persisted evidence checksum.

Important factual correction: actual reply is NOT literal NO_ENTRY (it has0NO_ENTRY mentions). It contains2opening <experience> tags and0closing </experience> tags. It includes proposed cue/lesson/evidence prose, but the original _EXP complete-block regex does not match. Do not claim a well-formed lesson was retained or mutate the raw reply to NO_ENTRY.

## Original behavior proof

The local original Harness checkout is exact1cfe254e8d25b15f37048c3730134686abe60335. Original selection._EXP regex was extracted as its AST assignment and evaluated against the real reply without executing any model/scheduler or writing into the experiment: no match. Original selection._distil returns{}when no complete block matches (and also returns{}when required fields are missing). Its response-processing/distillation tail is byte-identical to current; only the shared execution-port call plumbing differs before that tail.

Original library.py is byte-identical to current. has_experience requires nonempty cue/lesson/evidence; the actual cached selections.agg.experience={}fails this original predicate. Original scheduler fresh retention only adds a selected harness when has_experience is true. Its resume _restore_libraries function is byte-identical to current and likewise skips a task without retained experience. The original Library remains entries[]/files[]; this is allowed for NO_ENTRY and other original non-distillable replies. Do not change the scheduler/recursion/selection/reflection/Library behavior to force a lesson.

The EarthNano sweep wrapper earthnano_sweep.py:272–277 explicitly includes the completed reflection record in the projected mode result based on its original taskRecords/scope. Current domain-results.ts:112–115 deliberately returns task+selection without experience whenever the Library has no admitted entry. domain-results.test.ts:263 already asserts empty Library produces no experience and no fabricated reflection provenance. This branch is shared by fresh and resume; it is not a resume-specific omission.

## Minimal recommendation

Change only the acceptance assertion: independently verify the original completed/confirmed reflection record and exact immutable reply artifact. When the task has a retained Library entry, keep the strict summary.experience original-ref/selected-harness/Library checks. When no entry was distilled, assert the original cached distillation result is empty/non-retainable, Library remains empty for this one-task fixture, and summary.experience is undefined. For this actual instance verify the unmatched complete-block structure, not a fabricated literal NO_ENTRY reply. Keep all Core/budget/8Job/producer/content/PNG/native Read/independent assessment/configuration/reopen assertions unchanged.

No production summary field is needed: reflection completion and retained experience are separate facts. A model may finish a valid reflection execution while producing no Library-admissible lesson. Existing positive retained-experience tests must continue to require full immutable provenance; existing empty-Library guard must continue to forbid invented experience.

## Actual run and zero-fee completion

The manager is completed at22/24 (20old+2reviewers), with7newDeepSeek requests and0proxy rejection.8original task outputs are present in this report. Baseline/candidate independent pass and artifact passed are original observed results, not a retroactive change to test status. Corrected fixture can reopen this already completed original manager and read original evidence with0newCore/API/Job: completed manager.resume/get returns the cached projection rather than execute. Do not call startSweep or change the original manifest/budget, and label any zero-fee tail validation separately from the old failing log.

Structured evidence and exact source hashes: resume5-reflection-review.json. Original attempt5/resume5 report files were not modified.
