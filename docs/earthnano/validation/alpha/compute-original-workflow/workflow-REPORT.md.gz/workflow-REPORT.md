# 原 Compute workflow integration：范围 A 本地证据

基线67207ef3c6149f78f161591617bd03a63ab2484e；branch test/alpha-compute-full-workflow。只新增 persistent-compute-workflow.integration.test.ts 与 test/earthnano/compute-transport.ts，无生产diff。root负责将这两个文件登记到既有module inventory；原B journal fixture未修改。

## 实际走通的原链

真实迁移SQLite、原PermissionGrantRegistry→Compute adapter→ComputeApprovalBroker、原Session enabled hosts/reservation/private persistence、原Core/FileExecutionStore、原pinned native Claude及Node REPL/RPC。除模型使用固定本地Messages外，不替换任何submit或业务状态owner。

成功场景的原Project submit_job grant精确到ssh:fixture，broker仍核当前Host row。JobRepository使用原OptionalSecureStorageStringProtection和本地AES-256-GCM cipher端口：真实保护/解保护路径被调用，数据库原始command/stdoutTail不含fixture明文字节；此端口不代表OS钥匙串或生产密钥管理。

一个原ComputeExecution/DispatchTracker同时供Service、原持久queue、dispatcher、默认poller/reaper使用。原queue尚未启动时，模型真实submitJob创建queued row，getJobStatus确认runtime_stopped且result_final=false，transport零调用。启动原createComputeJobRuntime后，其原queue reconciliation读真实Session持久policy并自动提升、调度。真实原callbacks观测queued/submitted/running/success；默认poller在原15秒tick读取模拟远端协议；默认harvest做原枚举、前后inode/mtime/size一致性、字节预算、实际下载、目录发布、checksum和Compute file-evidence；原notifier写入harvested/notified，原result adapter/Delivery触发真实私有第二Turn。

第二Turn通过原attachJob(...).result()读取完整结果与原harvested文件，在实际Node进程从JSON values[2,4,6]计算count3/mean4，并复制实际PNG字节为新本地产物。原producer捕获、write_artifact_file、Version/PNG materialize、完整性Review和独立确定性json-value Review都真实提交；初始Core身份与单次预算保持，delivery consumed。

## 仅有的运输模拟及能力边界

ComputeConnectionBroker.acquire→lease.run/upload/download是唯一远端替身。它解析原dispatcher传入的base64 command/launcher，不执行它们，写入owned临时remote目录的固定JSON/PNG及协议文件；按原随机nonce/实际Job UUID返回机器协议；枚举与stat来自这些实际本地文件，下载执行真实受限字节复制。未知命令拒绝，不提供job_cleanup、kill或取消确认。数字900001只是dispatcher线协议字段，不是宿主或远端PID、存活证据、owner witness或cleanup证据。

因此这是**原全状态owner本地联调**，不是Linux脚本/远端进程、SSH/SCP认证、Slurm/HPC或远端科学计算验收。远端metrics由fixture给定而非command执行产生；已证明的计算因果仅为真实Node分析实际harvested字节。原cancel/reaper由原runtime构造并start/stop，但本轮happy没有取消operation，不声称覆盖其远端取消执行；原六生命周期反例继续独立保留。

## 两个严格反例

- no-grant：字段保护可用但没有任何Compute grant。实际Node submit走原broker，原Run明确failed且错误为approval_denied/原拒绝消息。零Job、零operation、零transport；approvalId和broadcast零调用，Registry仍0grant。
- protection-unavailable：存在同一真实Project grant，但原Job字段保护不可用，原willPersistUnencrypted路径仍被deny-unresolved拒绝。相同明确原审批拒绝、零Job/operation/transport和零审批卡分配；原Project grant保留1条。没有auto-once、默认grant或allowUnencryptedPersistence。

测试不spy submit、不手写Job/operation状态、fulfill或harvested/notified/cleanup；静态禁用项扫描记录于receipt。所有异步publish/notifier、原runtime及delivery drain均join后才关SQLite，失败不吞。

## 验证与保留的初始错误

workflow-attempt1.json/log：最初3/3 runtime通过、zero global、process exit0。但同次静态检查有本fixture错误：workflow-types-attempt1.log unused getNotebookDataRoot import；workflow-lint-attempt1.log core prefer-const。均已修并保留原日志，不称原基线失败。

workflow-final.json/log：补充原encrypted raw row与approvalId/broadcast断言后3/3通过、process exit0、无global。
workflow-owner-final.json/log：最终新3项 + 原B六生命周期/journal项9/9、零skip/零global、process exit0。原fixture未改，正常reopen/未知lock等原断言保留。
workflow-final-types.log：npm run typecheck:compiled（Node/sandbox/web）。workflow-final-lint.log、workflow-final-format.log、git diff --check均为最终检查。精确exit和SHA见workflow-receipt.json。

本机macOS arm64/Node26/Vitest4.1.11；未做Windows、真实SSH、付费模型、CI、安装或build，未改共享依赖。后续真实Desktop source/Harness/DeepSeek由root按独立阶段处理，本测试不泛化成新引擎。

提交：76b798e360f8a8c1068d54a7ecacff839595f7f4；branch test/alpha-compute-full-workflow；工作树clean，compiled types/lint/format/diff exit0。
