# 8ec 最终验收 fixture 只读复核

复核提交：8ec476031040763f6718be6abd7e2c21be392fd6。仅查看源码及已有原报告，未运行API/CI、未修改仓库或旧证据。主树现有两项lint修复WIP不在本复核范围。

- **无entry分支符合本实例的原_distil语义。** 先从原Core记录独立查出唯一reflection，再经原owner.exportResult验证真实reflection-reply.md内容与原reply一致、SHA正确；不再把reflection完成等同于Library必须保留经验。有entry仍要求experience指向该原reflection。无entry时，使用与原_EXP相同的完整块模式，按首冒号拆字段、trim/lower键、后值覆盖，再检查cue/lesson/evidence未齐备，同时要求Library为空且experience缺省。实际原reply有2个开标签、0个闭标签、0个NO_ENTRY字面量，故该分支正确，也未伪称它是literal NO_ENTRY。原domain-results retained-entry完整性校验和正向测试均保留；没有改生产parser/Library/resume。
- **累计模型请求预算未重置。** 原attempt5请求149；905恢复时承接149/240、剩91，用7后累计156；8ec重开承接previouslyUsed156、remainingBeforeRun84。代码递推使用上一段previouslyUsed+上一段provider.requests，因此连续零请求重开仍为156/240，不会又获得240。每段新provider计数保留为该段原值；它不是完整费用账本。
- **原事实引用未丢失。** originalTransport/originalProvider优先沿resumedFrom继承，避免将上一恢复段的空transport或仅reviewer统计覆盖最初109条transport/selector Native Read证据。独立JSON相等比较确认8ec报告中的两个original字段均与原attempt5逐项一致。
- **真实零API重开没有重跑或改预算。** sweep-deepseek-completed5-reopen-report.json实际provider.requests/upstreamRequests均0、transport[]；原22条Core journal与905恢复报告逐项相同，8个Job ID及顺序相同，仍22completed/22admitted/24limit/active0。原测试也要求8个task records完整相等，仅允许新记录为reviewer，且已completed实例必须0请求。对应原Vitest JSON为1pass/0fail，原log正常结束；这与先前失败log分别保留，并未追认旧exit1通过。

结论：本次窄验收修正无观察到的阻断问题。保留原未蒸馏出经验的结果，同时保留真实reflection完成、独立评估、版本字节及成本上界证据；不需要新增恢复/读者框架或付费重跑。此前只读细证据见resume5-reflection-review.json；本次依据为8ec源码、原attempt5/905恢复/8ec完成实例重开三份独立报告及对应Vitest JSON/log。
