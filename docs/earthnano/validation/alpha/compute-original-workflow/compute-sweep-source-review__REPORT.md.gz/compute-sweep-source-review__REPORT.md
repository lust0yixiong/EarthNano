# Compute sweep source review

Reviewed read-only on 2026-10-21 in /Users/yxmac_mini/Developer/EarthNano-worktrees/alpha-method. No model calls, tests, builds, SSH, CI or repository edits were performed by this review. Windows remains deferred.

## Reviewed source identity

The reviewed WIP was based on HEAD d3cafd1b15c207e350895121ac5c7d92f78524b6. This was a changing working tree, not a clean immutable acceptance head. The four inspected source copies and their SHA-256 values are retained beside this report and in snapshot.json. Subsequent root edits were also read specifically to assess the two input/source-origin fixes; those later reads are not claimed as an executed acceptance result.

## Actionable findings and resolved-in-progress integration gaps

1. Original Harness managed-input validation rejects an explicitly empty manifest. The original vendor/harness2/harness2/earthnano.py validate_managed_inputs requires 1–10 entries; validate_config calls it when the optional key exists. The original sweep routes its tasks through that same validator. Root observed method exit 2 before any admission. The minimal fix is confined to the private method-config projection: omit the empty optional field only for the Compute profile; retain [] in the authoritative Core task. Current run-persistent-optimization.ts methodTask does this without changing the upstream algorithms or Python/R validation.

2. The original binding generated optimization origin without source Session provenance, although the Compute owner requires frozenCompute.sourceSessionId to equal request.origin.sessionId. Root observed two real admissions, zero model requests, then “Compute frozen source differs from its original execution”. Current harness-optimization.ts derives origin.sessionId only from the trusted normalized frozenCompute context. This fixes provenance without granting a method role Compute capability.

3. A subsequent source-visible blocker was non-task roles retaining Compute managedInputs:[] after their tools/environment were projected to workspace-only/provider-only. candidate-snapshot.ts intentionally sends such non-Compute input lists through normalizeFrozenNotebookInputs, which rejects []. Current binding omits only this empty optional list for non-baseline/non-candidate roles. It keeps task prompt/files and keeps the baseline/candidate TaskSnapshot unchanged. No guard or Python/R rule needs to change. Appropriate regression assertions are identical baseline/candidate task/environment refs, method-role workspace-only/provider-only with no Compute environment, and unchanged nonempty input/Python/R rules.

4. The offline scientificCompute provider overstates two pieces of model-authored evidence. In the retained provider snapshot, lines 623–636 compare Compute output against known fixture constants, while line 648 says “Recomputed arithmetic”; independent source recomputation occurs only in the non-Compute CSV branch. Lines 592–594 also emit reflection claiming CSV aggregation, original Notebook tools and same CSV, although this case uses harvested protocol bytes and Node control. These are fixture rationale/experience wording defects, not forged native producer or Job records. A Compute-specific truthful rationale/experience should describe checked controlled-protocol expected values and actual harvested Node analysis. No added source reader or scientific-accuracy claim is needed.

The first three are concrete connection failures, already reported to root and being repaired there. I did not run their corrected pipeline. No additional proven producer/state/cleanup isolation blocker was found in the reviewed source.

## What the test actually exercises

The retained sweep test invokes the original DesktopOptimizationManager, createDesktopSweepPreview/createDesktopSweepOptions, and runPersistentOptimization. Its run wrapper only records/rethrows the original failure. It requests parallel k=2/concurrency=2 and passes the original preview digest back into startSweep. It asserts zero model/Job activity before preview and completed original Core journal records with cleanup confirmed afterwards.

Baseline/candidate records must have identical task and environment digests, distinct private Sessions, and changed harness revisions. Each such Session must own exactly one actual original Job with success/harvest/notified/producer fields. It reads original native Run repository entries from two prompt identities, exports through the original owner, checks JSON content and materializes a binary ArtifactVersion. It reads original Reviews and expects the independent reviewer role in the Core journal. The selector must receive a native Read image tool_result. It checks no new approval broadcast and unchanged source Session authority. Thus producer identity is obtained from real control tool results and validated by original owners; the fixture does not supply invented native producer IDs.

The test's final manager recreation performs get(), not resume()/Core resubmission. Its unchanged model and Job counters establish read-only desktop-history reopening without replay. Do not describe this as process-death recovery or actual unknown-resource takeover; those require the separate persisted-Core fixtures.

## Explicit substituted boundaries

test/earthnano/compute-transport.ts is a declared protocol simulator. It does not execute SSH or the generated command scripts. It writes known metrics and PNG bytes and supplies protocol exit/poll responses; the numeric 900001 value is a required synthetic wire field, explicitly not a real PID or resource witness. Actual original Compute dispatch/poll/harvest services and repositories process those responses. Unsupported cancellation/reaper operations throw, so this simulator cannot attest external cleanup or successful remote cancellation.

The cipher fixture uses a fixed test key and does not verify OS keychain behavior. The source prompt and test report explicitly exclude remote science, SSH, Slurm, renderer launch, final-package validation and cost-ledger claims. The PNG signature assertion proves real binary transport/materialization of a PNG-shaped fixture, not a newly computed scientific plot or complete image semantics.

The offline Reviewer compares the actual exported JSON bytes with independently predetermined protocol expectations; it does not independently analyze a remote scientific dataset. The semantic criteria deliberately require the known arithmetic and forbid claiming copied PNG bytes as new science. The existing scientificCompute rationale/experience wording needs the narrow correction above.

## Teardown/report and DB assessment

The installed Vitest runner invokes test.onFinished hooks with stack order (node_modules/@vitest/runner/dist/chunk-artifact.js lines 2574–2576 and 2985). The early report/provider-close hook therefore runs after the later manager/fixture cleanup hook. The later hook reads the real execution journal and records transport changes before fixture deletion; errors are aggregated, not swallowed.

compute-workflow.ts close() first stops delivery scheduling, awaits original routing shutdown, runtime stop, actual dispatch joins and tracked effects/drainSession promises, then closes RPC/notebook/its Prisma client. It retains owned files on failure and removes only its fixture tree after successful joins. This preserves the prior drainSession test-only repair; no manual cleanup witness upgrade was found.

The sweep currently calls the global disconnectProjectDbClient before f.close completes those joins. I did not reproduce a late DAO call reopening that singleton or a shared-DB race in this successful path, so this is not reported as a confirmed defect. This source review alone cannot establish absence of concurrent-suite DB interference. Targeted execution should retain global-error/exit evidence and check the final disconnect order if a Prisma error recurs.

## Review limits

This is a source review of an actively changing WIP and original validation/lifecycle paths. It does not replace root's exact-clean-head offline/live acceptance results. I did not rerun tests, paid calls, remote hosts or cleanup probes. The original six Harness algorithms were not modified by the reviewed fixes: method-config/source-origin/role projection changes are integration metadata, not replacement search/selection logic.

