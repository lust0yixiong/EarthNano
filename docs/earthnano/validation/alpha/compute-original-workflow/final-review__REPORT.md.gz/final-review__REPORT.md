# Final Compute source review

No confirmed P1/P2 production finding in the reviewed scope. This is an independent source review with a narrow local failure-path fixture, not a claim that all Alpha platforms or external Compute deployments have passed.

## Identities and evidence

- Reviewed integrated source `905eb504cc56cf1f5bed323215a83ac07fb04b77`, against PR20 `ce0e1d498b46ddea5867bb795c6fad63dafb28b5`, fixed OpenScience `9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5` and pinned Harness² source. Read `docs/earthnano/ALPHA_COMPUTE_CONTRACT.md`.
- Follow-up native failure probe is on `8ec476031040763f6718be6abd7e2c21be392fd6`, whose relevant production modules match the reviewed source. It only adds test cases in an independent worktree. Original `source-and-evidence.json` is retained unchanged.
- Core/scope, TaskRunner, original Job/Notebook/delivery repositories and all six Harness core algorithm files are byte-identical between PR20 and 905; hashes are in source-and-evidence.json. `packages/compute` has no change in this comparison. The original repositories and Compute package also remain the original OpenScience implementations; no alternate Job scheduler/database was introduced here.

## Reviewed invariants

1. **Same execution and original owners.** Candidate `computeFacts` (`persistent-candidate-owner.ts:470–550`) reconstructs actual native admissions and original Runs, then joins Job producer identity to the exact private Session/project/frames/branch/segment/invocation. Application Turns require original background-result attribution and exact original delivery rows. `computeEvidence` (`:566–655`) verifies real final Jobs, consumed deliveries and each fixed Version's original completed producer; per-Turn integrity Reviews explicitly do not claim scientific correctness. Export revalidates request identity, deterministic candidate prompt identity and recomputed references; materialization uses original Version leases, exact digest and owner-chosen isolated targets.
2. **Authority and cancellation.** Frozen source currentness uses actual Session enabled hosts and original host identity; selected hosts do not confer authority. Private Session approvals use original private-Session/project grants. Restricted TCP tokens intersect original allowed methods, retain active invocation identity across body awaits and overwrite model-supplied producer/policy. Global host details writes are denied only for restricted trials. Deny-unresolved uses the original broker and does not copy source grants or invent one-time approvals. Original cancellation joins the native owner and original Job resource owners; unknown cleanup keeps its existing handle/lock, without manufacturing a witness.
3. **Routing and restart.** Factory delivery/control ports remain paired; an explicit live non-Compute claim can preserve its original control behavior, whereas known retired/cold private Sessions cannot fall through to ordinary Send. Cold classification reads original Core/desktop journals under the original data-root writer lease. Explicit never-started setup failures are distinguished only with matching negative journal/directory evidence; malformed or conflicting started state fails closed. No second persistent registry or automatic reconciliation was added.
4. **Context view and legacy identity.** `harness-optimization.ts:390–500` freezes complete method context text as optional invocation contextFiles and gives explicit INPUT-relative mappings, including context/foo → INPUT/foo. It does not truncate original Session or Task files. All new methods share this binding. `candidate-snapshot.ts:247–324,534–615` validates task/context/assets together, applies original portable path and byte limits, and writes the exact files through the existing readonly manifest. Existing snapshots without the optional field retain canonical bytes. Reopen inspects the original invocation to retain legacy inline missions, and exact request comparison includes invocationRef rather than reusing a stage slot alone.
5. **Independent semantics.** The clarification at `semantic-evaluation.ts:397` separates the metadata serialization envelope from actual JSON/CSV/code artifact bodies. Parser/schema/exact quote and artifactRef validation, score thresholds and criteria are unchanged. A source marked unavailable is not assumed readable; image metadata is not scientific image assessment. Real JSON-body substring evidence is accepted, wrapper/double-escaped evidence remains rejected by unchanged validation.

## Failure-path concern resolved by original semantics

The source waiting predicate checks terminal outcome presence rather than requiring every historical Turn/Run to succeed. This alone did not prove a false completed phase. The follow-up real native fixture shows:

- after real analysis Run and partial Artifact publication, repeated native application-Turn failure exhausts the original default three delivery attempts and yields **Core failed / cleanup confirmed**;
- failed Notebook tool then repaired execution yields completed logical Turn/Core, retaining every original Run record.

No production change is warranted from this concern. Raw results and original atomic observations are in `../continuation-terminal-failure/REPORT.md`. The earlier 45s deadline probes returned interrupted/unknown and are explicitly not production red.

## Existing live evidence and test-only issue

Read the retained `root-full-workflow/sweep-deepseek-resume5-fixed-endpoint-report.json` without making requests: 22/24 admitted and completed, all 22 records completed/confirmed, 7 new successful upstream requests/0 rejected, two independent semantic assessments 88/pass and 92/pass. This is evidence from the parent-run experiment, not an independently rerun model test here.

At 905, the acceptance fixture required a reflection experience object unconditionally. Original Harness selection permits missing `<experience>` and its schedule only adds nonempty experience (`selection.py:513–515`, `schedule.py:571`, `library.py:43–45`). Empty Library/NO_ENTRY therefore is not a product defect or justification to fabricate experience. Parent fixed this test-only assertion at 8ec and reported offline/reopen verification; this review does not retroactively relabel earlier failed attempts as passed.

## Limits

- Remote submission/harvest in local integration uses explicit transport/cipher fixtures. No real SSH/Slurm host or physical remote cleanup was exercised by this review.
- FileStore terminal reopening/no redispatch and a live unknown owner's lock are tested; safe takeover after actual process death is a separate boundary, not proved by copying a journal or fabricating PID evidence.
- Source review and retained model evidence do not prove all CLI/Web/desktop GUI, installer, keychain, provider interruption or image-scientific evaluation paths. Usage aggregation remains explicitly unknown where the original owners cannot give an authoritative all-Turn total.
- No API, CI, build, dependency installation or Windows activity was performed. Windows is deferred to 0.2. No source changes were made to root alpha-method.

Test-only follow-up commit: `b3cb05200837d0a0a4fe92368ff55cfec55e1f73`; worktree clean after commit.
