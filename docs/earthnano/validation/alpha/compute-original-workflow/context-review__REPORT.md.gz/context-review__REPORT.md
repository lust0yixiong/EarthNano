# contextFileView caller review

Read-only review of b72b92e73c0156abbe1c04b2eb9547305344e92a plus the four working-tree files captured here in source.json. No repository edits, branch switches, model/API calls or tests. Root's concurrent validation is not counted as work performed by this review.

## Result

No new demonstrable blocking correctness/authority defect found in the inspected change. One wording refinement is recommended below; actual native Read path use remains a validation limit.

## Checked paths and byte authority

PlatformRequestFactory continues to send the original read_snapshot/context_snapshot result as contextFiles (earthnano_binding.py275–291). read_snapshot produces paths relative to the original context root and exact UTF8 contents with original file/link/identity/size checks. The changed binding textFiles normalization does not truncate content.

For new view mode, harness-optimization.ts454–468 puts only path/UTF8 size in mission while freezing the complete context array in invocation.contextFiles at500. Snapshot materialization writes those files at INPUT/<frozen relative path> (candidate-snapshot.ts615–616); binary assets retain their same original relative root. Context is protected and validated by the same exact manifest/readback checks as other frozen text. No Task mutation or full Session/journal overwrite is added here.

Native preparation's existing gate permits Read within INPUT and rejects writes there. Complete contents containing @/backtick stay in files; only path metadata is JSON-escaped for the native prompt. File size, aggregate budgets and path/collision checks remain authoritative. This does not provide arbitrary host-file access.

## All method callers

run-persistent-optimization.ts549 sets contextFileView in the shared bindingOptions. taskBindingOptions spreads those options for every task; both single HarnessOptimizationBinding and HarnessDomainBinding (which constructs the same original binding per task) receive it at572–575. Proposer, composer, selector and reflection use that same freeze path; no separate method implementation was introduced. Baseline/candidate also freeze an explicit empty contextFiles array where the original method supplies no role context, making the representation discoverable on later resume.

## Resume identity

The mode is chosen from a trusted resolved prior invocation rather than model content. With any retained original inline experiment, absence of contextFiles chooses the old construction. The old-mode mission/header strings and old JSON body remain byte-identical; invocation has no newly defaulted field. The existing completed-stage matching at533+ still uses sameExecutionInputs including invocationRef and returns the exact old immutable request only after export validation. Changed task/context/assets cannot become paid replay through a slot-only match.

For new-mode records, the optional property exists even for the initial empty context, so reopening selects file mode and reconstructs the same ref. The added tests cover new exact reuse and unchanged admission count; the original legacy exact-reuse test now supplies opt-in true on reopen and still rejects changed task/evidence. Unknown cleanup, missing ownership index and method-source identity checks were not loosened.

Mode selection currently uses the first prior record for that task. A fabricated mixed-format history is not silently accepted: any completed request that reconstructs differently still fails the exact identity check. This review did not execute a multi-task partial-resume fixture, so successful native continued operation is left to root's validation rather than inferred from a unit result.

## Wording / native path observation limit

Original Harness missions/layouts contain literal context/task.md, context/harness/, context/pool/... references (core/context.py539 and core/selection.py489–491). Actual file targets in this new projection are INPUT/task.md, INPUT/harness/, INPUT/pool/..., not INPUT/context/... or cwd/context/....

The current new-mode sentence says the original context directory is under INPUT at the listed relative paths and asks the model to resolve method context references under INPUT. This is consistent with the implementation but does not explicitly spell out the prefix substitution. A narrow improvement is to state: “When original method text says context/foo, read INPUT/foo; listed paths are already relative to INPUT.” This can prevent accidental INPUT/context/foo exploration without changing original method text, evidence bytes or readable capability. It is not reported as an observed failure.

The newly added large-reflection test uses 40 actual files and checks exact bytes/manifest with a short mission, but does not execute native Read. Root should verify actual successful Read paths in the offline/native record; passing size/materialization tests alone cannot prove the model followed the correct path mapping. The deterministic fixture provider may inspect files itself and should not be used to claim a native model read unless a real tool_result is observed.

The source prompt refinement in the Compute fixture requires exactly three numeric report fields while retaining metrics-source.json and PNG as separate outputs. It does not weaken checks or substitute the independent Review outcome. No trajectory slicing/obs_trunc change exists in these four files.

