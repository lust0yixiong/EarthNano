# Provider rejection diagnostics

Base d13967b9c598936308398f964781c0777728d706; changes are limited to the acceptance provider fixture and its existing unit suite.

Adds stats.rejectionReasons with a fixed reason vocabulary and stats.upstreamStatuses containing numeric HTTP response status counts. Error bodies/status text/messages/keys are never read into diagnostics. Original response rejection, 1,000,000-byte limit, request ceilings and short-circuit request counting, forwarding transforms, streaming and offline scoring remain unchanged. Unexpected throws remain fixture-error; deliberate Stop disconnects retain their original cancellation/incomplete-usage path. HTTP errors retain their status category even if body cancellation throws.

Original 13 cases and all original test lines are preserved. Three new actual loopback HTTP cases cover exact 1,000,000-byte acceptance vs 1,000,001 rejection (no second upstream call), and upstream 400/429 with body cancellation and safe-only stats. Existing 503 and request-ceiling cases additionally assert categories. Injected upstream responses do not call DeepSeek or another external API.

Old provider with current assertions: 11 pass / 5 fail, exit1; all failures are absent diagnostic fields. New provider:16 pass /0 fail /0 pending, exit0, no global errors. Full typecheck:compiled, targeted ESLint, Prettier check and git diff --check pass. Raw red/green logs and JSON are retained alongside receipt.json.

Commands: node node_modules/vitest/vitest.mjs run scripts/ci/earthnano-messages-provider.test.ts --reporter=default --reporter=json --outputFile=<evidence>/final-focused.json; npm run typecheck:compiled; node node_modules/eslint/bin/eslint.js e2e/fixtures/earthnano-messages-provider.ts scripts/ci/earthnano-messages-provider.test.ts; node node_modules/prettier/bin/prettier.cjs --check <same files>; git diff --check.

This is local macOS fixture validation. It neither reconstructs the previous real rejection reason nor establishes whether the invalid PNG caused upstream failure. PNG/helper/production/transport/threshold/scoring are untouched. No real API, Windows, CI, install/build, signing or publication operation was performed.
