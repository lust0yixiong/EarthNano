# Semantic artifact-body citation prompt clarification

Commit b795e0c015f1f59439f3f9777c1e7a470013ce70
Base d77d6cae (exact full base in production-invariance.json)
Branch fix/alpha-semantic-json-evidence-prompt
Independent worktree alpha-ci-runtime is clean after commit.

## Confirmed ambiguity and narrow change

The original Reviewer mission said “do not quote JSON container syntax or escaped serialization instead” without naming only the artifacts.json wrapper. Attempt5 candidate's original rationale explicitly read this as prohibiting genuine raw JSON file-body quotations because they coincide with JSON syntax. It therefore reported insufficient quotable text despite reasoning from the real metrics source.

Only the mission statement in src/main/earthnano/semantic-evaluation.ts is changed. It now distinguishes:
- artifacts.json is the evidence package; parse it once to obtain the exact entry.content body.
- Genuine JSON/CSV/source-code bodies, including their own syntax and literal escapes, are valid text to quote.
- A quote is a short contiguous body substring, without decoding the body again when copying.
- Only wrapper metadata/its serialization is excluded; writing assessment.json uses normal JSON escaping. After that assessment is parsed once, quote must be the actual body substring rather than JSON.stringify/double-escaped text.

No Task/Session mutation, schema/parser/score/threshold/criteria change or citation tolerance was added. production-invariance.json verifies that replacing the one mission line with a placeholder makes the entire production file byte-identical to base; all other production bytes are unchanged.

## Original failure audit: corrected facts

Retained attempt5 root:
 /var/folders/4k/7zdywcj964s64r9xmj0svhth0000gn/T/earthnano-compute-workflow-yV18wG

The original files were read, never edited. attempt5-json-audit.json stores original assessment/INPUT paths, SHA256 identities, exact version matches, nonempty/body-substring observations.

I also loaded the unchanged production parseSemanticAssessment through existing Vite SSR (outside shared dependency/build outputs) and passed the original assessment.json plus the same Reviewer's original INPUT/evidence/artifacts.json and criteria.json. original-parser-audit.json/.log records:
- baseline execution6cf429f3-4f0e-4b9a-8a58-417542298c7c: accepted,95/pass.
- candidate executionea21d62e-44ea-4e3c-99ce-56c9030a8091: rejected, “Invalid or unsupported semantic assessment”.

Baseline's serialized display is not evidence of invalid double-escaping. Its decoded quotes all match actual decoded body substrings and the actual unchanged production parser accepts it. Candidate's c1 quotes match; c2 cites binary measurements.png with an empty quote, which still fails the original nonempty/text-body contract. The original candidate rationale proves the prompt ambiguity, but this patch does not repair/relabel its invalid output or retroactively pass attempt5. The whole live acceptance remains failed.

The generic error occurs before binary-body verification for an empty quote. Existing binary metadata rejection remains covered separately with a nonempty forged metadata quote.

## Tests and results

Only src/main/earthnano/semantic-evaluation.test.ts also changed; original test names/assertions are retained. New actual data cases cover JSON containing literal escapes, CSV with quotes/CRLF, and source code with Unicode/newlines:
1. Package/assessment JSON round trips preserve actual body quotations.
2. JSON-stringified quotes and escaped string interiors are rejected.
3. Wrapper artifactRef metadata is rejected as file-body evidence.

These data tests run the original parser; they are not a model simulation. Existing owner evaluation checks also verify the new mission reaches the independent Reviewer.

red.log: old production prompt + tests:1 failed/38 passed, process1. The failure is the new prompt-admission expectation; the new data-boundary/parser cases already pass under the old strict parser, demonstrating why no validator change is needed. This is not claimed as a deterministic reproduction of the model's interpretation.

green.log:3 suites,78 passed/0 failed, process0:
- semantic-evaluation.test.ts
- persistent-candidate-owner.integration.test.ts
- persistent-candidate-owner.binary.test.ts

types-node.log / types-web.log / types-sandbox.log: full existing compiled checks all exit0.
lint.log: both changed files exit0.
Prettier and git diff --check: exit0.

No paid/API call, model retry, full build/shared dependency rebuild, SSH, Windows work or CI was performed. A new clean-head live model result remains necessary to prove that the clarified instruction resolves the model behavior; the unit/owner results prove contract preservation, not future scientific correctness or promotion.

