# Attempt5 explicit-resume review (read-only)

Source d77; original run0e66ecad-1847-498f-906c-2c86924cd66e; retained root earthnano-compute-workflow-yV18wG. No API, resume invocation, source/state/record/budget edits, dependency work or new reader/recovery framework. Original test failure remains preserved. Detailed original-data findings: attempt5-resume-review.json.

## What failed

Both assessment artifacts are syntactically valid JSON. Baseline6cf429f3-4f0e-4b9a-8a58-417542298c7c is95/pass, with valid nonempty target artifact quotes. Candidate ea21d62e-44ea-4e3c-99ce-56c9030a8091 is50/flagged; c2 cites measurements.png with an empty quote. The original semantic-evaluation.ts text() guard rejects that empty quote with the generic Invalid or unsupported semantic assessment before the binary-content guard. The target PNG is binary and cannot supply a text quote either. Preserve its original judgment/document; no JSON syntax repair, binary-to-text conversion, empty-quote waiver or score alteration is warranted.

Read-only DB has21complete/pass Review rows and21pass Findings:20original integrity/UTF-8/JSON syntax reviews plus1baseline semantic review. All8published reports numerically match their actual source Version values(3/12/4). But final evaluateResearchOutcome/commitDeterministicReview runs only after semantic assessment returns: it was not reached in this failed run. Distinguish passed existing integrity reviews and independently checked arithmetic from an already-persisted final deterministic output review.

## Existing resume contract

DesktopOptimizationManager.resume(key) accepts this saved failed state only after original source Session validation, no active/unreconciled peer run, original manifest/desktop request identity agreement, all records terminal+cleanup confirmed and no journal lock. Current artifacts meet the visible state gates:20completed/confirmed, manager failed, no execution lock, original identity digest valid, method request index18entries. Budget remains20/24.

runPersistentOptimization({...preparedOriginalOptions,resume:true}) reads the same resume.json and refuses changed methodDigest or canonical resume identity. The frozen sweep/task/source/criteria/agent/model/framework/provider identity/host context, method scheduling options, executionTimeoutMs180000 and executionLimit24 must remain exactly original. Original methodDigest issha256:6fa18ab344cc81c333cc109c6d0ef34314a64c02ce8eac177aae398df6fa6208; recomputation against the existing Harness tree matches. It hashes every original harness2 Python source, so a vendor Python change would block resume. A semantic-review host prompt-only clarification does not alter this digest or the frozen scientific task.

Original OptimizationResumeIndex validates the original18method requests, their task/scope/slot ownership and request hashes. HarnessOptimizationBinding reuses completed requests only under sameExecutionInputs, re-exports original pinned results and submits the ORIGINAL request key; Core returns the original handle with no admission. An occupied completed slot with changed identity throws paid replay refused. PlatformResultReader revalidates original cached projections, including artifact identity and physical projection bytes. The cached summary.port.json and experiment-libraries.json exist. Scheduler/method Python still walks its normal resume path; this is not a new evaluator-only shortcut. Empty Library/NO_ENTRY is allowed and should not be repaired.

Under these exact conditions, all18method executions, including2baseline+6candidate, should reuse their existing records:0new scientific Job/dispatch/harvest. This is source-contract reasoning, not a resume executed by this review. Any cache/Version/Turn/model/profile mismatch must remain a hard error, never fallback to replaying an old successful candidate.

## Important reviewer reuse distinction

Original reuseAssessmentRequest selects any exact completed/cleanup-confirmed reviewer request; it intentionally leaves output parsing to the original evaluator. Thus unchanged code/invocation reuses both old completed reviewer records (including the invalid candidate JSON), consumes0new admissions/API and fails the same validation again. Explicit resume alone cannot force a fresh assessment and there is no force-refresh parameter to invent.

B's narrow semantic invocation/system-prompt clarification produces a different frozen invocationRef (or reviewer agent ref), so original sameExecutionInputs no longer matches the old reviewers. Then the existing evaluator naturally submits2new reviewer requests under the SAME optimizationId and budgetRef:20→22of24, leaving old reviewer records untouched/charged. No mutation of old identity/index/cache, no changed request key on old record, no budget increase and no direct Core/evaluator bypass. It can still legitimately fail/flag on the new model response; there is no promised score/pass. Exact scope change must be proved before a paid call, and if the patch does not change the frozen reviewer request it will simply reuse the invalid artifact again.

## Exact public call once original dependencies are available

Use the original manager options assembly and original retained root, not startSweep/new Task:

```ts
const runId = '0e66ecad-1847-498f-906c-2c86924cd66e'
const executionRoot = join(originalRoot, 'earthnano', 'desktop-runs')
const manager = new DesktopOptimizationManager({
  root: join(originalRoot, 'config', 'earthnano-desktop'),
  executionRoot: () => executionRoot,
  readResume: async (id) => readDesktopOptimizationResume(join(executionRoot, id, 'execution')),
  validateSession: originalValidateSession,
  createOptions: originalRejectAlternateSingleTaskPath,
  createSweepOptions: async (request, signal) => ({
    ...(await createDesktopSweepOptions(request, { ...sameDependencies, signal })),
    executionTimeoutMs: 180_000,
    timeoutMs: 1_200_000
  }),
  run: runPersistentOptimization
})
await manager.resume({ projectId: 'compute-project', sourceSessionId: 'compute-source', runId })
// Observe manager.get(key), then original shutdown; preserve original failure and new continuation receipt.
```

resume() reconstructs the original sweep request from its frozen manifest itself. Do not replace criteria/sourcePrompt with the current test's constants, create a new requestKey, start a new sweep or call evaluateOptimizationSemantics directly. Direct runPersistentOptimization resume exists but requires the exact same prepared/frozen options and bypasses the desktop projection if used alone; manager.resume is the appropriate existing caller here.

## Current practical blocker: fixture reattachment is not an existing entry point

createComputeWorkflowFixture({mode,sourcePrompt}) always mkdtemp+creates a new Project/Source Session/Host/grant and transport. It has no existing-root/reopen option. Calling it again would build a different experiment and cannot resume this one. The old Vitest process and closure ports have closed; there is no turnkey existing test command that restores them. The public production resume mechanism is present, but this test's external DI assembly is not retained as a callable reopen handle. This review does not add an opener/new framework/parameter exemption. Root must choose an explicitly authorized original dependency reattachment/caller using existing constructors, or retain an in-process handle in a future experiment; cannot claim the shown pseudocode runs today without supplying sameDependencies.

Required existing-root dependencies: original configRoot/config database/client with no migration/seeding; SessionRepository and existing candidate-owner persistence/settings ports; same ManagedFileVersion/ImmutableInputAuthority/Notebook readers; same fixed cipher below for jobs/operations; original Compute host/session-access/grant and BackgroundResultDelivery repositories; same factory onOwnersReady original router; notebook RPC/native reviewer runtime only as required by existing owner setup; explicit provider/model/runtime binding reauthorization. Reconstruct source/host rows from retained authority rather than saveSession/hosts.create/remember-grant again. Never start the Job runtime/dispatcher simply to read final Jobs or invent a reaper result. Any persisted unknown cleanup blocks admission as before.

Fixture encryption is reconstructable: cipher key is Buffer.alloc(32,7), AES-256-GCM with12-byte nonce +16-byte tag +ciphertext; selected backend literal gnome_libsecret. New per-encryption nonces do not change the key. Reuse original OptionalSecureStorageStringProtection/ComputeJobRepository/ComputeJobOperationRepository constructors, not plaintext reads/grants; this is test protection, not OS keychain evidence. Original Session IDs/database/leases and authority must still be used.

Original loopback provider is closed; any resumed paid segment needs the same explicitly authorized provider/model/runtime identity and a newly owned local proxy. Original cap was240requests and149have been consumed. To retain that same aggregate bound across a new proxy process, the existing maxModelRequests caller option can be limited to remaining91(never reset to240then silently claim the original total cap). Record old and continuation counters separately and their sum; no new global ledger/mechanism is implied. Core20/24 is independent and must remain unchanged until real new reviewer admissions.

## No-fee preflight before any continuation

Keep originals byte-for-byte and inspect existing manifest identity/method digest/index, all20record/witness/owner proofs,24artifact refs/bytes and21passing existing reviews using original read APIs; confirm existing8Job IDs and final statuses. Verify the proposed new reviewer invocation differs while scientific task/method/agent/model/host/budget remain the same. If dependency reattachment or any original cache identity cannot be established, stop at that specific blocker; do not pay for a blind fresh8Job run or loosen guards.
