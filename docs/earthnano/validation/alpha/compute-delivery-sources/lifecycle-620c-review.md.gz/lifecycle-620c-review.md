# Independent lifecycle review — 620c096e3

Read-only review of exact `620c096e3abfc0347a4510199efc9367009dad7f` against shared base
`1ada7326e054aee1f9b1b5643ca703500356233e` and fixed OpenScience
`9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5`. No broad tests, build, model, SSH, Windows
or CI actions were run for this review. One narrow external source fixture was used.

## Confirmed recovery issue

`composition/background-results.ts:45–59`: private owner disappearance after readiness
can reject sendContinuation or report false from isContinuationSaved. Original
`background-result-delivery/owner.ts:429–440,479–489` then calls failClaim even though
the target is temporarily absent; original repository `:398–425` spends attemptCount.
Three readiness→retirement races produce pending/1 → pending/2 → needs-attention/3
with zero private admissions and zero claim releases.

The exact router and unchanged fixed-pin owner/repository were loaded from git into a
minimal external fixture. The transaction port is in memory; no database/native/model
is claimed. Reproduction: `node lifecycle-620c-route-race.cjs` from this directory.
Its JSON/log preserve the counts. The first fixture loader setup failure is separately
retained and is not used as evidence of product behavior.

Root authorized a minimal generic availability correction from `56c083b`; see
`delivery-availability/REPORT.md` and its real original migration/repository/owner/router
red/green tests. Ordinary errors must still spend the original retry budget.

## Other reviewed boundaries: no additional blocking finding

- `runtime-coordinator.ts:1596–1601` adds only the existing positional application
  attribution to AcpExecutionDispatch. It does not infer authority from request/model JSON.
  Native admission observations still originate in original onPromptStarted ownership
  checks (`:2358–2371`), not provider response text.
- `earthnano/acp-execution-boundary.ts:94–150` resolves an exact live main-owned execution,
  then requires the existing strict background-results attribution schema, deliveryKey
  matching promptMessageId, same private Session, ownsTurn and ownsApplicationDispatch.
  The original codec rejects extra fields such as trusted. Ordinary second-Turn identity
  restrictions and deny-unresolved restrictions remain in their original branches.
- The application observer (`:159–185`) requires matching original Session admission,
  rejects provider acceptance before it, and rejects a completed dispatch with no admission.
  It records observations without overwriting the immutable mission identity. Durable
  delivery/Job/producer membership still belongs to the injected original owner; a typed
  boolean interface alone is not evidence that the future private Job owner implements it.
- `acp/earthnano-execution-driver.ts:140–179,219–286` retains one cancellation registration;
  initial exact-prompt cancellation remains admitted/settled gated. The optional background
  branch remains available during readResult, both branches are joined with allSettled,
  original errors survive, and acknowledgment does not by itself attest cleanup.
  Timeout terminalization remains original Core interrupted/unknown; late completion cannot
  overwrite it. No change to the underlying Core cancellation ordering was made.
- Original ordinary sendContinuation/isContinuationSaved/canStartSessionTurn functions
  compare equal after TypeScript AST printer normalization; the original composition in
  shared base is byte-identical to the fixed OpenScience pin. With no resolver, routing
  returns the original target directly. Results are in `lifecycle-620c-ordinary-comparison.json`.

## Explicit consumer limits

The background cancellation hook must acknowledge/request cancellation independently of
readResult and the same Core signal. Core.cancel waits for its registered owner callback
before aborting that signal (`execution-core.ts:313–333`), and the driver may join an
already-started cancellation before entering readResult (`:219`). A hook that awaits
readResult completion or waits for this signal to initiate cancellation creates an
acknowledgment cycle. This is a required consumer invariant; no such production consumer
is introduced in 620c, so it is not reported as a demonstrated new ordinary regression.

The resolver must derive ordinary/private-unavailable classification from durable ownership,
not only a live map, and private ownsApplicationDispatch must validate original persisted
delivery/Job scope. The shared lifecycle ports and their fixture tests do not alone prove
actual remote Job cancellation, producer publication or multi-Turn recovery acceptance.
