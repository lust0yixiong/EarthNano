# Preserve claims while the original result authority is unavailable

Base: `56c083b1b909026b2cfebc386acab3173bcc453b`.
Branch: `feat/alpha-compute-delivery-availability`; the separate 210bdc control branch and
old Windows branch remain intact. Root authorized only original delivery owner/routing
and their necessary tests. No shared DTO, candidate owner, desktop composition, model,
SSH, Windows, CI, dependencies or Job algorithm was changed or invoked.

## Cause and smallest correction

Private readiness can succeed, then its authority can retire while the original owner
awaits SQL/source resolution/send/result. Generic send rejection or a false saved-message
answer was indistinguishable from an actual failed delivery. The original owner called
failClaim, consuming attempts without any eligible authority. Three occurrences could move
the row to needs-attention. A saved continuation could also be mistaken for unsaved work.

The original `background-result-delivery/owner.ts` now defines and exports the host-only
`BackgroundResultDeliveryUnavailableError`. It is a real Error instance, not a JSON marker,
new persisted state or EarthNano type dependency. Composition throws it only for a known
private-unavailable send or saved-message lookup; canStartSessionTurn still returns false.
Existing admitted/result callback types and ordinary callbacks remain unchanged.

The original drainSession catch preserves original pre-dispatch disposal and already-consumed
priority. Only this explicit error uses the original releaseClaim(allIds, claimToken), publishes
the original activity projection and returns queued. releaseClaim's original SQL predicate
checks exact token and claimed/dispatching state, preserves correlation and attemptCount,
and cannot release a replacement/consumed claim. Ordinary errors still use failClaim.

No new queue, retry counter, transaction or schema was added. Dependency remains
composition → original delivery owner; original owner has no EarthNano import.

## Real repository races and red/green evidence

The existing repository suite starts the original migration-backed temporary SQLite client
and original BackgroundResultDeliveryRepository. The new cases run the original
BackgroundResultDeliveryOwner and actual routeCandidateContinuations, with a controlled
private target at the existing callback seam:

1. Authority retires in source resolution after readiness, before send.
2. A prior continuation already exists; authority retires after the actual durable claim,
   before the original saved-message lookup.
3. A continuation is admitted/saved, then authority retires before the result owner's
   saved-message lookup. Restoring authority consumes the saved continuation without
   dispatching it a second time.

For the first two, three repeated retirement races retain pending/attemptCount=0. The
third retains its correlation and zero attempts after the admitted result. Restoring
the original authority dispatches unsent messages once, or recognizes the saved message;
all finish consumed/attemptCount=0. No ordinary fallback runs.

An ordinary Error with the exact same unavailable wording still spends attempts 1,2,3
and reaches needs-attention. Additional owner cases verify consumed authority and
pre-dispatch disposal priority over the explicit unavailability signal. Existing test
titles/ordinary assertions remain; one new lifecycle router expectation changes false
to the now-explicit unavailable error.

- Before the production correction, repository suite **11 pass / 3 fail / 0 skip**:
  `red.json`, `red.log`. All three new race cases fail on the original attemptCount.
- Final targeted original suites **76 pass / 0 fail / 0 skip**: `green-final.json/log`.
  Repository 14, owner 30, composition routing 7, compute adapter 21, source resolver 4.
- Complete Node + sandbox + Web compiled types: pass (`types.log`).
- Focused ESLint: pass (`lint.log`). Prettier check: pass (`format.log`).
  git diff --check: pass.

The original three ordinary callback function expressions are **byte-identical** to
56c base and match fixed OpenScience 9e18 after TypeScript AST printer normalization.
Per-function hashes and comparisons: `ordinary-function-comparison.json`.

This validates local original persistence/routing availability semantics. The controlled
callback does not claim to be a paid model, native admission DB, SSH server or remote Job.

## Final commit

`96e2e0395ceae58cebe18b8fb160189fb8bf4a0a` on `feat/alpha-compute-delivery-availability`, parent
`56c083b1b909026b2cfebc386acab3173bcc453b`. The worktree was clean after commit.
Full patch: `commit.patch`. No push, shared dependency mutation, build, model, SSH,
Windows or CI action was performed.
