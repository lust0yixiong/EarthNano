# Windows NSIS exit-2 阶段取证选项

审查仅使用 run 39577934563 的原始 job log / 小证据包、源提交 `f6329ed8cf5993a9b8a807b393b7640c395b42cd` 和该提交所锁定的 electron-builder NSIS 模板。未执行 installer、未改仓库、未运行构建或 CI。

## 已确认事实

- smoke 实际以 `args:["/S","/D=D:\\a\\_temp\\...\\installed app 程序"]` 启动，记录 `windowsVerbatimArguments:true` 和带引号的 `argv0`。installer 在约 9.3 秒后 exit 2，stdout/stderr 为空，`installedEntries:[]`、`archiveBytes:0`。这不能证明 `/D` 已由原 NSIS 正确解析，也不能说明 exit 2 的来源。原始记录为 `windows-diagnosis/job.log` SHA-256 `28d38d0117c7ea910312a09bea5636244558b70c1d4e3228f08535a1b1a42671`，关键记录约在日志 2160–2165 行。
- 同一次 build 的 `evidence/dist/builder-debug.yml` SHA-256 `dafecf646c035a87ab8a902dfd341efb6fe004d6d497d72d5b54fe3a87989665` 显示 electron-builder 生成的 NSIS 主脚本 include `multiUser.nsh` 和 `assistedInstaller.nsh`。其 `.onInit` 顺序是：`SetOutPath` / `${LogSet} on` → 可选 `preInit` → `initMultiUser` → 可选 `customInit`。模板还包含静默安装区段及后续 `Quit` 分支。
- smoke 前的 arguments probe 没有跑出参数结论：probe 报告显示 NSIS 3.04 编译因 `GetDParameter` macro 未定义而失败（`evidence/test-results/native-evidence/nsis-arguments/nsis-arguments-7Jggoq/report.json`，`cases:[]`）。这是 probe 的编译缺口，不是原 installer 参数解析结果；probe 修复由另一个审查任务处理。

## 原始源码与 hook 位置

源文件均指固定构建提交 `f6329ed8cf5993a9b8a807b393b7640c395b42cd`：

- `build/installer.nsh` Git blob `0cc963a822b611c6369ca4165d43203c151d53b8`。`:1–6` 定义 `customInstallMode`，将 `$isForceCurrentInstall` 置为 `1`；`:264–343` 是 `customInit`；`:35–43` 的 `quitFailedUpdate` 执行失败 receipt、`SetErrorLevel 2`、`Quit`；`:411–423` 提供 `restorePreservedOnAbort` 与 `.onInstFailed`；`:426–429` 是成功后的 `customInstall`。
- `electron-builder.yml` Git blob `37c6a134f2f258a6c7ee6378ce3cab8c13499aed`。`nsis` 配置为 assisted installer（`oneClick: false`）、current-user、允许选择安装目录；没有改变 NSIS compiler。
- 本次生成脚本 `builder-debug.yml` 的关键顺序如上，直接来自 run 证据，而不是根据文档推断。
- 锁定的 `app-builder-lib` 为 `26.15.3`（package-lock 对应 tarball）；其实际模板位于 `node_modules/app-builder-lib/templates/nsis/`。`installer.nsi:49–88` 展示 `.onInit` 顺序和 `preInit` 插入点；`multiUserUi.nsh:30–65` 仅在 install-mode 页面回调中调用 `customInstallMode`；`assistedInstaller.nsh:84–153` 的 `initMultiUser` 选择安装模式，并通过 `GetDParameter` 处理 `/D`。因此本次 `/S` 测试不经过 `customInstallMode` 页面 hook，但会运行 `initMultiUser` 和之后的 `customInit`，除非更早路径 `Quit`。

## 最小阶段取证方案

若需在保持生产模板和 NSIS compiler 不变的情况下继续定位，最小可判别方案是对一次隔离诊断包使用临时构建副本，在现有 NSIS hook 写入独立 `%TEMP%` 追踪文件（每行固定阶段标记和错误码，不写用户数据）：

1. 在模板已有 `preInit` 插入点写 `PREINIT`。它位于 `initMultiUser` 之前；若它存在而 `CUSTOM_INIT_BEGIN` 不存在，范围就收敛到原多用户初始化/模式选择/`/D` 路径。
2. 在临时副本的 `customInit` 入口与出口写 `CUSTOM_INIT_BEGIN` / `CUSTOM_INIT_END`，并在其静默分支的既有关卡前后标记：读取注册安装信息、`ensureExistingUninstallerIsWritable`、`protectMachineDataRootForSelectedMode`。同时在诊断副本的 `quitFailedUpdate` 展开点写 `QUIT_FAILED_UPDATE`，特别是 `customInit` 内的两个现有调用点；该宏本身把 exit code 设为 2 后立即 `Quit`，不会依赖 `.onInstFailed` 收尾。
3. 在 `customInstall` 与 `.onInstFailed` 写 `INSTALL_SUCCEEDED` / `INSTALL_FAILED_CALLBACK`。若记录到 `QUIT_FAILED_UPDATE`，可将 exit 2 直接关联到该项目宏；若只到 `CUSTOM_INIT_END`，则继续排查安装 section / electron-builder 原有静默分支。没有任何 marker 时，失败发生于最早 marker 前或 trace 写入本身不可用，应先检查诊断 trace 的写入前提，不能归因参数问题。

这些是一次性诊断构建中的 hook 标记建议，不应作为本轮已实现或已验证的修复。`customInstallMode` 只适合额外的交互式对照运行，不是复现当前 `/S` 失败的取证点。模板的 `${LogSet} on` 虽存在于生成 `.onInit`，本次 artifact 没有携带 installer 内部 log；不要将其当作已获得阶段日志的证据，也不要以外层 Node `stdout/stderr` 为空推断 NSIS 内部没有打印。

## 结论边界

`windowsVerbatimArguments:true` 和 quoted `argv0` 只描述 smoke runner 的子进程构造；probe 当前 `cases:[]`，所以引号/空格是否被原 NSIS 解析正确仍未验收。源模板确有显式 `SetErrorLevel 2; Quit` 路径，但当前日志没有阶段标记证明实际命中了它；installer 也可能在其他模板/区段路径退出。现阶段只能确认安装未留下目标 entries 且进程退出 2，不能宣称引号已解释 exit 2，也不能根据一次 exit 2 判定产品安装器整体失效。
