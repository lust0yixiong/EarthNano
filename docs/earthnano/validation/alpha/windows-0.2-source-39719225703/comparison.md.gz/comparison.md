# EarthNano pinned source comparison

## win32
- Outcome: no-new-regressions
- Baseline tests: 115591; candidate: 116991; added: 1400
- Baseline failures: 13; skips: 4254; candidate failures: 3; skips: 4364
- New test regressions: 0; stage regressions: 0
- Baseline failures/skips remain unresolved evidence, not full acceptance. Equal failing statuses do not prove an identical cause.
