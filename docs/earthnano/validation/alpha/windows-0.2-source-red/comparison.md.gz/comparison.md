# EarthNano pinned source comparison

## win32
- Outcome: new-regressions
- Baseline tests: 115591; candidate: 116997; added: 1406
- Baseline failures: 16; skips: 4254; candidate failures: 72; skips: 4350
- New test regressions: 100; stage regressions: 0
- Baseline failures/skips remain unresolved evidence, not full acceptance. Equal failing statuses do not prove an identical cause.
