# Binary desktop fixes — independent read-only source review

Reviewed exact root `4746f52f79a80aa9de5ec0d5ea184eb4fca18733` via `git show`; the
review worktree stayed clean on its existing independent branch. No production edits,
build, model calls, CI operations or Windows diagnostics were performed.

**No provable severe or blocking regression found in the scoped fixes.** This is a
source review of the specified path/asset/protocol boundaries, not a declaration that
all Alpha capabilities or Compute are complete. Existing root offline/DeepSeek
acceptance and 335 total / 330 pass / 5 opt-in skips were reported by root; they were
not rerun or independently reclassified as this review's test results.

## Three actual desktop fixes

### 74ce135fcbc8c8f99871ab9d4fb69ee4aee645c2 — host-root alias

`src/main/earthnano/run-persistent-optimization.ts:301` creates the host-selected
workRoot (exclusive for a new run); `:442–450` resolves that existing host root before
appending `artifact-projections`. It does not canonicalize an arbitrary model-provided
destination or an existing untrusted projection leaf. The owner chooses every output.

`persistent-candidate-owner.ts:170–213` still walks/checks ancestors before child
creation, rejects symbolic links and non-directories, requires a private leaf on POSIX,
then rechecks directory device/inode/realpath. Its unique `mkdtemp` child and alias at
`:1315–1325` remain owner-selected. Thus accepting the trusted macOS `/var` alias at
the host boundary does not grant callers permission to materialize through child links
or choose host paths. The existing snapshot root canonicalization at
`candidate-snapshot.ts:322–339` follows the same host-root distinction.

### 2f08daa88149e07e47f1b373dff6aded9dc01a82 — native manifest verification

`src/main/acp/claude-candidate-preparation.ts:66–99` includes frozen invocation assets
in the exact expected manifest, verifies size and digest metadata, rejects unexpected,
duplicate or absent manifest entries. The binary arm at `:122–160` hashes every byte
with the original 64 KiB reader rather than decoding it or retaining the full binary
in memory. It compares the final byte count/digest and original/open/final path file
identity, size, timestamps, type and link count; the handle closes in finally.
Preparation verifies before creating native runtime resources (`:302–311`).

The newly exported `readOpenFileChunks` implementation is the original OpenScience
reader (`bounded-file-io.ts:148–164`), including its original pacing and optional
AbortSignal support. Only its export changed; no new file reader was introduced.

Budget and lease checks are layered rather than replaced by manifest metadata:

- `candidate-snapshot.ts:500–513` prechecks each binary and combined task/asset bytes
  using original artifactFileBytes/artifactTurnBytes before artifact I/O.
- `:568–659` obtains the exact owner projection, checks descriptor equality, original
  singly linked regular source, original file and disk-reserve budgets, copies exclusively
  with cancellation, then rechecks source/destination identity and whole-byte digest.
- Owner `readFiles` (`persistent-candidate-owner.ts:420–510`) opens the exact managed
  Version, validates Project/Session/file/Version/checksum/size, reads/hashes all bytes,
  verifiesUnchanged and closes its original lease in finally. MIME-declared binary is
  a descriptor even when its bytes happen to be valid ASCII/UTF-8.
- Owner materialization (`:1263–1455`) requires completed + cleanup-confirmed baseline
  or candidate, matching request digest/evidence ref and original export verification.
  It reserves inventory/turn bytes, validates the lease again, checks disk reserve,
  copies through original positional lease reads with AbortSignal, verifies whole bytes,
  closes the original lease, and revalidates cached projections before returning.
- The original lease and exact unique target remain tracked if close/cleanup fails
  (`:1327–1367`); shutdown aborts admission, waits active materializations/projections,
  retries owned cleanups and returns reaped=false while any cleanup is unconfirmed
  (`:1839–1856`). Deleting a directory is not used as a source lease-release witness.

Cancellation limitation, not a verified severe finding: the final native preparation
re-read calls `readOpenFileChunks(handle)` without a signal (`claude-candidate-preparation.ts:126`).
`prepareClaudeCandidate`'s preexisting API has no signal argument. Owner/source projection
and snapshot copy do carry signals, and `claude-candidate-driver.ts:91–93` rechecks
execution cancellation before opening/dispatching an owner. Therefore this review does
not claim immediate interruption of the final full-file native verification on slow I/O.
No new paid dispatch after that cancellation check bypass, resource authorization loss,
or demonstrated severe failure was found. An earlier no-signal text preparation API is
not proof of a stronger binary interruption guarantee.

### 0138d1df00c42173178311169ffbb538c9c2969c — JSONL envelope

`harness-optimization.ts:585–607` parses a plain JSON object, bounds frame bytes, requires
a positive safe correlation id and rejects reused ids before dispatch. The operation is
validated by the existing bounded string validator at the actual dispatch call. The
change copies the message and removes only transport-owned `id` and `operation`.
All other keys remain available to payload validators; no payload key is filtered out
to turn an otherwise invalid request into an accepted one.

In particular `materializeArtifact` still requires exactly `artifactRef,executionId`
(`:243–254`), an id in this binding's admitted set (`:224–225`), completed/confirmed
original result (`:261–268`), baseline/candidate role and a unique exact binary ref
(`:291–301`). Caller targetPath and any other extra field remain rejected. Assets
for another invocation likewise require admitted sourceExecutionId and exact original
binary descriptor (`:303–328`). The root callback uses Core.get and the same owner
(`run-persistent-optimization.ts:466–477`), not a caller file path.

## Original producer, Version and native Read authority

`persistent-candidate-owner.ts:1193–1247` binds execution id to the already existing
`candidate-prompt-${executionId}`, verifies original runtimeSessionAdmissions and pinned
Session evidence. Scientific artifacts require original completed Notebook Runs and
their real VersionExecution producer/terminal prompt. The original ManagedVersion lease
then revalidates bytes and ownership independently. This is not a second artifact DB or
an arbitrary Version reader exposed to the model.

The native tool gate (`claude-candidate-preparation.ts:179–220`) checks absolute,
unaliased, nonlinked paths. Read is limited to that invocation's private INPUT/OUTPUT/plugin;
Write/Edit remain OUTPUT-only. Source owner projection paths are not granted as native
read roots. Binary producer/reference identities stay in host provenance; models receive
only their admitted anonymous private copies. Existing scientific MCP calls retain the
original permission broker/producer requirement, frozen language and input restrictions.

## Fixed upstream comparison and algorithm scope

OpenScience pin: `9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5`.
Direct Git bytes and the existing fixed source snapshot agree. Seven original modules
are byte-identical at reviewed head: managed-file-versions service/read-port/version-file-operator,
immutable-input-authority, artifacts/provenance-producer-capture, artifacts/compute-output-evidence,
and file-io-pacing. bounded-file-io differs only by exporting its existing reader.
Exact SHA256 rows are in `binary-final-openscience-hashes.json`.

Harness² original checkout HEAD was verified as
`1cfe254e8d25b15f37048c3730134686abe60335`. All 14 original core modules at reviewed
head equal both pre-binary `b9dfebfa7451a9405dec0f335e5460c71fa3e370` and pre-three-fixes
`aedd3e209`. In particular the six files with historic integration seams — context.py,
prompts.py, proposer.py, recursion.py, schedule.py and selection.py — were not changed
by binary integration or these desktop fixes. Eight other original core modules also
remain byte-identical to the fixed Harness² pin. The six seam files differ from that pin
because of earlier integration; this report does not incorrectly label them original
byte-identical. Exact original/head hashes and both unchanged comparisons are saved in
`binary-final-harness-hashes.json`.

The three complete reviewed patches are saved as `binary-final-74ce.patch`,
`binary-final-2f08.patch`, `binary-final-0138.patch`. This review did not rerun algorithm
equivalence tests, native model/tool execution, full suites or builds. Compute implementation
and 0.2 Windows installer work remain outside this scoped binary review.
