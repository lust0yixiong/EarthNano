# EarthNano pinned source comparison

## win32
- Outcome: new-regressions
- Baseline tests: 115591; candidate: 116990; added: 1400
- Baseline failures: 7; skips: 4254; candidate failures: 6; skips: 4364
- New test regressions: 5; stage regressions: 0
- Baseline failures/skips remain unresolved evidence, not full acceptance. Equal failing statuses do not prove an identical cause.
