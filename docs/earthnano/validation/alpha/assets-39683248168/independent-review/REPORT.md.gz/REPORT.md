# Prepared Alpha assets 独立只读审查

结论：未发现 P1/P2。现有实际证据支持把以下确切四元组交给已审查的 `87c020a9a2f8ce71d59f1ab30703d99a7c379ccc` 首次双 draft 工具，继续执行其原始远端 preflight 与真实文件字节复验；本报告不替代那些门槛，不证明已生成 draft 或公开 release。

```text
prepared_run_id: 39683248168
prepared_run_attempt: 1
prepared_artifact_id: 12385377098
prepared_artifact_digest: sha256:73d26b24720dceaf72237d05ffd7745dc7994c9b7ff3a14db4335a884e5c52a4
```

## 实际身份与原执行步骤

- preparer：`2e8a03947add018cc9f0ee33def33f217e61ae11`，branch `ci/earthnano-alpha-assets`，`.github/workflows/earthnano-ci.yml`，实际 `workflow_dispatch`，run/attempt `39683248168/1`，唯一 job `119510793269`、run 与所有步骤均 completed/success。
- application source：`bdc0246383a25990030854f4c2fa100895f29ea6`，tree `25d834714406b65aff26b291a790e5c1749f94b1`，四份 manifest 均 clean、unsigned-ci、EarthNano 0.1.0-alpha.1、各 2 个 package，原 OpenScience/Harness² pins 与源 UPSTREAMS.json 完全相同；Electron expected/installed/binary 均 43.7.5。
- native `39658781703` 四目标、source `39658771118`、QA `39662102991` 在本次保存的 gate 记录均 completed/success。QA operational source 为 `9fae695a78c7f704645fd27894d4f1f887886255`、attempt1，证明 macOS ARM64 实际包；不扩展为其他架构 GUI 证明。
- 本次 workflow 使用固定 application source 的原 helpers，依次执行实际 source/bytes/cert/QA collect → Unix certification aggregate → Alpha mac feed merge → 8 包 SHA256SUMS 生成及 strict check → require-complete/mac,linux version manifest → Actions prepared upload。job step 结论全部 success，原 `checksums.log` 恰有 8 个对应文件的 `OK`。`verify-runs.log`、`collect.log`、`aggregate.log` 是原 helper 成功时的空输出；以实际成功步骤和相应源码为依据，不把空日志单独当执行证明。

## 小证据逐字节核对

本机读取的仅小 evidence.zip：4,771,646 bytes，SHA256 `594d460e265fb3eef8c184b8740eedad85b5803f4c2f3356c15566979454b113`，与 API artifact digest 及下载 receipt 相同。60 个唯一普通文件成员全部通过 ZIP CRC；无绝对/父目录路径或 symlink member。每个成员的 ZIP 内容、解压文件、receipt bytes/SHA256 都相同，解压树无额外文件。完整 60 项 inventory 位于 `facts.json: archive.members`。

本机另外对照已下载的新 bdc 原始归档：

- 4 target 的全部 16 个原 native 文件（manifest、builder-debug、certification、真实 DB certification）逐字节相同。
- 携带的 29 个 QA 文件逐字节等于 actual-bdc-success 原始归档，包括 original spec、projection byteproof、launch/acceptance、bundle inventories、Keychain binding、原业务日志与两个退出报告。process-exit 为原 wrapper/test=0、tee=0，final-verification=0。
- source comparison 的 JSON 和 Markdown 逐字节等于 final-source-bdc-complete 原 artifact。两个平台均 no-new-regressions、regressions/stageRegressions 空；保留 baseline failures/skips，不将此描述为所有测试零失败。

QA 当时记录的历史 release-gates/source 状态照原字节保留；本次 preparer 的 fresh source-run completed/success 记录另行核对，不回写历史证据。

## 24 条 staging 与 4 原 manifest

| target | staging 条目 | package | blockmap | 原 feed | cert + DBcert |
|---|---:|---:|---:|---:|---:|
| macos-arm64 | 7 | 2 | 2 | 1 | 2 |
| macos-x64 | 7 | 2 | 2 | 1 | 2 |
| linux-x64 | 5 | 2 | 0 | 1 | 2 |
| linux-arm64 | 5 | 2 | 0 | 1 | 2 |

24 个 stagedName 唯一；每条 sourcePath 都是相应原 manifest 唯一的 `dist/<filename>`，bytes/SHA256 逐项相等。唯一名称变化是两份原 alpha-mac.yml 隔离成 arm64-mac.yml/x64-mac.yml；不覆盖，不修改字节。Linux 本轮未生成 blockmap，未人为要求不存在的文件。完整 24 条及八包大小/SHA 在 facts.json 中保留。

四份 certification 的 source/ref/run/attempt 与 native 原身份一致，packageSmoke=passed，electronP0/visualRegression/authenticode=not-applicable。它们嵌入的 databaseMigration 与本机实际相应 DBcert JSON 深相等，freshInstall/legacyAdoption/reopen/specialPath 均 passed；cert/DBcert 文件本机 SHA 与 manifest/staging 均一致。每个 cert 的两个 package SHA 也与同 target manifest/staging 相同。

原合并 feed 日志的两个 ZIP URL、version、size 与实际 staging metadata 一致；SHA512 保留为 GHA 输出，未在本机重新散列大 ZIP。原 merge helper 默认调用原 validateUpdateFeed 做真实字节校验，本次未使用 metadata-only；原 require-complete manifest helper 和 strict SHA256SUMS 步骤在 GHA 实际成功。

## 大资产与后续边界

prepared artifact 的 API 记录为 `earthnano-alpha-prepared-bdc0-39683248168-1`、2,448,804,773 bytes，ID/digest 如上，未过期（保存记录时），workflow_run 绑定本 preparer SHA/run。**本审查没有下载此大 artifact，也没有在本机验证八个 package、其中 assets/version.json、SHA256SUMS.txt、RELEASE-CERTIFICATION.json 或原 per-arch feed 的实际字节。**这些大资产文件由本次 GHA 原 helpers 校验；本报告本机证据是小 ZIP 原 manifest/metadata/日志及步骤。

已核对 87c 原工具：重新读取 actual run/attempt/jobs/artifact/release/tag/workflow 状态后，经固定 download action digest-mismatch:error，再核全部 24 staged 文件 bytes/SHA、完整文件集合，重新跑原 aggregate/strict SHA256SUMS/feed merge/buildManifest；manifest 重建必须与原 notes/releaseDate 等完整对象 deepEqual。其后才允许同 28 份资产供两个 pinned action 创建 draft=true/prerelease=true/make_latest=false、overwrite=false 的同源草稿。首次创建/部分失败停止/不自动公开的原限制保留；不应绕过远端即时状态复核。

本目录保存的 `*-refs-before`、all-releases-empty、disabled-workflow metadata 是此前快照。报告交付时 parent 告知已精确建立两个指向 bdc 的轻量 tag，并单次启动 87c run39684743913；本审查没有调用 API 验证该后续状态，也不将此前 absent-tag 快照当成当前状态。87c 的原 preflight 本就允许精确同源的既有 tag，仍拒绝已有对应 draft/public release。

未更改仓库/PR/产品文件，未执行 CI、原 App、native 包、模型、Keychain 或 Windows；没有安装/构建/下载大资产。只读 Git 均限 EarthNano-release-sync，GIT_NO_LAZY_FETCH=1。`audit.py` 仅外部本地证据散列和对照，命令/结果保存在 audit-command.txt/audit-result.json；它不替代原发布验证体系。
