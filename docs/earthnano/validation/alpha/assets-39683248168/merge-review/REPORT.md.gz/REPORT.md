# PR23 最终整合合并审查

**无 P1/P2 finding；可将固定 PR23 head57441a04b4988c435c823042d61fc13e89e0e93e 以保留历史的 merge commit 并入当前 main2dee9be129bd6d66dae558bb94bc6e97d15400d7。** 不必逐个合并旧PR13–22；不要用squash/rebase替代这项保留原提交历史的整合。此结论是源码整合审查，不等于公开Alpha发布批准或资产已全部验收。

## 唯一 Git 根与树等价

全部 Git 操作仅在 /Users/yxmac_mini/Developer/EarthNano-release-sync，实际独立Git目录为该根/.git；没有使用旧CloudStorage或共享worktree Git。对象检查用GIT_NO_LAZY_FETCH=1，未fetch或触发远端操作。工作目录当前docs分支3a6caef仅被读取，没有切换/重置/写入。

PR23 head57441a04的父提交恰为4a31b9ae及bdc0246383。bdc是其直接祖先，二者tree均为25d834714406b65aff26b291a790e5c1749f94b1，git diff为空。origin/main2dee9be12是其祖先；共有184个待并入提交，因此在此main/head不变时，保留历史的合并结果可保持已验证产品tree，旧堆叠PR无需分别合入。后续main/head变化须重新核定身份，不能把本结论转移到其他树。

PR24相对4a只包含builder目标1行修改与79行原资源契约测试，80增/1删；5744完整保留该bdc提交，不是把发布产物换成docs-only源。当前docs PR25提交3a6caef不是5744祖先，也不混入此次产品树。

## 原 PR 历史

以下保留remote原分支head均确为5744祖先；分支与原PR关联依据既存pr-stack-current.json等本地记录，不查询或改写旧PR：

| PR | 保留head | 5744祖先 |
|---|---|---|
| #13 | `f921359ce2fc74ec72ec4e15e0eb8466c2591ae6` | 是 |
| #14 | `293d56015b82dcdfdb92a011c7d8877349e4507a` | 是 |
| #15 | `1d6df496d70d579e01d3bf1e7e7cf0a4c92d3a33` | 是 |
| #16 | `add1b517b6358aa8c89ae6cc07022e1003efe21e` | 是 |
| #17 | `4df93008e499941738d91dd75dc653fb033316b0` | 是 |
| #18 | `a554cde128bad308e0be3c6b4e3239fa53665049` | 是 |
| #19 | `dc6fdb20679bf2708159f76dc02f6ffa800f5612` | 是 |
| #20 | `ce0e1d498b46ddea5867bb795c6fad63dafb28b5` | 是 |
| #21 | `d89f3a8eb10e667aed1192cf589976af937ba8f9` | 是 |
| #22 | `aea6998ad12b2b3461e954783ce945cfd2d1f69d` | 是 |

另显式检查归档早期PR16头6e1a03bc、PR18精确ef9639c43、PR22发布头138179fd，全部也是祖先。全部精确值及当前原ref在ancestry-facts.json。PR13–22的内容、修复和原始失败历史不因umbrella合并而被挑选丢失。

## Windows 边界

延期Windows安装参数/NSIS probe/stage诊断工作未混入：archive/alpha-windows-native、fix/alpha-windows-0.2-preserved、fix/alpha-windows-installer-stage-diagnostic和source-windows-regressions各head均不是祖先；31abb6、28d873、82f0ba、03760d、14302b、f6329e等专项提交均不是祖先。最终树没有windows-nsis-arguments-probe新增脚本。

这不表示没有任何Windows相关历史差异：已审查的通用品牌/许可smoke适配、source fixture路径/文本编码、原目录持久化兼容与延期证据在历史内。windows-installer-smoke.mjs相对main的改动全部归于早期d8af1a7的metadata-driven品牌/许可检查，没有后续NSIS参数修复；原Windows源码保留。原native/selectedsource范围是macOS/Linux，Windows未被冒称通过或重新列为0.1门槛。

## 声明与实际证据

pr23-final-body.md与现有事实不冲突：

- 新完整source39658771118/attempt1已completed-success，headbdc。实际被测PR合并checkout328cb593的父为4a+bdc，tree同样25d834…；不是把旧4a对照替代bdc。原comparison的darwin/linux均no-new-regressions，stage/test回归数组为空。双方各115595→116940IDs；Mac2→2失败、3756→3765skip，Linux30→29失败、3778→3787skip；9新增opt-inskip保留，非全部测试通过。C独立原始Unix库存审查无P1/P2，报告与receipt原样保留。H2单独原5/集成77通过的声明与其报告范围一致，非live模型科研证明。
- native39658781703/attempt1/sourcebdc的四目标实际success，原安装/资源/launch与fresh/legacy/reopen/special-pathDB认证相符；本审查引用已有独立metadata报告，不把小archive/manifest当本机读完8个大包。
- MacARM真包science39662102991/attempt1/operator9fae/productbdc通过原业务spec。2baseline+6candidate、20/24admission（18complete/2cancel，cleanupconfirmed）、原producer/Version/Review、停止/续跑/重开、3同vaultKeychainmetadata、11123bundle记录不变和49Harness文件的声明与原独立报告一致。provider离线59fixture请求/0upstream，不能改称新DeepSeek、Compute/RPNG或普遍科研收益。
- body保留历史DeepSeek/Rbinary/Compute分层及未知用量/空Library、unsigned/非公证和Windows延期边界。当前资产preparer39683248168是独立Actions准备；正在上传的状态来自主智能体，不在本审查发API确认，也不当公开发布或两draft验收。后续docsPR25和真实全部资产/readback发布审查仍独立进行。

## 限制与交付

没有逐行重新审查184提交的全部业务实现，也未重复运行全套测试；本项只核整合历史、树与既有新证据的一致性。远端PR mergeability/branch protection和release publisher禁用状态沿既存快照及主智能体状态，不在本审查重新查询。没有源码/PR/仓库写入、依赖安装、构建、模型/native/App/Windows/CI/API操作。只在本外部目录保存报告与小receipt。
