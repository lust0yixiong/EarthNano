import { vi, afterAll } from 'vitest'
import { writeFileSync } from 'node:fs'

const clock = vi.hoisted(() => ({ ctimes: new Map<string, bigint>(), tamperWrites: 0 }))
vi.mock('node:fs/promises', async (importOriginal) => {
  const actual = await importOriginal<typeof import('node:fs/promises')>()
  const isTarget = (path: unknown): boolean => String(path).endsWith('_large.bin')
  const project = <T extends { ctimeNs?: bigint }>(path: unknown, stats: T): T => {
    if (!isTarget(path) || stats.ctimeNs === undefined) return stats
    const key = String(path)
    if (!clock.ctimes.has(key)) clock.ctimes.set(key, stats.ctimeNs)
    if (clock.tamperWrites >= 2) return stats
    return new Proxy(stats, {
      get(target, property, receiver) {
        return property === 'ctimeNs' ? clock.ctimes.get(key) : Reflect.get(target, property, receiver)
      }
    })
  }
  return {
    ...actual,
    writeFile: async (...args: Parameters<typeof actual.writeFile>) => {
      const data = args[1]
      if (isTarget(args[0]) && Buffer.isBuffer(data) && data.length === 256 * 1024 && data[0] === 8) clock.tamperWrites++
      return actual.writeFile(...args)
    },
    lstat: async (...args: Parameters<typeof actual.lstat>) => project(args[0], await actual.lstat(...args)),
    open: async (...args: Parameters<typeof actual.open>) => {
      const handle = await actual.open(...args)
      if (!isTarget(args[0])) return handle
      return new Proxy(handle, {
        get(target, property) {
          if (property === 'stat') return async (...options: Parameters<typeof target.stat>) => project(args[0], await target.stat(...options))
          const value = Reflect.get(target, property, target)
          return typeof value === 'function' ? value.bind(target) : value
        }
      })
    }
  }
})
afterAll(() => {
  const output = process.env.EARTHNANO_CLOCK_PROOF_OUTPUT
  if (output) writeFileSync(output, JSON.stringify({ tamperWrites: clock.tamperWrites, controlledMetadataOnly: true, realFilesAndContent: true, clockReleasedAfterSecondWrite: clock.tamperWrites >= 2 }, null, 2) + '\n')
})
