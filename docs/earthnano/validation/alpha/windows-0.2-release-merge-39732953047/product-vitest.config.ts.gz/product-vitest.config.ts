import { readFileSync } from 'node:fs'
import { availableParallelism, cpus } from 'node:os'
import { basename, dirname, resolve } from 'path'
import { configDefaults, defineConfig } from 'vitest/config'
import { packageTestExcludePatterns } from './scripts/ci/package-test-impact.mjs'
import WindowsTestSequencer from './scripts/ci/windows-test-sequencer'

const testRoot = resolve('.')
const sharedInstallRoot = basename(dirname(testRoot)) === '.worktree' ? resolve('../..') : testRoot
const windowsFullTest = process.env.VITEST_WINDOWS_FULL_TEST === '1'

export function resolveVitestMaxWorkers(
  available = typeof availableParallelism === 'function' ? availableParallelism() : cpus().length,
  override?: string
): number {
  if (override !== undefined) {
    const workers = Number(override)
    if (!/^[1-9]\d*$/.test(override) || !Number.isSafeInteger(workers)) {
      throw new Error('OPEN_SCIENCE_TEST_MAX_WORKERS must be a positive integer.')
    }
    return workers
  }
  return Math.max(available - 1, 1)
}

export const VITEST_ARCHITECTURE_TEST_GLOBS = [
  '**/*.architecture.test.ts',
  // Whole-repository graph scanning belongs after the parallel pool, retaining its timeout.
  'scripts/ci/module-consumer-coverage.test.ts',
  // This trust-boundary fixture starts dozens of Git/Node subprocesses; run it after the
  // parallel unit pool while keeping every assertion and its original timeout.
  'scripts/ci/pr-gate-workflow.test.ts'
] as const

export const VITEST_DATABASE_TEST_GLOBS = [
  'scripts/database-migration-ledger-smoke.test.ts',
  // Package round trips repeatedly migrate real validation databases. Keep their disk/CPU work
  // out of the parallel unit pool instead of extending the tests' timeout budget.
  'src/main/session-package/service.test.ts',
  'src/main/session-package/literature.test.ts',
  'src/main/session-package/fork.test.ts'
] as const

export const VITEST_PROCESS_TEST_GLOBS = [
  '**/*.integration.test.ts',
  '**/*.certification.test.ts',
  'src/main/notebook/kernel-executor.test.ts',
  'src/main/notebook/full-stack.smoke.test.ts',
  'src/main/local-rpc-transport.test.ts',
  'src/main/session-plan/plan-mcp-server.test.ts',
  'src/main/acp/mcp-http-host.test.ts',
  'src/main/settings/protocol-forwarding-bridge.test.ts',
  'src/main/settings/messages-bridge.test.ts',
  'resources/skills/literature-review/kernel.test.ts'
] as const

const BASE_VITEST_EXCLUDE_PATTERNS = [
  ...configDefaults.exclude,
  'e2e/**',
  // This native addon owns its node:test runner; Vitest cannot collect those suites.
  'packages/credential-identity-probe-native/test/**',
  'docs/internal/**',
  '**/.claude/**',
  '**/.codex/**',
  '**/.pnpm-store/**',
  '**/tmp/**',
  '**/.worktrees/**',
  '**/.worktree/**'
]
const VITEST_PORTABLE_CI_EXCLUDE_PATTERNS = [
  'src/renderer/src/i18n/resources.test.ts',
  'packages/notebook-network-sandbox/src/filesystem-enforcement.integration.test.ts',
  'packages/notebook-network-sandbox/src/network-enforcement.integration.test.ts',
  'src/main/session-plan/plan-context-file.shell.integration.test.ts'
] as const

function portableTestScopeFor(env: NodeJS.ProcessEnv): 'host' | 'packages' | undefined {
  if (env.VITEST_PORTABLE_CI !== '1' || !env.OPEN_SCIENCE_CI_PORTABLE_SCOPE) return undefined
  const scope = env.OPEN_SCIENCE_CI_PORTABLE_SCOPE
  if (scope !== 'host' && scope !== 'packages') throw new Error('Invalid CI portable test scope')
  return scope
}

function vitestExcludePatternsFor(env: NodeJS.ProcessEnv): string[] {
  const scope = portableTestScopeFor(env)
  return [
    ...BASE_VITEST_EXCLUDE_PATTERNS,
    ...packageTestExcludePatterns(env),
    ...(scope === 'host' ? ['packages/**'] : []),
    // Exclude every non-package root, including root-level tests and future host directories.
    ...(scope === 'packages' ? ['!(packages)/**', '*.{test,spec}.?(c|m)[jt]s?(x)'] : []),
    ...(env.VITEST_PORTABLE_CI === '1' ? VITEST_PORTABLE_CI_EXCLUDE_PATTERNS : [])
  ]
}

// These suites use the same package-owned configuration locally and in the host runner.
const standalonePackageRoots = [
  'packages/resilient-download',
  'packages/durable-files',
  'packages/compute',
  'packages/providers',
  'packages/pdf-structure',
  'packages/pdf-translation',
  'packages/literature-citations',
  'packages/journal-catalog',
  'packages/literature-discovery',
  'packages/literature-screening',
  'packages/literature-library',
  'packages/literature-reading'
]
const standalonePackageExcludes = standalonePackageRoots.map((root) => `${root}/**`)

const VITEST_EXCLUDE_PATTERNS = vitestExcludePatternsFor(process.env)
const portableTestScope = portableTestScopeFor(process.env)
const VITEST_COVERAGE_EXCLUDE_PATTERNS = [
  '**/*.test.{ts,tsx}',
  '**/*.d.ts',
  'src/**/index.ts', // process entry wiring
  'src/main/ipc.ts', // Electron IPC composition root
  'src/preload/**', // declarative ipcRenderer bridge
  'src/**/*types.ts',
  'src/renderer/src/main.tsx'
]
// Full-suite shards collect partial coverage maps. Only the merged report may enforce thresholds.

function coverageThresholdsEnabled(env: NodeJS.ProcessEnv): boolean {
  return env.VITEST_DEFER_COVERAGE_THRESHOLDS !== '1'
}

function fullSuiteShardAllowsEmptyProjects(argv: readonly string[]): boolean {
  return argv.some((argument) => argument === '--shard' || argument.startsWith('--shard='))
}

const FULL_COVERAGE_THRESHOLDS = {
  lines: 90,
  functions: 88,
  branches: 79,
  statements: 88
} as const

// `coverage.changed` limits the report to changed source files. Preserve its existing contract
// instead of requiring every selective diff to match the whole repository's aggregate baseline.
const CHANGED_SOURCE_COVERAGE_THRESHOLDS = {
  lines: 66,
  functions: 62,
  branches: 57,
  statements: 64
} as const

type CoverageThresholds = Record<
  string,
  number | { lines: number; functions: number; branches: number; statements: number }
>

function coverageThresholdsFor(env: NodeJS.ProcessEnv): CoverageThresholds | undefined {
  if (!coverageThresholdsEnabled(env)) return undefined

  const aggregate =
    env.VITEST_CHANGED_COVERAGE_THRESHOLDS === '1'
      ? CHANGED_SOURCE_COVERAGE_THRESHOLDS
      : FULL_COVERAGE_THRESHOLDS

  return {
    ...aggregate,
    // Temporary 1.0 baseline from Nightly 38516126264 after update-recovery expansion.
    // Restore lines 85 / statements 80 as recovery-path coverage is added.
    'src/main/update/**': {
      lines: 78,
      functions: 75,
      branches: 70,
      statements: 77
    },
    // CSV is a user-facing renderer with bounded-data and fallback behavior worth protecting.
    'src/renderer/src/pages/workspace/previews/renderers/CsvPreview.tsx': {
      lines: 95,
      functions: 95,
      branches: 80,
      statements: 95
    }
  }
}

// Mirrors the renderer alias from electron.vite.config.ts so tests that mount real component
// trees (instead of mocking every aliased import) can resolve '@/...' without a build step.
export default defineConfig({
  server: {
    // Vitest may still canonicalize worker URLs through the shared install even when module
    // resolution preserves symlinks. Limit the additional allowance to this repository root.
    fs: { allow: [...new Set([testRoot, sharedInstallRoot])] }
  },
  resolve: {
    // Git worktrees reuse the repository-root dependency install through a local node_modules
    // symlink. Keep that logical path so Vite does not resolve PDF workers outside the test root and
    // reject them before the component suite can run. A normal checkout already has a local install.
    preserveSymlinks: true,
    alias: {
      '@': resolve('src/renderer/src'),
      '@renderer': resolve('src/renderer/src'),
      'e-virt-table/dist/index.es.js': resolve('test/fixtures/fake-e-virt-table.ts')
    }
  },
  test: {
    // Only the advisory Windows full suite uses fixed module groups. Inherit Vitest's
    // sorting/group ordering; override just assignment, never test discovery or worker limits.
    ...(windowsFullTest ? { sequence: { sequencer: WindowsTestSequencer } } : {}),
    // Vitest shards each project independently. A valid full-suite shard can therefore contain no
    // files for one project even though its other projects execute tests.
    passWithNoTests: fullSuiteShardAllowsEmptyProjects(process.argv),
    // Keep successful suites quiet while retaining their captured console output on failure.
    silent: 'passed-only',
    server: {
      deps: {
        inline: ['@file-viewer/renderer-spreadsheet']
      }
    },
    // Loads .env into process.env before tests run. Integration tests gated on RUN_COMPUTE_JOBS=1
    // read their target alias from COMPUTE_TEST_SSH_ALIAS. The file is gitignored; .env.example
    // documents the supported variables.
    setupFiles: [
      './test/setup-dotenv.ts',
      './test/setup-jsdom-polyfills.ts',
      './test/setup-i18n.ts'
    ],
    // Keep vitest's defaults (node_modules, dist, .git, ...) and also ignore git worktrees — those hold
    // full source + node_modules copies that would otherwise be discovered and run as duplicate (and
    // often stale) suites during local runs. Playwright owns e2e/; Vitest must not execute those specs
    // in its Node workers. .worktree is the project-standard root; .claude remains excluded for
    // existing local checkouts.
    exclude: VITEST_EXCLUDE_PATTERNS,
    // Lift the 5s default: the full coverage run instruments 4400+ tests across parallel workers on a
    // shared CI runner, so a fast fully-mocked test can still be CPU-starved past 5s and time out
    // spuriously. 15s absorbs that contention without masking a genuine hang (real work is far slower).
    testTimeout: 15000,
    // Inline projects inherit these values before root CLI overrides are applied. Set the Windows
    // budget here so every project's hooks actually receive the workflow's intended 60 seconds.
    hookTimeout: windowsFullTest ? 60000 : 30000,
    // Pin the pool to Vitest's own CPU-minus-one bound so full-suite runs cannot spawn an unbounded
    // set of short-lived workers. Heavy files below run in later groups and do not share that pool.
    // Inline projects inherit this before CLI overrides, so provide a config-time worker cap.
    maxWorkers: windowsFullTest
      ? 1
      : resolveVitestMaxWorkers(undefined, process.env.OPEN_SCIENCE_TEST_MAX_WORKERS),
    projects: [
      ...standalonePackageRoots
        .filter(
          (root) =>
            portableTestScope !== 'host' &&
            !packageTestExcludePatterns(process.env).includes(`${root}/**`)
        )
        .map((root) => {
          const config = `${root}/vitest.config.ts`
          const index = standalonePackageRoots.indexOf(root)
          // Packages keep their own worker caps; Vitest requires separate scheduling groups.
          return index < 4
            ? config
            : {
                extends: config,
                root,
                test: { sequence: { groupOrder: index } }
              }
        }),
      {
        extends: true,
        test: {
          name: 'default',
          exclude: [
            ...VITEST_EXCLUDE_PATTERNS,
            ...standalonePackageExcludes,
            ...VITEST_ARCHITECTURE_TEST_GLOBS,
            ...VITEST_DATABASE_TEST_GLOBS,
            ...VITEST_PROCESS_TEST_GLOBS
          ]
        }
      },
      {
        extends: true,
        test: {
          name: 'architecture',
          include: [...VITEST_ARCHITECTURE_TEST_GLOBS],
          exclude: [...VITEST_EXCLUDE_PATTERNS, ...standalonePackageExcludes],
          isolate: false,
          fileParallelism: false,
          maxWorkers: 1,
          sequence: { groupOrder: 1 }
        }
      },
      {
        extends: true,
        test: {
          name: 'process',
          include: [...VITEST_PROCESS_TEST_GLOBS],
          exclude: [...VITEST_EXCLUDE_PATTERNS, ...standalonePackageExcludes],
          isolate: true,
          fileParallelism: false,
          maxWorkers: 1
        }
      },
      {
        extends: true,
        test: {
          name: 'database',
          include: [...VITEST_DATABASE_TEST_GLOBS],
          exclude: [...VITEST_EXCLUDE_PATTERNS, ...standalonePackageExcludes],
          isolate: true,
          fileParallelism: false,
          maxWorkers: 1,
          sequence: { groupOrder: 2 }
        }
      }
    ],
    coverage: {
      provider: 'v8',
      // text for the CI log, lcov for upload/tooling, html for local inspection.
      reporter: ['text', 'lcov', 'html'],
      reportsDirectory: './coverage',
      include: [
        'src/**/*.{ts,tsx}',
        ...JSON.parse(
          readFileSync(
            new URL('./scripts/ci/package-test-boundaries.json', import.meta.url),
            'utf8'
          )
        ).packages.map(({ root }: { root: string }) => `${root}/src/**/*.{ts,tsx}`)
      ],
      // Exclude non-logic files so coverage reflects testable code, not wiring/types.
      exclude: VITEST_COVERAGE_EXCLUDE_PATTERNS,
      // Keep the full-suite gate about one point below the measured main baseline. Selective
      // changed-source runs retain their separately calibrated compatibility thresholds.
      thresholds: coverageThresholdsFor(process.env)
    }
  }
})

export {
  CHANGED_SOURCE_COVERAGE_THRESHOLDS,
  coverageThresholdsEnabled,
  coverageThresholdsFor,
  FULL_COVERAGE_THRESHOLDS,
  fullSuiteShardAllowsEmptyProjects,
  VITEST_COVERAGE_EXCLUDE_PATTERNS,
  VITEST_EXCLUDE_PATTERNS,
  VITEST_PORTABLE_CI_EXCLUDE_PATTERNS,
  vitestExcludePatternsFor,
  portableTestScopeFor
}
