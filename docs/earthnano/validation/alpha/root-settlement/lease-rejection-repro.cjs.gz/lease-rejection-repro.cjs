const fs = require('node:fs');
const cp = require('node:child_process');
const assert = require('node:assert/strict');
const root = '/Users/yxmac_mini/Developer/EarthNano-worktrees/alpha-public-sync';
const ts = require(root + '/node_modules/typescript');
const upstream = '9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5';
const candidate = 'ef9639c43e88ac054b7b188f16cdbe8199ee33ac';
function source(rev, path) {
  return cp.execFileSync('git', ['show', `${rev}:${path}`], {cwd: root, encoding: 'utf8'});
}
function evaluate(text, stubs = {}) {
  const module = {exports: {}};
  const code = ts.transpileModule(text, {compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022}}).outputText;
  new Function('require', 'module', 'exports', code)((name) => {
    if (name.startsWith('node:')) return require(name);
    return stubs[name] ?? {};
  }, module, module.exports);
  return module.exports;
}
const observations = [];
async function run(rev, boundaryEnabled, delayedBaseline = false) {
  const {DelegationSettlementWakeOwner} = evaluate(source(rev, 'src/main/delegation/delegation-settlement-wake-owner.ts'));
  const wake = new DelegationSettlementWakeOwner({
    readSnapshot: async () => {
      if (delayedBaseline) await new Promise(resolve => setTimeout(resolve, 20));
      return {projectId: 'p', sessionId: 's', rootFrameId: 'root', activeRootPromptIds: ['prompt'], rootPromptRuntimeSegments: {prompt: 'segment'}, attempts: []};
    },
    dispatch() { throw new Error('No settlement dispatch expected'); }
  });
  const calls = [];
  const {AcpRuntimeCoordinator} = evaluate(source(rev, 'src/main/acp/runtime-coordinator.ts'));
  const coordinator = Object.create(AcpRuntimeCoordinator.prototype);
  const native = {sendPrompt: async () => {calls.push('native'); throw new Error('native preparation failed');}};
  Object.assign(coordinator, {
    promptAttemptSequence: 0, globalCancellationGeneration: 0,
    pendingPromptStarts: new Map(), activePromptRequests: new Map(), latestPromptRequests: new Map(),
    durableQuitDetachedSessionIds: new Set(), runtimeTargets: new Map(),
    admissionClosedReason: () => undefined, claimRuntimeAdmission: runtime => runtime,
    removePendingPromptStart: (id) => coordinator.pendingPromptStarts.delete(id),
    delegatedWork: {
      rootTurnStarted: async input => {calls.push('start'); return wake.onRootTurnStarted(input);},
      rootTurnEnded: async input => {calls.push(['end', input]); return wake.onRootTurnEnded(input);}
    }
  });
  if (boundaryEnabled) {
    const {createAcpExecutionBoundary} = evaluate(source(candidate, 'src/main/earthnano/acp-execution-boundary.ts'), {
      './execution-scope': {currentExecutionScope: () => undefined}
    });
    coordinator.executionBoundary = createAcpExecutionBoundary({host: {
      prepare: async () => {calls.push('host'); throw new Error('Original Session is unavailable');}
    }});
  }
  let error;
  try {
    await coordinator.dispatchAdmittedPrompt({sessionId: 's', text: 'task', provenanceContext: {promptMessageId: 'prompt'}}, undefined, 'sendPrompt', native);
  } catch (failure) { error = failure.message; }
  // Wait for an already-started readSnapshot to complete even when boundary rejection raced it.
  await new Promise(resolve => setTimeout(resolve, 40));
  const leases = [...wake.sessions.values()].reduce((n, state) => n + state.turnLeases.size, 0);
  const result = {revision: rev, boundaryEnabled, delayedBaseline, error, calls, remainingSettlementLeases: leases, remainingSessionStates: wake.sessions.size, pendingPrompts: coordinator.pendingPromptStarts.size, activePrompts: coordinator.activePromptRequests.size};
  observations.push(result);
  if (boundaryEnabled && rev === candidate) {
    assert.equal(leases, 1);
    assert.equal(calls.filter(call => Array.isArray(call) && call[0] === 'end').length, 0);
    assert.equal(calls.includes('native'), false);
  } else {
    assert.equal(leases, 0);
    assert.equal(calls.filter(call => Array.isArray(call) && call[0] === 'end').length, 1);
    assert.equal(calls.find(call => Array.isArray(call) && call[0] === 'end')[1].clean, false);
  }
  assert.equal(coordinator.pendingPromptStarts.size, 0);
  assert.equal(coordinator.activePromptRequests.size, 0);
}
(async () => {
  await run(upstream, false);
  await run(candidate, false);
  await run(candidate, true);
  await run(candidate, true, true);
  if (process.argv[2]) {
    await run(process.argv[2], true);
    await run(process.argv[2], true, true);
  }
  console.log(JSON.stringify({method: 'Transpile exact git objects; exercise unchanged coordinator dispatch method, real boundary host rejection and real DelegationSettlementWakeOwner. Stub native runtime and unrelated imports; no provider, database or root build.', observations}, null, 2));
})().catch(error => {console.error(error); process.exitCode = 1;});
