# Hosted Unix source CI: final read-only evidence and narrow static repair

PR18 run39583693350 (head a554cde128bad308e0be3c6b4e3239fa53665049) and PR20 run39585343040 (head ce0e1d498b46ddea5867bb795c6fad63dafb28b5) completed failure. Source collection job success is not test success. All artifacts/logs remain original; checksums in downloaded-artifacts-sha256.json.

## Per-run Linux facts

| Run | Baseline/candidate assertions | Failures baseline/candidate | Skips baseline/candidate | New unique failed IDs | Original comparison |
|---|---|---|---|---|---|
| PR18 |115595/116609|29/29|3778/3786|0|no-new-regressions|
| PR20 |115595/116664|29/57|3778/3787|28|new-regressions|

All8 Linux logical reports per run have original npm-ci/pretest/typecheck exit0 and test exits exactly explained by assertions. All16 raw Vitest inventories independently re-normalized with their original source helper; equal to uploaded inventories. Original validateSourceExecution accepts all runtime sidecars with zero unhandled/global errors. Re-running original compareReports over selected linux reproduces hosted Linux comparison exactly (PR18 succeeds, PR20 rejects as expected). No counter/skip/comparison rule changed.8/9 new skipped IDs remain unresolved inventory; baseline failures/skips are not acceptance.

Within each run all8 reports have Nodev24.22.0/x64/Electron43.7.5 and one actual runner ImageVersion: PR18 ubuntu24:20261012.334.1; PR20 ubuntu24:20261018.339.1. These are different experiments, not cross-run pairs. Baseline source is exact9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5. Actual candidate checkout is PR merge446c8f4ea8c78d68132ac9939f067b38a42b6742 /863d53862caae17ea0e58bf29273d941d961e667, not run headSha. API parent/tree metadata proves each includes the named PR head, and each merge tree equals its head tree. Original helper SHA256 is01043b008ac79ba48c29a6c633959d38c736871141d78589383bf2e4e0e75700 in both. Lock hashes are identical within each kind across shards/runs: baseline3466bdf3f5f10907e32c363a568748b6413b3b9adf953c9f6dea7a5f3ec84ebd; candidate0eeb220227bc4fc274fde06f429604a0ebd7142dc01989043c8cf37b09e33e77.

## Root causes and inherited failures

PR20's28 additional failures are the same IDs on macOS/Linux:25 audit ownership guards,2 host ownership/DAG guards,1 classification guard. Comparison lists56 regression entries because each originally passing failed ID appears under passed-to-failed and new-failure; this means28 failed assertions, not56. Exact original ce0 manifest + original tracked-file inventory audit proves3 missing owners: persistent-candidate-owner.binary.test.ts, candidate-artifact.test.ts, candidate-artifact.ts. Original audit output saved in pr20-original-scripts/original-audit.json. Shared contract introduction fdf3a26cb6871d843c3b5e1a924561dcf876fe44 and binary owner introduction b6b42ce50db41679227fec308a31c2412f4ff0a0 explain these omissions. They are real integration regressions, not environment failures.

Existing Linux29 failed IDs persist on both sides. Two PDF writer tests lack installed @aipoch/pdf-translation/resources/worker.mjs.23 sandbox filesystem/network assertions explicitly report missing bubblewrap; one shell-cell assertion also exposes that prerequisite in stderr. Three plan-context shell assertions fail with unsuccessful exit; do not claim an identical cause from status equality alone. These are complete, comparable assertion failures, not globally unavailable inventories. Before later acceptance the same real Linux runtime prerequisites must be supplied to both original/candidate and the packaging fixture failure investigated; never hide/skip them.

## Current source and minimal registration

Read-only audit of alpha-method at b72b92e73c0156abbe1c04b2eb9547305344e92a plus its existing4modified files: real audit CLI ok8039/8039, missing/routingGaps empty; original audit guards347/347; full original host architecture3/3. Matching old28 exact IDs proves27 already pass; only classification still fails. Commit56c083b1b909026b2cfebc386acab3173bcc453b already registered candidate-artifact.ts/.test to shared_optimization_contracts(owner/interface/owner test) and persistent-candidate-owner.binary.test.ts to main_optimization(owner/owner test). No DAG waiver or extra production repair is needed.

The remaining explicit win32 branches introduced by b6b42ce50 in persistent-candidate-owner.ts are missing from change-impact.json's exact windows_sensitive path overlay. Module inventory overlay alone does not populate this classifier's roots/GUI lanes. Parent approved a separate1line exact registration from6eec8d4fe2b724460c12628f71d6d63b66cb49fd. Original classify130:129pass/1fail; after change original classify130+audit347+host3=480/480 exit0; real audit CLI again8039/8039; original28 now allpass. Prettier/diff pass. No workflow,0.1 Unix scope, business code, runtime dependency or Windows operation changes.

## PR18 macOS failure kept separate

PR18 full Unix comparison fails because one additional Mac assertion fails: src/renderer/src/pages/workspace/previews/PreviewTextAnnotationSurface.test.tsx :: PreviewTextAnnotationSurface keeps the trigger after preview code highlighting retargets the selected code ::0. Raw candidate1 artifact and job119167704226 log saved under pr18-macos-candidate1/ and pr18-macos-candidate1-job.log. Line1623 waits for source-code-token count>0, gets0; earlier trigger-not-null check passed. Test file blob is unchanged(e5b412ad9a6881bac02f3cee0a67ca2aef0caaa8) at fixed original9e18, a554,ce0,current6eec. That does not prove flakiness or production cause. It remains a real new failure in this run; root assigns further source review separately.

No CI dispatch/cancel/retry, source-rule loosening, Windows debug/build/install, dependency rebuild or paid/API model call occurred. gh run operations explicitly target -R lust0yixiong/EarthNano; gh api does not support -R, so API GETs used fully explicit repos/lust0yixiong/EarthNano endpoints plus GH_REPO. Initial rejected -R API syntax was corrected without a request.
