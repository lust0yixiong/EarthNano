# Hosted macOS PreviewTextAnnotationSurface failure — bounded read-only review

## Disposition

The original hosted result remains a failure. I found no product/highlighter or dependency-lock change explaining it, and did not reproduce it in four bounded local runs. This is insufficient to label it a flake or clear the hosted failure. No test timeout/assertion was changed, no CI rerun was requested, and no source/environment repair is proposed on these facts.

## Immutable evidence and local baseline

Hosted raw evidence is unchanged at:
 /Users/yxmac_mini/Developer/EarthNano-validation/compute-fusion-20261021/hosted-linux-final/pr18-macos-candidate1/
and sibling pr18-macos-candidate1-job.log.

Hosted source-report identity: 446c8f4ea8c78d68132ac9939f067b38a42b6742; macOS arm64, Node24.22.0, macos15:20260907.0337.1, Electron43.7.5, shard1/4, maxWorkers2, original-full. Its lock digest is 0eeb220227bc4fc274fde06f429604a0ebd7142dc01989043c8cf37b09e33e77, exactly the currently inspected lockfile.

Current source inspected: 6eec8d4fe2b724460c12628f71d6d63b66cb49fd in alpha-method. It was not edited or switched; the already-present documentation WIP was left alone.

Local original baseline is a complete tracked git archive of exact fixed OpenScience 9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5 at this report directory's original-9e18/. The archive has no Git database; source bytes are from git archive of that exact object. Its sole dependency pointer is node_modules -> /Users/yxmac_mini/Developer/EarthNano-worktrees/alpha-integration/node_modules, the existing shared install. No install/build/change of those dependencies occurred.

Local corresponding current tests ran in independent clean alpha-ci-runtime at ae21e387156aae4551ba709e1895571119499ab3, not in the active alpha-method. The inspected highlighter/test/config bytes are the same at that source and current6eec. The unrelated invocation-context feature does not enter this renderer chain.

facts.json records raw assertion, environments, dependency locked entries, installed versions, archive pointer and local results. source-comparison.json records source Git blobs and SHA256 comparisons.

## Hosted failure facts

Exact failing ID:
 PreviewTextAnnotationSurface.test.tsx :: PreviewTextAnnotationSurface keeps the trigger after preview code highlighting retargets the selected code :: 0

- The first trigger-not-null assertion at line1618 passed.
- The failure is line1623: source-code-token count remained0 within vi.waitFor.
- Test duration1067.340583ms.
- Installed original Vitest4.1.11 waitFor implementation (dist/chunks/test.DNmyFkvJ.js3359–3361) defaults interval50ms and timeout1000ms. The outer --testTimeout=30000 does not change that local wait.
- The suite had52 assertions; the other51 passed. Runtime report has zero unhandled errors.
- The raw job/tests log contains no “Failed to load Markdown code highlighting” or “[Streamdown Code] Failed to highlight code” message.
- Two other raw failures in PDF translation writer tests are separate from this new ID, not hidden as successes by this report.
- The target suite overlapped src/main/literature/pdf-attachment-reliability.test.ts,39 cases, hosted suite span about54.2s. This is observed concurrency/load context, not proven root cause. No CPU/resource timeline was recorded that would establish delay causally.

The invalid revision/not-a-git-repository and deliberate TypeScript fixture messages in tests.log are from unrelated existing test exercises. They do not show a highlighter failure.

## Production and lock comparison

The following original-to-current Git blobs are identical (full hashes in source-comparison.json):
- PreviewTextAnnotationSurface.test.tsx: e5b412ad9a6881bac02f3cee0a67ca2aef0caaa8
- PreviewTextAnnotationSurface.tsx: b34c513a2669430128daadaa5669e9dd085e9964
- HighlightedCodeLines.tsx: 631cd4044413ad644c4a48db9ebaa113372a7e48
- use-code-highlighter.ts: c3ec0a2e651cd38fa21d884973af042b41671f1a
- code-highlighter-runtime.ts: 0111161455bdfe014f03d6b5bcb118086a5f0555
- renderer lib/utils.ts, vitest.config.ts, setup-jsdom-polyfills.ts, setup-i18n.ts: also byte-identical.

The full package-lock diff against9e18 changes only root version1.0.0 to0.1.0-alpha.1 in two places. No dependency lock entry changed. Inspected installed versions equal the locked versions, including @streamdown/code1.1.1, streamdown2.5.0, shiki/@shikijs3.23.0, React/ReactDOM19.2.7, Vitest4.1.11, Vite7.3.6 and jsdom29.1.1.

The actual path remains:
 HighlightedCodeLines -> useCodeHighlighter -> asynchronous import code-highlighter-runtime -> @streamdown/code -> asynchronous Shiki createHighlighter with TypeScript grammar/themes and JavaScript regex engine -> highlight callback -> setHighlighted -> token/source equality gate -> source-code-token spans.

Preview plain text is intentionally rendered before optional highlighting. A zero token count alone cannot distinguish pending dynamic import/highlighter initialization, plugin failure, callback lifecycle cancellation, or token/source mismatch. Source identity plus local pass does not settle which happened on the hosted runner.

## Bounded local runs

No source/test edits; all use existing dependencies and --no-cache. Local environment is macOS arm64 Node26.0.0, which differs from hosted Node24.22.0.

| Run | Result | Target duration |
| --- | --- | --- |
| corresponding current, cold target only, maxWorkers1 |1 passed/51 skipped |213.36325ms |
| exact original9e18, cold target only, maxWorkers1 |1 passed/51 skipped |202.888625ms |
| corresponding current, full original file, maxWorkers2 + hosted outer timeouts |52 passed/0 failed |145.65325ms |
| exact original9e18, full original file, same options |52 passed/0 failed |142.596083ms |

Raw current-target/original-target/current-file/original-file .json and .log files are retained here. These are four local observations only; they do not reproduce the full hosted shard, cold CI filesystem/transformation state, Node24 environment, or co-running PDF suite. The full-file runs used the original assertions, including the unchanged1000ms wait.

## Minimal next step

No code/timeout/assertion change is supported by this diagnosis. Keep the hosted failure open in the original-pin comparison. As authorized by root, the next integrated PR's natural fixed-pin hosted comparison should process this exact ID using its real result. If it repeats, capture phase timing for the original dynamic import/highlighter callback and original source-selection token check in a separate diagnostic artifact under the same hosted Node/image/worker/shard conditions, paired with the original pin. Do not infer success from a targeted local pass or omit the ID from comparison.

No standalone CI run, API/model call, Windows diagnosis, package build/install, or production edit was performed.

