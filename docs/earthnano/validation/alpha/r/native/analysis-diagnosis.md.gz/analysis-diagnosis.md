# 原 R 输入证据诊断（只读）

结论：本次 ArtifactVersionInput=0 由固定上游对 `jsonlite::toJSON` 的保守 source-analysis 约束触发。`utils::read.csv` 与不带命名空间的 `read.csv` 均已受支持；`jsonlite::write_json` 也已受支持。没有发现此次失败由融合层漏传输入、alias 或授权造成的证据。

## 可复核实验

使用原生产 provisioner 安装的 R 4.4.3：`/Users/yxmac_mini/Developer/EarthNano-validation/r-restoration-20261021/storage/runtime/envs/default-r/bin/Rscript`。没有下载或安装包，没有执行付费 provider，没有修改任何仓库文件。

1. `compare.cjs` 用 git archive 导出的精确上游 9e18c7d 的 notebook-analysis TypeScript 源码（内存转译，无依赖构建）分析 12 个组合，并在同一真实 R 环境逐个执行。
2. `observer-compare.cjs` 用当前只读 runtime 树的原 observer + 原 graph + 原 execution-snapshot 做 4 个隔离真实文件 fixture；这些源文件与上游及 candidate 72a721d30 已逐字节核对相同。
3. `verify.py` 对实验结果执行严格断言。16 次实际 R 执行均 exit 0，所有生成的 JSON 都是 `{count:3,sum:12,mean:4}`。仓库仍干净。

| CSV 调用 | 输出调用 | source 读/写/external | 原 observer | producer snapshot 输入 |
| --- | --- | --- | --- | --- |
| utils::read.csv / read.csv | write_json(report,...); print(report) | complete | available / fileReads complete | 1，精确 frozen-old-upload-version |
| utils::read.csv / read.csv | write_json(report,...); print(toJSON(report,...)) | partial，opaque-call | partial / fileReads partial | 0 |

两种 CSV 调用在上述对照中行为一致。12 组合还分别隔离 none、write_json、toJSON、write_json+toJSON、literal writeLines、动态计算结果 cat(sprintf(...))：只有包含 toJSON 的组合产生 opaque-call 和 source-analysis-unsupported-call。literal writeLines 仅是分析器对照，不能作为科学正确性的正向脚本建议。

## 源码链条（runtime 树中的行号）

- `packages/notebook-analysis/src/dependency-analysis-r.ts:1208`：jsonlite 显式读函数 fromJSON/read_json/parse_json，输出 write_json；没有 toJSON。
- 同文件 `:2998`：qualifiedValueFileRead 明确支持 base/utils 的 CSV/table 读取；`:3139` 支持 jsonlite 的上述已知函数。
- `packages/notebook-analysis/src/source-file-access-analysis.ts:62`：unknown reason 中的 opaque-call 使 dependencyAnalysisUnavailable；`:79` 添加 source-analysis-unsupported-call，后续读写 coverage 保守为 partial。单纯 external-state 不会触发这一降级。
- `src/main/notebook/working-file-observer.ts:1464`：注册输入映射为 data/inputs/<filename-checksum>.csv。`:1589` 按 cwd 规范化相对路径。实验中原始 `inputs/...` 正确映射为 `data/inputs/...`，两种脚本的 present-before relation 都保存同一个精确 Version ID 与 checksum，证明 alias/登记并未丢失。
- 同文件 `:1686`：只有 source reads complete 且 initial generation 冻结成功才认可 fileReads complete；`:2051` 限制 confirmedReadPaths。`run-terminalization.ts:106` 据此添加 accessEvidence=file-evidence。
- **决定 producer 投影的直接 gate 是 graph 的 used edge，而不只是 accessEvidence 字段。** `src/main/artifacts/artifact-provenance-graph.ts:902` 只把 fileReads complete 的 present-before generation 视为已使用。partial 样本虽保存注册 Version 与原始字节，仍不制造 used edge。
- `src/main/artifacts/provenance-execution-evidence.ts:315` 只保留 graph 中有 used edge 的 registered-input-generation；因此上述 partial 样本的 execution snapshot inputFiles=[]。`provenance-producer-capture.ts:505` 使用这个投影，`:648` 按投影创建 ArtifactVersionInput，因此最终计数 0。

## 对根测试的建议与边界

保留当前强断言 1。正向 R 科研脚本保留动态读取、真实计算及 write_json 输出，将纯展示用 `print(jsonlite::toJSON(report,...))` 改为原分析器支持的 `print(report)`（也可不额外 print，结果应从真实产物 JSON 验证）。继续强验证旧 Version、正确字节与科学统计、同一 Core、独立 Sessions/Runs、producer 精确绑定及 reopen。

另保留一个独立 toJSON 对照，显式断言真实执行成功、正确结果字节、原始 inputFiles 与 present-before 注册事实仍在，同时 source/文件读取 coverage 是 partial、没有 confirmedReadPaths/已使用输入边，producer 不得伪造完整溯源。这个对照用于保护未知事实，不能替代主正向 strong assertion，也不能宣称 partial 路径的重放输入已证实。

此诊断只证明固定上游 analyzer/observer/graph/snapshot 在隔离文件 fixture 的上述行为。**没有重跑或修复融合的 R 科研强断言；72a721d30 的实际 R 科研输入溯源验收仍失败/未通过。** Core 授权链、完整 DB producer persistence、Review reopen、停止/超时等集成验收不由此诊断代替。没有提交、push 或源码修改。

## 证据

- source-identity.json：12 个上游/72a/runtime 源文件一致性。
- comparison.json / comparison.log / compare.cjs：12 组原分析器 + 真实 R。
- observer-comparison.json / observer-comparison.log / observer-compare.cjs：4 组真实 observer + graph + snapshot，包括完整冻结关系、hash、精确 Version ID、used edges。
- verify.py / verification-summary.json：严格结果核验与任务范围。
