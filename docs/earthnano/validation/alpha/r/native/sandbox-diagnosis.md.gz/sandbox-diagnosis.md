# 原 macOS R sandbox 诊断（只读）

结论：这次 exit 126 是原上游对位于用户私有路径的 external conda R 安装自动授权范围有限，叠加 E2E fixture 只登记解释器、未显式授予其安装目录读取权限导致。它不是 toJSON 问题，也未发现融合生产代码漏接 sandbox 路径：8 个关键文件与固定上游 9e18c7d 和候选 7f687e3f9 逐字节一致。

## 原调用关系

1. `packages/environment/src/environment-discovery.ts:390`：只合并同目录 `bin/R` 与 `bin/Rscript`；`:527` 的 rscriptFor 将末尾 R 替换为 sibling Rscript。它不查询 R.home，也不识别/授予 `lib/R/bin/R` 作为完整运行时读取根。原始 probeR 在 sandbox 外能检测 R4.4.3 与 jsonlite；该结果不证明后续隔离启动具有全部读取权限。
2. `src/main/notebook/runtime-binding.ts:722`：external R binding 通过 rscriptFor 生成 command。external condaPrefix 推导 windowsCondaPrefixForR 仅 Windows 生效；Darwin没有附加该 prefix。
3. `src/main/notebook/kernel-executable-read-root.ts:29`：Darwin R 返回 dirname(executable)，所以本次仅为 `<external-prefix>/bin`。
4. `src/main/notebook/kernel-executor.ts:1197`：readOnlyRoots 包含当前应用 request.runtimeRoot、resolved condaPrefix（Darwin外部R没有）、R library（如果有）、inputRoot、kernelExecutableReadRoot、loop与PATH roots。当前 E2E 应用 runtimeRoot 与 restoration runtimeRoot 是两个独立目录。
5. `src/main/notebook/network-sandbox-owner.ts:488,536`：读取原 GrantedLocalRoot owner 的列表并合入只读 roots；`:552` 仅 access=rw 的授权进入可写 roots。因此既有 grantRoot({path: exactPrefix, access:'ro'}) 足以授予读取，不授予运行时写权限。
6. `packages/notebook-network-sandbox/runtime/src/platform/macos-isolation.ts:39`：敏感目录 `/Users` 等只允许精确 readable 子树，其他读取被拒；`:76` 限制写入可写根。当前 `<prefix>/bin/Rscript` 是普通 Mach-O executable，启动 `<prefix>/lib/R/bin/R` shell wrapper，再到真实 R engine；R脚本与依赖库均需要同一安装 prefix 的读取权限。bin 权限不足。

## 同环境原源码复现

`reproduce.cjs` 通过 git show 导出 9e18c7d 原 macosLaunch/seatbeltProfile、filesystem-layout、kernelExecutableReadRoot 与 r_loop.R。只内存转译这些 TypeScript，未 build/安装依赖，直接通过 `/usr/bin/sandbox-exec` 启动原真实 R loop，无 mock kernel、无网络请求、无付费。

同一个已安装 R：
`/Users/yxmac_mini/Developer/EarthNano-validation/r-restoration-20261021/storage/runtime/envs/default-r/bin/Rscript`

| 隔离配置 | 原 R loop 实际结果 | 环境目录写探针 | 其他私有文件读探针 |
| --- | --- | --- | --- |
| 原 bin-only 权限 | exit 126，lib/R/bin/R: Operation not permitted | exit1，Operation not permitted，无文件产生 | exit1，Operation not permitted，无内容 |
| 加精确 default-r prefix **只读** | exit0，原协议 error=null、execution_started=true、R4.4.3；产物 count3/sum12/mean4 | exit1，Operation not permitted，无文件产生 | exit1，Operation not permitted，无内容 |

原 profile 没有改规则，没有禁用 sandbox，没有授予环境写入，没有授予 runtime/envs 父目录或用户 home。两份完整 profile 保存在 fixtures/*/profile.sb，结果与完整原 R 协议响应保存在 sandbox-comparison.json；reproduction.log 末尾严格断言全部通过。外部私有文件 fixture 只用于证实授权没有外溢。

`discovery.cjs` 进一步实测原 public discovery helpers：bin R/Rscript 被合为 bin/R；rscriptFor 恢复 bin/Rscript；Darwin condaPrefix 为 null；原无隔离 probeR 判为 R4.4.3/runnable=true。这证明“目录外部注册成功且 runnable”与“隔离 kernel 自动获得全安装读取权限”是原路径的不同检查，不应混为一个通过。

## 最小原路径配置修正

在这个特定 E2E 的显式外部 R 选择/登记后，沿原 Files API 调用：

```ts
await window.api.localFs.grantRoot({
  path: '/Users/yxmac_mini/Developer/EarthNano-validation/r-restoration-20261021/storage/runtime/envs/default-r',
  access: 'ro'
})
```

此路径是所选解释器所属的精确安装 prefix；其 bin、lib/R、共享库在同一边界内。不要改为其 storage/runtime 父目录、envs、home 或 rw。仅换登记为 sibling bin/R 不会解决权限范围，因为最终 command 仍为同一个 bin/Rscript。可由 fixture 的显式环境变量提供只读 root，保持测试环境位置可配置。

生产的 managed 路径则原本把本应用自己的 request.runtimeRoot 作为只读根；如果使用原 managed runtime，应通过原 provisioner/storage 所属路径配置，不应把别的私有目录伪装成本应用 managed owner。今回不执行此替代方案。

## 独立 micromamba 配置项

原桌面日志 line197 报 `micromamba binary not found`，发生于生产 factory 初始化，是另一个测试环境资源未配置事实。已有可读 binary：
`/Users/yxmac_mini/Developer/EarthNano-validation/r-restoration-20261021/tools/micromamba`

`src/main/notebook/environment-resources.ts:48` 原样支持 `OPEN_SCIENCE_MICROMAMBA_BIN`。`discovery-comparison.json` 验证使用这个精确 override 能由原 resolveMicromambaLocations 定位，kind=override。设置此原环境变量能消除“找不到工具”配置错误；它本身不授予外部 R 文件读取，也不等价于环境 provisioning/desktop 验收通过。本诊断没有运行 installer/provisioner，没有追加包安装。

## 验收边界与保存状态

原普通 Send 的初次失败日志由 desktop-failure-extract.json 保存路径、行号与SHA256。该失败根因已由上面原源码/真实 R/sandbox 对照复现。

本次只读实验没有重跑完整桌面 Harness 双mode、停止续跑、Review/reopen，也不把隔离原 R loop 当作这些验收。Root 后续报告其 E2E-only fixture commit72444d533 已沿原 grantRoot(ro)配置路径并通过普通 Send，继续运行后续桌面阶段；这是 root 的进度，不属于此隔离对照独立验收。

运行树 `/Users/yxmac_mini/Developer/EarthNano-worktrees/alpha-ci-runtime` HEAD97f0db284 仍干净。没有修改root/生产代码、原测试断言或依赖，没有commit/push。任务在保存本报告后停止。

主要证据：source-identity.json、sandbox-comparison.json、reproduction.log、reproduce.cjs、discovery-comparison.json、discovery.log、discovery.cjs、verification-summary.json、desktop-failure-extract.json。
