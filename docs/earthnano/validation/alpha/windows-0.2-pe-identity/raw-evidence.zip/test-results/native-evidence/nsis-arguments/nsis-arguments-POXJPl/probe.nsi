﻿Unicode true
!addincludedir "${APP_BUILDER_NSIS_DIR}"
!addincludedir "${APP_BUILDER_NSIS_DIR}\include"
!addplugindir /x86-unicode "${APP_BUILDER_NSIS_PLUGIN_DIR}"
!include "LogicLib.nsh"
!include "${APP_BUILDER_NSIS_DIR}\include\StdUtils.nsh"
!define APP_GUID "earthnano-argument-observation"
!define UNINSTALL_APP_KEY "earthnano-argument-observation"
!define INSTALL_MODE_PER_ALL_USERS
!include "${APP_BUILDER_NSIS_DIR}\multiUser.nsh"
Name "EarthNano NSIS argument observation"
OutFile "probe.exe"
InstallDir "$EXEDIR\default-target"
RequestExecutionLevel user
SilentInstall silent
Section
  System::Call 'kernel32::GetCommandLineW() w .r1'
  StrCpy $2 $INSTDIR
  !insertmacro GetDParameter $R0
  ${If} $R0 != ""
    StrCpy $INSTDIR $R0
  ${EndIf}
  ClearErrors
  FileOpen $0 "$EXEDIR\observation.txt" w
  IfErrors failed
  FileWriteUTF16LE /BOM $0 "$1$\r$\n$CMDLINE$\r$\n$INSTDIR$\r$\n$R0$\r$\n$2"
  FileClose $0
  IfErrors failed
  SetErrorLevel 0
  Goto done
failed:
  SetErrorLevel 3
done:
SectionEnd
