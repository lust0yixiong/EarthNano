﻿!macro customInstallMode
  # Notebook AppContainer profiles are per-user durable resources. A machine-wide installation
  # cannot safely create, identify, and remove one profile for every Windows account, so keep the
  # assisted installer and uninstaller bound to the current user.
  StrCpy $isForceCurrentInstall "1"
!macroend

!macro customUnInstall
  # Updates run the old uninstaller with isUpdated set and must retain the durable profile. Only a
  # real product uninstall removes the AppContainer resources.
  ${ifNot} ${isUpdated}
    nsExec::ExecToLog '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$INSTDIR\resources\windows-update-handoff-uninstall.ps1" -InstallPath "$INSTDIR"'
    Pop $0
    StrCmp $0 "0" updatePresentationCleanupComplete
    DetailPrint `Open-Science update presentation cleanup failure code=$0`
    MessageBox MB_OK|MB_ICONSTOP "An Open-Science update may still be active. Finish the update and close its update window, then retry uninstall."
    Abort
    updatePresentationCleanupComplete:
    nsExec::ExecToLog '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$INSTDIR\resources\windows-notebook-sandbox-uninstall.ps1" -SandboxRoot "$INSTDIR\resources\notebook-network-sandbox\windows"'
    Pop $0
    StrCmp $0 "0" notebookSandboxCleanupComplete
    DetailPrint `Open-Science Notebook cleanup failure code=$0 sandboxRoot="$INSTDIR\resources\notebook-network-sandbox\windows"`
    MessageBox MB_OK|MB_ICONSTOP "Open-Science could not safely remove its owned Notebook isolation resources. The uninstall was stopped so the cleanup can be retried."
    Abort
    notebookSandboxCleanupComplete:
  ${endif}
  nsExec::ExecToLog '"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "$INSTDIR\resources\windows-runtime-cache-uninstall.ps1"'
!macroend

!ifndef BUILD_UNINSTALLER
!define MUI_CUSTOMFUNCTION_ABORT restorePreservedOnAbort
!include "D:\a\EarthNano\EarthNano\build\windows-update-handoff.nsh"
!include "D:\a\EarthNano\EarthNano\test-results\native-evidence\installer-stages\installer-stage-TngEMm\overlay\windows-install-publication.nsh"

# Quit bypasses .onInstFailed and every other NSIS callback. Publish the existing failure
# receipt at each explicit failure exit so the detached presentation can become dismissible.
!macro quitFailedUpdate
# EARTHNANO_STAGE_BEGIN
Push "QUIT_FAILED_UPDATE"
Call earthNanoDiagnosticStage
# EARTHNANO_STAGE_END
  Call cleanupInstallPublication
  Push "failed"
  Call writeUpdateReceipt
  SetErrorLevel 2
  Quit
!macroend

Var perMachineInstallDirCache
Var perUserInstallDirCache
Var perMachineDataBackup
Var perUserDataBackup
Var perUserDataBackupBranded
Var perMachineDataBackupBranded
Var retryLegacyDataBackup
Var retryBrandedDataBackup
Var retryRegisteredBrandedBackup
Var dataProtectionFailed
Var dataRestoreFailed

# Registry values that identify the same Windows directory may differ only in letter case or a
# trailing separator. LogicLib's == comparison is already case-insensitive; trim separators here
# so every later shared-path decision uses one canonical form. Keep drive roots such as C:\ intact.
Function normalizeRegisteredInstallPath
  Exch $R0
  Push $R1

  normalizeRegisteredInstallPath_loop:
    StrLen $R1 $R0
    IntCmp $R1 3 normalizeRegisteredInstallPath_done normalizeRegisteredInstallPath_done
    StrCpy $R1 $R0 1 -1
    StrCmp $R1 "\" normalizeRegisteredInstallPath_trim
    StrCmp $R1 "/" normalizeRegisteredInstallPath_trim normalizeRegisteredInstallPath_done

  normalizeRegisteredInstallPath_trim:
    StrCpy $R0 $R0 -1
    Goto normalizeRegisteredInstallPath_loop

  normalizeRegisteredInstallPath_done:
    Pop $R1
    Exch $R0
FunctionEnd

# Move a data root outside the installation before the OLD uninstaller sees it. A deterministic
# sibling path lets an elevated inner installer or a later retry recover data left by an
# interrupted outer installer without relying on process-local registers.
!macro preserveNamedDataRoot DIR BACKUP SLOT FOLDER
  StrCpy ${BACKUP} ""
  ${if} "${DIR}" != ""
    ClearErrors
    # NSIS GetFullPathName requires the parent to exist. A stale InstallLocation may outlive
    # that directory after a manual move/delete. Resolve lexically with the Windows API so
    # absent data is a no-op, while existing data and interrupted backups still use the guards.
    System::Call 'kernel32::GetFullPathName(t "${DIR}\..", i ${NSIS_MAX_STRLEN}, t .R2, p 0) i.R3'
    ${if} $R3 == 0
    ${orIf} $R3 >= ${NSIS_MAX_STRLEN}
      SetErrors
    ${else}
      # Only a missing parent is harmless. Keep refusing paths whose attributes cannot be read
      # for other reasons (permissions, unavailable drives, invalid paths).
      System::Call 'kernel32::GetFileAttributes(t R2) i.R3 ?e'
      Pop $R4
      ${if} $R3 == -1
      ${andIf} $R4 != 2
      ${andIf} $R4 != 3
        SetErrors
      ${endif}
    ${endif}
    ${if} ${Errors}
      DetailPrint `Open-Science data protection failure code=parent-path-unresolved path="${DIR}\${FOLDER}"`
      DetailPrint `Could not safely preserve "${DIR}\${FOLDER}"; its parent path could not be resolved.`
      MessageBox MB_OK|MB_ICONSTOP "Open-Science could not safely protect its data folder before updating.$\r$\nThe existing data was left untouched."
      StrCpy $dataProtectionFailed "1"
    ${else}
      StrCpy ${BACKUP} "$R2\.open-science-update-data-${SLOT}"
      ${if} ${FileExists} "${DIR}\${FOLDER}\*.*"
        ${if} ${FileExists} "${BACKUP}\*.*"
          DetailPrint `Open-Science data protection failure code=backup-already-exists path="${DIR}\${FOLDER}" backup="${BACKUP}"`
          DetailPrint `Could not safely preserve "${DIR}\${FOLDER}" because the backup path already exists: ${BACKUP}`
          MessageBox MB_OK|MB_ICONSTOP "Open-Science found both the current data folder and an earlier update backup.$\r$\nNo data was changed. Please inspect:$\r$\n${BACKUP}"
          StrCpy ${BACKUP} ""
          StrCpy $dataProtectionFailed "1"
        ${else}
          ClearErrors
          Rename "${DIR}\${FOLDER}" "${BACKUP}"
          ${if} ${Errors}
            DetailPrint `Open-Science data protection failure code=preserve-rename-failed path="${DIR}\${FOLDER}" backup="${BACKUP}"`
            DetailPrint `Could not safely preserve "${DIR}\${FOLDER}"; leaving the existing installation untouched.`
            MessageBox MB_OK|MB_ICONSTOP "Open-Science could not safely protect its data folder before updating.$\r$\nThe existing data was left untouched."
            StrCpy ${BACKUP} ""
            StrCpy $dataProtectionFailed "1"
          ${else}
            DetailPrint `Protected the data folder at: ${BACKUP}`
          ${endif}
        ${endif}
      ${elseif} ${FileExists} "${BACKUP}\*.*"
        # A previous installer exited before it could restore. Adopt that deterministic backup
        # and restore it through the normal post-uninstall path.
        DetailPrint `Found data preserved by an interrupted update at: ${BACKUP}`
      ${else}
        StrCpy ${BACKUP} ""
      ${endif}
    ${endif}
  ${endif}
!macroend

!macro restoreNamedDataRoot DIR BACKUP FOLDER
  ${if} "${DIR}" != ""
  ${andIf} "${BACKUP}" != ""
    ${if} ${FileExists} "${BACKUP}\*.*"
      ${if} ${FileExists} "${DIR}\${FOLDER}\*.*"
        DetailPrint `Open-Science data protection failure code=restore-destination-exists path="${DIR}\${FOLDER}" backup="${BACKUP}"`
        DetailPrint `The preserved data remains at: ${BACKUP}`
        MessageBox MB_OK|MB_ICONSTOP "Open-Science could not restore its data folder because the destination already exists.$\r$\nThe preserved data remains at:$\r$\n${BACKUP}"
        StrCpy $dataRestoreFailed "1"
      ${else}
        CreateDirectory "${DIR}"
        ClearErrors
        Rename "${BACKUP}" "${DIR}\${FOLDER}"
        ${if} ${Errors}
          DetailPrint `Open-Science data protection failure code=restore-rename-failed path="${DIR}\${FOLDER}" backup="${BACKUP}"`
          DetailPrint `The preserved data remains at: ${BACKUP}`
          MessageBox MB_OK|MB_ICONSTOP "Open-Science could not restore its data folder after updating.$\r$\nThe preserved data remains at:$\r$\n${BACKUP}"
          StrCpy $dataRestoreFailed "1"
        ${else}
          DetailPrint `Restored the data folder to: ${DIR}\${FOLDER}`
          StrCpy ${BACKUP} ""
        ${endif}
      ${endif}
    ${else}
      # Another installer instance may already have restored the deterministic backup.
      StrCpy ${BACKUP} ""
    ${endif}
  ${endif}
!macroend

!macro preserveNestedDataRoot DIR BACKUP SLOT
  !insertmacro preserveNamedDataRoot ${DIR} ${BACKUP} ${SLOT} OpenScience
  ${if} $dataProtectionFailed == "0"
    !insertmacro preserveNamedDataRoot ${DIR} ${BACKUP}Branded ${SLOT}-branded Open-Science
  ${endif}
!macroend

!macro restoreNestedDataRoot DIR BACKUP
  !insertmacro restoreNamedDataRoot ${DIR} ${BACKUP} OpenScience
  !insertmacro restoreNamedDataRoot ${DIR} ${BACKUP}Branded Open-Science
!macroend

!macro restoreAllNestedDataRoots
  StrCpy $dataRestoreFailed "0"
  !insertmacro restoreNestedDataRoot $perMachineInstallDirCache $perMachineDataBackup
  !insertmacro restoreNestedDataRoot $perUserInstallDirCache $perUserDataBackup
!macroend

!macro quitIfDataRestoreFailed
  ${if} $dataRestoreFailed != "0"
    !insertmacro quitFailedUpdate
  ${endif}
!macroend

# Run only after installMode is final. Interactive assisted installers reach this from the
# instfiles-page preflight; silent installs have no page callbacks, so customInit calls it after
# initMultiUser has resolved the command-line/previous-install mode. A distinct HKLM tree must not
# be touched for a current-user install merely because the process already has admin rights.
!macro protectMachineDataRootForSelectedMode
  ${if} $dataProtectionFailed == "0"
  ${andIf} $installMode == "all"
    ${if} $perMachineInstallDirCache == $perUserInstallDirCache
      StrCpy $perMachineDataBackup $perUserDataBackup
      StrCpy $perMachineDataBackupBranded $perUserDataBackupBranded
    ${elseif} ${UAC_IsAdmin}
      !insertmacro preserveNestedDataRoot $perMachineInstallDirCache $perMachineDataBackup machine
    ${elseif} $perMachineInstallDirCache != ""
      # The unelevated assisted outer process stops on the install-mode page while its elevated
      # inner process completes the install. The inner process runs this same protection path.
      DetailPrint `Deferring machine data-folder protection to the elevated installer.`
    ${endif}
  ${endif}
  ${if} $dataProtectionFailed != "0"
    # Undo any earlier successful move before refusing to start either old uninstaller.
    !insertmacro restoreAllNestedDataRoots
    !insertmacro quitFailedUpdate
  ${endif}
!macroend

# electron-builder already installs an instfiles PRE callback that sanitizes the selected install
# directory. Preserve that callback and chain the final-mode data preflight after it.
!macro customPageAfterChangeDir
  !ifdef MUI_PAGE_CUSTOMFUNCTION_PRE
    !define openScienceOriginalInstFilesPre ${MUI_PAGE_CUSTOMFUNCTION_PRE}
    !undef MUI_PAGE_CUSTOMFUNCTION_PRE
  !endif
  !define MUI_PAGE_CUSTOMFUNCTION_PRE protectNestedDataRootsForInstall
!macroend

# Interactive updates retain the native instfiles page after Electron exits. The normal setup
# finish page would strand --force-run at a second confirmation, so update installs complete it
# automatically. Fresh installations keep the standard finish page and optional Run checkbox.
!macro customFinishPage
  Function openScienceStartInstalledApp
    StrCpy $1 ""
    ${if} ${isUpdated}
      StrCpy $1 "--updated"
      ${if} $updateOperation != ""
        StrCpy $1 "$1 --open-science-update-operation=$updateOperation"
      ${endif}
    ${endif}
    ${StdUtils.ExecShellAsUser} $0 "$launchLink" "open" "$1"
  FunctionEnd

  Function openScienceUpdateFinish
    ${if} ${isUpdated}
      ${if} ${isForceRun}
        Call openScienceStartInstalledApp
      ${endif}
      Abort
    ${endif}
  FunctionEnd

  !ifndef HIDE_RUN_AFTER_FINISH
    !define MUI_FINISHPAGE_RUN
    !define MUI_FINISHPAGE_RUN_FUNCTION openScienceStartInstalledApp
  !endif
  !define MUI_PAGE_CUSTOMFUNCTION_PRE openScienceUpdateFinish
  !insertmacro MUI_PAGE_FINISH
!macroend

# EARTHNANO_STAGE_BEGIN
!macro preInit
!ifndef BUILD_UNINSTALLER
Push "PREINIT"
Call earthNanoDiagnosticStage
!endif
!macroend
# EARTHNANO_STAGE_END
!macro customInit
# EARTHNANO_STAGE_BEGIN
Push "CUSTOM_INIT_BEGIN"
Call earthNanoDiagnosticStage
# EARTHNANO_STAGE_END
  Call initializeUpdateReceipts
  # Cache both registered locations before either uninstall pass can delete their registry data.
  # More importantly, move any nested OpenScience data root OUTSIDE the install directory before
  # the first old uninstaller runs. Its /KEEP_APP_DATA flag only protects the normal OS app-data
  # directory; its update algorithm otherwise moves every child of the install directory into a
  # disposable $PLUGINSDIR and deletes it on success.
  StrCpy $perMachineInstallDirCache ""
  StrCpy $perUserInstallDirCache ""
  StrCpy $perMachineDataBackup ""
  StrCpy $perUserDataBackup ""
  StrCpy $dataProtectionFailed "0"
  StrCpy $dataRestoreFailed "0"
  # The assisted install section elevates silent per-machine upgrades AFTER .onInit.
  # Match that existing decision before any write probe or data move: the outer process
  # must reach UAC, and only its elevated child may protect/replace the old installation.
  ${if} ${Silent}
  ${andIf} $hasPerMachineInstallation == "1"
    ${ifNot} ${UAC_IsAdmin}
      Goto openScienceCustomInit_done
    ${endif}
    # With both HKCU and HKLM registrations, initMultiUser initially chooses CurrentUser,
    # but the silent install section later selects all-users. Preflight that final target.
    !insertmacro setInstallModePerAllUsers
  ${endif}
  ReadRegStr $perMachineInstallDirCache HKEY_LOCAL_MACHINE "${INSTALL_REGISTRY_KEY}" InstallLocation
  ReadRegStr $perUserInstallDirCache HKEY_CURRENT_USER "${INSTALL_REGISTRY_KEY}" InstallLocation
  Push $perMachineInstallDirCache
  Call normalizeRegisteredInstallPath
  Pop $perMachineInstallDirCache
  Push $perUserInstallDirCache
  Call normalizeRegisteredInstallPath
  Pop $perUserInstallDirCache

  # Protect HKCU independently of the mode selected during .onInit: the user can still switch to
  # all-users on the assisted install-mode page, so that early mode is not the uninstall verdict.
  # One exception needs a non-destructive write probe: both registry entries may point at the
  # same machine-owned Program Files tree. An unelevated outer process must defer that shared path
  # to the inner installer instead of failing before the user has a chance to approve UAC.
  StrCpy $R8 "1"
  ${if} $perUserInstallDirCache != ""
  ${andIf} $perMachineInstallDirCache == $perUserInstallDirCache
  ${andIfNot} ${UAC_IsAdmin}
    StrCpy $R8 "0"
    StrCpy $R9 ""
    ClearErrors
    GetFullPathName $R2 "$perUserInstallDirCache\.."
    ${ifNot} ${Errors}
      GetTempFileName $R9 "$R2"
      ${ifNot} ${Errors}
        ClearErrors
        Delete "$R9"
        ${ifNot} ${Errors}
          StrCpy $R8 "1"
        ${endif}
      ${endif}
    ${endif}
    ${if} $R8 == "0"
      DetailPrint `Deferring shared data-folder protection to the elevated installer.`
      ClearErrors
    ${endif}
  ${endif}
  ${if} $R8 == "1"
    !insertmacro preserveNestedDataRoot $perUserInstallDirCache $perUserDataBackup per-user
  ${endif}

  ${if} $dataProtectionFailed != "0"
    !insertmacro restoreAllNestedDataRoots
    !insertmacro quitFailedUpdate
  ${endif}
  # Page callbacks do not run in silent mode. There is no later user choice in that mode, so the
  # installMode selected by initMultiUser is already final and machine protection can run now.
  ${if} ${Silent}
# EARTHNANO_STAGE_BEGIN
Push "CUSTOM_INIT_BEFORE_UNINSTALLER_PROBE"
Call earthNanoDiagnosticStage
# EARTHNANO_STAGE_END
    Call ensureExistingUninstallerIsWritable
# EARTHNANO_STAGE_BEGIN
Push "CUSTOM_INIT_AFTER_UNINSTALLER_PROBE"
Call earthNanoDiagnosticStage
# EARTHNANO_STAGE_END
# EARTHNANO_STAGE_BEGIN
Push "CUSTOM_INIT_BEFORE_MODE_PROTECTION"
Call earthNanoDiagnosticStage
# EARTHNANO_STAGE_END
    !insertmacro protectMachineDataRootForSelectedMode
# EARTHNANO_STAGE_BEGIN
Push "CUSTOM_INIT_AFTER_MODE_PROTECTION"
Call earthNanoDiagnosticStage
# EARTHNANO_STAGE_END
    Push "installing"
    Call writeUpdateReceipt
  ${endif}
  openScienceCustomInit_done:
# EARTHNANO_STAGE_BEGIN
Push "CUSTOM_INIT_END"
Call earthNanoDiagnosticStage
# EARTHNANO_STAGE_END
!macroend

# These callbacks cover cancellation or an installer failure before the post-uninstall hooks run.
# The normal path restores each directory immediately after its matching old-uninstaller pass.
!macro customHeader
# EARTHNANO_STAGE_BEGIN
Function earthNanoDiagnosticStage
  Exch $0
  Push $1
  Push $2
  IfErrors diagnostic_saved_error diagnostic_saved_clear
  diagnostic_saved_error:
    StrCpy $2 1
    Goto diagnostic_write
  diagnostic_saved_clear:
    StrCpy $2 0
  diagnostic_write:
    ClearErrors
    FileOpen $1 "D:\a\EarthNano\EarthNano\test-results\native-evidence\installer-stages\installer-stage-TngEMm\stages.txt" a
    IfErrors diagnostic_restore
    FileSeek $1 0 END
    FileWrite $1 "$0$\r$\n"
    FileClose $1
  StrCpy $1 $0 12
  StrCmp $1 "PUBLICATION_" 0 diagnostic_restore
  FileOpen $1 "D:\a\EarthNano\EarthNano\test-results\native-evidence\installer-stages\installer-stage-TngEMm\stages.txt.$0.txt" w
  IfErrors diagnostic_restore
  FileWriteUTF16LE /BOM $1 "$publicationResult$\r$\n$publicationOutput"
  FileClose $1
  diagnostic_restore:
    StrCmp $2 1 diagnostic_restore_error diagnostic_restore_clear
  diagnostic_restore_error:
    SetErrors
    Goto diagnostic_restore_registers
  diagnostic_restore_clear:
    ClearErrors
  diagnostic_restore_registers:
    Pop $2
    Pop $1
    Pop $0
FunctionEnd
# EARTHNANO_STAGE_END
  !insertmacro defineUpdateReceiptFunctions
  # NSIS extracts the new uninstaller after the application package. Probe the same write access
  # its File command will request before uninstalling the old app, and again before extraction.
  # Checking only after uninstalling can reject the update with the old executable already gone.
  # A stale locked uninstaller must not turn a silent install into a false success or offer the unsafe
  # Ignore choice. OPEN_EXISTING keeps this check non-destructive; Retry lets the user release a
  # transient lock. Unattended installs stay silent; a user-requested restart must explain failure
  # even though electron-updater starts NSIS with /S and exits before observing the result.
  Function ensureExistingUninstallerIsWritable
    IfFileExists "$INSTDIR\${UNINSTALL_FILENAME}" ensureExistingUninstallerIsWritable_retry ensureExistingUninstallerIsWritable_done

    ensureExistingUninstallerIsWritable_retry:
      System::Call 'kernel32::SetLastError(i 0)'
      System::Call 'kernel32::CreateFile(t "$INSTDIR\${UNINSTALL_FILENAME}", i 0x40000000, i 1, i 0, i 3, i 0x80, i 0) p.R0 ?e'
      Pop $R1
      StrCmp $R1 0 0 ensureExistingUninstallerIsWritable_failed
      System::Call 'kernel32::CloseHandle(p R0)'
      Return

    ensureExistingUninstallerIsWritable_failed:
      DetailPrint `Cannot replace the existing uninstaller: "$INSTDIR\${UNINSTALL_FILENAME}". Windows error: $R1.`
      ${if} ${Silent}
        # --updated + --force-run is the existing Restart to update handoff, including old clients.
        # Plain /S and non-relaunching update jobs must not wait for someone to dismiss a dialog.
        ${ifNot} ${isUpdated}
          Goto ensureExistingUninstallerIsWritable_cancel
        ${endif}
        ${ifNot} ${isForceRun}
          Goto ensureExistingUninstallerIsWritable_cancel
        ${endif}
      ${endif}
      ${if} $R1 == 5
        MessageBox MB_OK|MB_ICONEXCLAMATION|MB_SETFOREGROUND "Open-Science could not finish updating.$\r$\n$\r$\nWindows denied access to:$\r$\n$INSTDIR\${UNINSTALL_FILENAME}$\r$\n$\r$\nClose this notice, then run the official Open-Science installer as administrator to update this installation.$\r$\n$\r$\nWindows error: $R1"
      ${elseif} $R1 == 32
      ${orIf} $R1 == 33
        MessageBox MB_RETRYCANCEL|MB_ICONEXCLAMATION|MB_SETFOREGROUND "Open-Science could not finish updating.$\r$\n$\r$\nAnother process is using:$\r$\n$INSTDIR\${UNINSTALL_FILENAME}$\r$\n$\r$\nClose the process using this file, then choose Retry. Choose Cancel to stop this update.$\r$\n$\r$\nWindows error: $R1" IDRETRY ensureExistingUninstallerIsWritable_retry
      ${else}
        MessageBox MB_RETRYCANCEL|MB_ICONEXCLAMATION|MB_SETFOREGROUND "Open-Science could not finish updating.$\r$\n$\r$\nWindows could not replace:$\r$\n$INSTDIR\${UNINSTALL_FILENAME}$\r$\n$\r$\nChoose Retry to try again, or Cancel to stop this update. If the problem continues, report the file path and Windows error below.$\r$\n$\r$\nWindows error: $R1" IDRETRY ensureExistingUninstallerIsWritable_retry
      ${endif}

    ensureExistingUninstallerIsWritable_cancel:
      # customInit may already have moved nested user data outside the old installation.
      !insertmacro restoreAllNestedDataRoots
      !insertmacro quitFailedUpdate

    ensureExistingUninstallerIsWritable_done:
      Return
  FunctionEnd

  Function protectNestedDataRootsForInstall
    !ifdef openScienceOriginalInstFilesPre
      # An update must replace the registered installation, including a custom directory that
      # does not contain APP_FILENAME. The setup-page sanitizer would append a second directory.
      ${ifNot} ${isUpdated}
        Call ${openScienceOriginalInstFilesPre}
      ${endif}
    !endif
    Call ensureExistingUninstallerIsWritable
    !insertmacro protectMachineDataRootForSelectedMode
    Push "installing"
    Call writeUpdateReceipt
  FunctionEnd

  Function restorePreservedOnAbort
    Call cleanupInstallPublication
    !insertmacro restoreAllNestedDataRoots
    Push "failed"
    Call writeUpdateReceipt
  FunctionEnd

  Function .onInstFailed
# EARTHNANO_STAGE_BEGIN
Push "INSTALL_FAILED_CALLBACK"
Call earthNanoDiagnosticStage
# EARTHNANO_STAGE_END
    Call cleanupInstallPublication
    !insertmacro restoreAllNestedDataRoots
    Push "failed"
    Call writeUpdateReceipt
  FunctionEnd
!macroend

!macro customInstall
# EARTHNANO_STAGE_BEGIN
Push "CUSTOM_INSTALL_BEGIN"
Call earthNanoDiagnosticStage
# EARTHNANO_STAGE_END
  Push "installed"
  Call writeUpdateReceipt
# EARTHNANO_STAGE_BEGIN
Push "CUSTOM_INSTALL_END"
Call earthNanoDiagnosticStage
# EARTHNANO_STAGE_END
!macroend

# Resilient replacement for handleUninstallResult's default failure handling, installed via
# electron-builder's customUnInstallCheck hooks below. During an in-app update the new installer
# runs the OLD uninstaller and treats any non-zero exit code as fatal ("Failed to uninstall old
# application files. Please try running the installer again.: <code>") — aborting the update.
# That code is not trustworthy for our assisted installer (oneClick: false): electron-builder only
# normalizes the uninstaller's exit code (quitSuccess, "avoid exit code 2") for ONE_CLICK builds,
# so a benign trailing error leaks out as exit code 2 even when the old version was fully removed
# (electron-userland/electron-builder#9593). And when the code IS real, it is usually a background
# child still running from the install dir (micromamba provisioning, the CLI in Node mode, an
# agent child) locking files — worth one more attempt after a force-kill instead of failing.
# Recovery order (${DIR} = the installation this pass was uninstalling):
#   1. Exit code non-zero but the old executable is already gone -> the uninstall did its job
#      despite the reported code; log and continue installing.
#   2. Files remain -> force-kill processes running from the install dir, wait, and run the old
#      uninstaller once more. Only if it still fails show the original dialog and quit.
# Symbol constraints: handleUninstallResult is parsed BEFORE uninstallOldVersion and
# CHECK_APP_RUNNING declare their globals ($installationDir, $PowerShellPath, ...), and makensis
# treats unknown variables as errors — so this stays self-contained: registers, built-in
# constants, and the literal temp-uninstaller path uninstallOldVersion uses.
!macro preserveRetryDataRoot DIR BACKUP FOLDER
    StrCpy ${BACKUP} ""
    ${if} ${FileExists} "${DIR}\${FOLDER}\*.*"
      ClearErrors
      GetFullPathName $R2 "${DIR}\.."
      GetTempFileName ${BACKUP} "$R2"
      ${ifNot} ${Errors}
        Delete "${BACKUP}"
        ClearErrors
        Rename "${DIR}\${FOLDER}" "${BACKUP}"
      ${endif}
      ${if} ${Errors}
        Delete "${BACKUP}"
        DetailPrint `Could not safely preserve "${DIR}\${FOLDER}"; leaving the existing installation untouched.`
        MessageBox MB_OK|MB_ICONEXCLAMATION "$(uninstallFailed): $R0$\r$\nAny data already preserved for this retry remains at:$\r$\n$retryLegacyDataBackup$\r$\n$retryBrandedDataBackup"
        !insertmacro restoreAllNestedDataRoots
        !insertmacro quitFailedUpdate
      ${endif}
    ${endif}

!macroend

!macro restoreRetryDataRoot DIR BACKUP REGISTERED_BACKUP FOLDER
    ${if} ${BACKUP} != ""
      ${if} "${REGISTERED_BACKUP}" != ""
      ${andIf} ${FileExists} "${REGISTERED_BACKUP}\*.*"
        # customInit already holds the authoritative registered data outside the install tree.
        # Do not overwrite either copy if the old process recreated data before it was killed;
        # retain that additional directory at its unique sibling path for manual reconciliation.
        DetailPrint `Additional data created during the update remains at: ${BACKUP}`
        MessageBox MB_OK|MB_ICONEXCLAMATION "Open-Science found additional data created while closing the previous version.$\r$\nYour original data will be restored; the additional data remains at:$\r$\n${BACKUP}"
      ${else}
        # No registered backup exists (recovery can also be used independently). The retry may
        # have removed ${DIR}; recreate only the parent and put the retry-local data back before
        # deciding whether the retry's exit code represents success or failure.
        CreateDirectory "${DIR}"
        ClearErrors
        Rename "${BACKUP}" "${DIR}\${FOLDER}"
        ${if} ${Errors}
          DetailPrint `The preserved data remains at: ${BACKUP}`
          MessageBox MB_OK|MB_ICONSTOP "Open-Science could not restore its data folder after updating.$\r$\nYour data remains at:$\r$\n${BACKUP}"
          !insertmacro restoreAllNestedDataRoots
          !insertmacro quitFailedUpdate
        ${endif}
        StrCpy ${BACKUP} ""
      ${endif}
    ${endif}
!macroend

!macro uninstallFailureRecoveryAt DIR REGISTERED_BACKUP REGISTERED_BRANDED_BACKUP
  ${ifNot} ${FileExists} "${DIR}\${APP_EXECUTABLE_FILENAME}"
    DetailPrint `Old uninstaller exited with $R0 but the previous installation is already removed; continuing.`
  ${else}
    DetailPrint `Old uninstaller exited with $R0; closing leftover app processes and retrying once.`
    # Force-kill anything still running from the install dir, then retry. The PowerShell sweep
    # matches on ExecutablePath (Win32_Process has no Path property) with a trailing-backslash
    # boundary so a sibling directory can never match, and receives the directory as an ARGUMENT —
    # never interpolated into the script source — so a custom install dir containing an apostrophe
    # breaks nothing and injects nothing. The image-name taskkills are ONLY a fallback for when
    # the sweep could not run (PowerShell missing or policy-blocked): they match by exe name in
    # ANY directory — open-science.exe covers the app and its Electron-as-Node children (the
    # CLI), micromamba.exe covers in-flight provisioning — so a second install, the portable zip
    # copy, or an unrelated micromamba would be killed too. Acceptable solely when no path-scoped
    # option exists. Both are best-effort; the retry is the verdict.
    # $0 keeps the uninstaller arguments (/currentuser etc.) — neither nsExec call touches it.
    nsExec::Exec `"$SYSDIR\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -C "$$root = $$args[0].TrimEnd('\') + '\'; Get-CimInstance -ClassName Win32_Process | ? { $$_.ExecutablePath -and $$_.ExecutablePath.StartsWith($$root, 'CurrentCultureIgnoreCase') } | % { Stop-Process -Id $$_.ProcessId -Force -ErrorAction SilentlyContinue }" "${DIR}"`
    Pop $R1
    # nsExec pushes "error" when powershell.exe cannot even start, otherwise its exit code — any
    # non-zero means the sweep did not run, so only then widen to the image-name kills.
    ${if} $R1 != 0
      nsExec::Exec `"$SYSDIR\cmd.exe" /C taskkill /F /IM "${APP_EXECUTABLE_FILENAME}"`
      Pop $R1
      nsExec::Exec `"$SYSDIR\cmd.exe" /C taskkill /F /IM micromamba.exe`
      Pop $R1
      nsExec::Exec `"$SYSDIR\cmd.exe" /C taskkill /F /IM "notebook-appcontainer-host.exe"`
      Pop $R1
    ${endif}
    ClearErrors
    Sleep 1000
    # A custom data root may live inside the installation itself (the issue reporter uses
    # <install>\OpenScience). The updated uninstaller moves EVERY child of ${DIR} into its
    # disposable $PLUGINSDIR, so making that move reliable without protecting the data root
    # would turn an update failure into silent data loss. Move the directory to a unique sibling
    # on the same volume before retrying, then restore it regardless of the retry's exit code.
    # A failed preserve leaves the original directory in place and aborts before the retry.
    !insertmacro preserveRetryDataRoot ${DIR} $retryLegacyDataBackup OpenScience
    !insertmacro preserveRetryDataRoot ${DIR} $retryBrandedDataBackup Open-Science

    # During an update, electron-builder's old uninstaller moves every installed file into its
    # $PLUGINSDIR before deleting the old tree. Windows cannot atomically rename across volumes:
    # for a custom D: install and the usual C: TEMP this becomes a slow, failure-prone copy of the
    # whole installation. Give only the recovery child a unique temp directory beside the old
    # install so its plugin directory stays on the same volume. If that directory cannot be
    # created, retain the existing default-TEMP retry rather than turning recovery setup into a
    # new fatal path. $R3/$R4 preserve this installer's environment across the child process.
    StrCpy $R5 ""
    ClearErrors
    GetFullPathName $R2 "${DIR}\.."
    GetTempFileName $R5 "$R2"
    ${ifNot} ${Errors}
      Delete "$R5"
      ClearErrors
      CreateDirectory "$R5"
    ${endif}
    ${ifNot} ${Errors}
      ReadEnvStr $R3 "TEMP"
      ReadEnvStr $R4 "TMP"
      System::Call 'Kernel32::SetEnvironmentVariable(t, t)i ("TEMP", "$R5").R6'
      ${if} $R6 != 0
        System::Call 'Kernel32::SetEnvironmentVariable(t, t)i ("TMP", "$R5").R6'
      ${endif}
      ${if} $R6 == 0
        # A partial environment update must not leak into the rest of the new installer.
        System::Call 'Kernel32::SetEnvironmentVariable(t, t)i ("TEMP", "$R3").R6'
        System::Call 'Kernel32::SetEnvironmentVariable(t, t)i ("TMP", "$R4").R6'
        RMDir /r "$R5"
        StrCpy $R5 ""
      ${endif}
    ${else}
      StrCpy $R5 ""
    ${endif}

    ExecWait '"$PLUGINSDIR\old-uninstaller.exe" /S /KEEP_APP_DATA $0 _?=${DIR}' $R0
    ${if} $R5 != ""
      System::Call 'Kernel32::SetEnvironmentVariable(t, t)i ("TEMP", "$R3").R6'
      System::Call 'Kernel32::SetEnvironmentVariable(t, t)i ("TMP", "$R4").R6'
      RMDir /r "$R5"
      ClearErrors
    ${endif}
    !insertmacro restoreRetryDataRoot ${DIR} $retryLegacyDataBackup ${REGISTERED_BACKUP} OpenScience
    !insertmacro restoreRetryDataRoot ${DIR} $retryBrandedDataBackup ${REGISTERED_BRANDED_BACKUP} Open-Science
    ${if} $R0 != 0
      ${ifNot} ${FileExists} "${DIR}\${APP_EXECUTABLE_FILENAME}"
        DetailPrint `Retry exited with $R0 but the previous installation is already removed; continuing.`
      ${else}
        MessageBox MB_OK|MB_ICONEXCLAMATION "$(uninstallFailed): $R0"
        DetailPrint `Uninstall was not successful. Uninstaller error code: $R0.`
        !insertmacro restoreAllNestedDataRoots
        !insertmacro quitFailedUpdate
      ${endif}
    ${endif}
  ${endif}
!macroend

!macro customUnInstallCheck
  # SHELL_CONTEXT resolves from the FINAL install-mode page selection, not the mode seen by
  # customInit. Keep registered data outside the install tree through any non-zero-exit recovery:
  # a live old process can recreate OpenScience, and restoring first would make the recovery path
  # abort on that destination conflict. $R8 selects the authoritative backup for this pass.
  ${if} $R0 != 0
    StrCpy $R8 $perUserDataBackup
    StrCpy $retryRegisteredBrandedBackup $perUserDataBackupBranded
    ${if} $installMode == "all"
      StrCpy $R8 $perMachineDataBackup
      StrCpy $retryRegisteredBrandedBackup $perMachineDataBackupBranded
    ${endif}
    # SHELL_CONTEXT pass: the old installation sits at $INSTDIR (an update installs over it).
    !insertmacro uninstallFailureRecoveryAt $INSTDIR $R8 $retryRegisteredBrandedBackup
  ${endif}

  # A current-user install has no second pass, so restore every cached root. An all-users install
  # restores HKLM here and keeps HKCU protected for the following explicit pass.
  ${if} $installMode == "all"
    ${if} $perMachineInstallDirCache == $perUserInstallDirCache
      DetailPrint `Keeping the shared data folder protected for the matching per-user uninstall pass.`
    ${else}
      !insertmacro restoreNestedDataRoot $perMachineInstallDirCache $perMachineDataBackup
      !insertmacro quitIfDataRestoreFailed
    ${endif}
  ${else}
    !insertmacro restoreAllNestedDataRoots
    !insertmacro quitIfDataRestoreFailed
    Call ensureExistingUninstallerIsWritable
  ${endif}
!macroend

!macro customUnInstallCheckCurrentUser
  ${if} $R0 != 0
    # installMode==all pass: it removes a stray PER-USER install, which may live anywhere —
    # $INSTDIR/$appExe describe the new (machine-wide) target, not it. Use the location cached in
    # customInit: reading the registry HERE is useless for the spurious-failure case, because a
    # successful per-user uninstall deletes InstallLocation before returning its (untrustworthy)
    # exit code. Empty cache means no per-user install was registered at install start; keep
    # electron-builder's default fatal handling rather than retry against an unknown directory.
    ${if} $perUserInstallDirCache == ""
      MessageBox MB_OK|MB_ICONEXCLAMATION "$(uninstallFailed): $R0"
      DetailPrint `Uninstall was not successful. Uninstaller error code: $R0.`
      !insertmacro restoreAllNestedDataRoots
      !insertmacro quitFailedUpdate
    ${endif}
    !insertmacro uninstallFailureRecoveryAt $perUserInstallDirCache $perUserDataBackup $perUserDataBackupBranded
  ${endif}
  # The old uninstall may have removed its registry key, so restore using the path cached before
  # either pass rather than reading InstallLocation here. Recovery must finish first because the
  # still-preserved backup is what keeps a recreated data directory from short-circuiting retry.
  !insertmacro restoreNestedDataRoot $perUserInstallDirCache $perUserDataBackup
  !insertmacro quitIfDataRestoreFailed
  Call ensureExistingUninstallerIsWritable
!macroend

!endif
