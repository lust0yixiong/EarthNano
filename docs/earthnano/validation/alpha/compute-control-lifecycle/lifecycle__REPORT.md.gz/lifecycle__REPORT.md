# Compute lifecycle phase 1 — local infrastructure evidence

Base: `1ada7326e054aee1f9b1b5643ca703500356233e`; branch `feat/alpha-compute-lifecycle`.
Local runtime: Node 26.0.0, macOS; Vitest 4.1.11. No Windows operation, provider/model/SSH call, build/install, CI dispatch, publication, or push was performed. Shared dependencies were only read. The root freeze helper `abd5f1c35` was not cherry-picked.

## APIs and retained authorities

- `PreparedAcpExecution.cancelOwnedBackground?(): Promise<void>` extends the existing driver's sole cancellation owner and abort listener through `readResult`. Its trusted owner must cancel/settle original owned background resources **and any currently owned application continuation**; the initial prompt token must never be sent to a later Turn. The original prompt branch retains its admission/settled/exact-token guards. Cancellation acknowledgment is not resource cleanup evidence; only original `resourceCleanup` can attest cleanup. Both branches are joined even after synchronous failure. Failed background cancellation forces unknown cleanup. Deadline terminal/unknown facts cannot be upgraded by a late result.
- Existing `AcpExecutionDispatch` adds optional original `MessageAttribution`. The actual coordinator forwards only its existing host-owned attribution with a conditional spread. An absent attribution retains the exact previous dispatch shape. Model payload fields never establish authorization.
- Existing `createAcpExecutionBoundary` accepts optional `TrustedApplicationExecutionOwner` (mutually exclusive with delegated owner). Application continuation validates the active original Core/Project/source Session, exact owned Session/Turn, original strict application attribution, nonempty unique delivery IDs, delivery key/message identity, and trusted owner callback. Native admission must match before provider acceptance. Continuation observes original admission without mutating mission identity or allocating a new Core/budget. Ordinary second-Turn and delegated Attempt behavior remain covered by original fixtures. The existing `findOwnedExecutionScope` is reused unchanged.
- `composeBackgroundResults` adds optional existing `ResolveCandidateDelivery`, and `routeCandidateContinuations` routes the original three callbacks through that resolver. Its target type is the exact shared `CandidateContinuationTarget`. A known private unavailable owner never falls back to ordinary Send; admission and result promises remain independent. Without a resolver it returns the original callback object. There is no new delivery queue, Job state machine, registry, schema, or resource owner.

Future candidate owner/desktop wiring is deliberately outside this phase. These fixtures do not establish Compute candidate functionality or real external Job/remote cleanup acceptance.

## Validation

`final-focused.json` / `final-focused.log` are the complete unmodified final Vitest output:

```sh
node node_modules/vitest/vitest.mjs run \
  src/main/acp/earthnano-execution-driver.test.ts \
  src/main/earthnano/acp-execution-boundary.test.ts \
  src/main/composition/background-results.test.ts \
  src/main/acp/runtime-coordinator.test.ts \
  src/main/background-result-delivery/owner.test.ts \
  src/main/earthnano/execution-core.test.ts \
  src/main/host-layer-dependencies.architecture.test.ts \
  scripts/ci/audit-module-ownership.test.ts \
  --reporter=default --reporter=json --outputFile=<this-directory>/final-focused.json
```

The six functional suites pass **358/358, no skips**: driver 30; boundary 27; routing/composition 7; actual coordinator 237; original delivery owner 28; original Core 29. Cases cover late cancel after initial native completion, deadline/late cleanup, unavailable remote settlement, acknowledgment without attestation, result owner rejection while cancellation remains pending, synchronous prompt-cancel failure, cancellation before/late admission, multiple legal application Turns, wrong ownership/tuple/attribution/admission, ordinary second-Turn rejection, and independent delivery promises/private-unavailable behavior.

Full `npm run typecheck:compiled` passes Node, sandbox, and Web (`final-compiled-types.log`). Scoped ESLint over all nine changed files, Prettier `--check`, and `git diff --check` pass (`final-lint.log`, `final-format.log`, `final-diffcheck.log`). No package/dependency build was used.

The additional two architecture suites **remain red**: complete combined run is **681 pass / 27 fail / 708 total**. `ownership-attribution.json` uses the original audit and original revision manifest loader with exact `git ls-tree` inventory. The common base already misses six registrations:

1. `src/main/earthnano/compute-candidate-ports.ts`
2. `src/main/earthnano/persistent-candidate-owner.binary.test.ts`
3. `src/shared/earthnano/candidate-artifact.test.ts`
4. `src/shared/earthnano/candidate-artifact.ts`
5. `src/shared/earthnano/compute-profile.test.ts`
6. `src/shared/earthnano/compute-profile.ts`

This phase adds one composition test needing exact registration: `src/main/composition/background-results.test.ts`. The 25 audit failures all derive from this nonempty missing set; two host graph assertions stop at the base's missing `compute-candidate-ports.ts` owner. The latter early stop does **not** certify a clean dependency DAG. Root owns final integrated manifest/consumer indexing. The original manifest and both guard files are byte-identical, and no assertion/exemption was changed.

## Source preservation

`byteproof.cjs` / `byteproof.json` prove original Core, scope, execution contracts/DTO, shared Compute ports, delivery owner/repository, persistent candidate owner, Claude driver, and desktop composition are byte-identical to the common base. Removing the sole conditional attribution spread restores the coordinator's exact original bytes. TypeScript parsed token sequences of all three moved ordinary continuation callbacks are identical (only formatting/placement changed). The three modified preexisting test files have **zero original lines removed**.

Initial trial logs are retained separately. Their fixture setup/type/lint mistakes were corrected; they are not claimed as production red/green evidence. No raw report was modified or normalized into a pass.
