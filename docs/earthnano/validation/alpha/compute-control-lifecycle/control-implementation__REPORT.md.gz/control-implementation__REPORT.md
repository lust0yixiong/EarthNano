# Compute control / approval implementation — independent slice

Commit `210bdc972` on branch `feat/alpha-compute-control`, based on exact shared-contract commit
`1ada7326e054aee1f9b1b5643ca703500356233e`. The old Windows branch/evidence remain intact.
Only assigned native preparation, original Notebook RPC/composition, original Compute
context/broker/operation/service/workflow files and focused tests changed.
No production owner/snapshot/ACP boundary-driver/background routing/desktop composition,
Job algorithm/schema, dependency, CI, model, UI, external SSH or Windows operation was changed/run.

## Implemented boundary

- `NotebookLocalRpcServer.issueControlConnection(..., executionCwd?, policy?)` accepts the
  **shared** main-only `TrustedControlPolicy` from compute-candidate-ports.ts. No duplicate
  policy type was introduced. Token methods are the intersection of the policy and the
  original main/delegate control set. The original default set is retained without a policy.
- The token retains its original callback/policy across actual socket RPC. The current-source
  callback runs for provider-targeted Compute calls. After awaited validation the token and
  captured active control invocation must still be the same; otherwise dispatch is rejected.
  Policy tokens use the original capabilityLifetime/revocation signal for in-flight work.
- Original RPC owner overwrite supplies Session/Project, producerRunId from the original
  activeControlInvocation, and interactionPolicy from the token. Model-supplied policy is
  overwritten even on an ordinary control token, where no trusted policy means no added field.
- The original AgentComputeService facade, ComputeService, remote operation owner and Job
  workflow carry the optional ExecutionRequest interactionPolicy to the original broker.
  Original enabled-host validation, host row identity/generation, scopes, operation names,
  producer identity, submission idempotency, DB/SSH and Job lifecycle remain in their owners.
- `ComputeApprovalBroker.requestWithContext` first uses its original grant resolver with the
  **actual private Session id**. A valid existing scope and current host may pass. An unresolved
  deny-unresolved request returns deny before request/card/timer/id/remember. Its lower-level
  request method also rejects that policy before allocating a request. Explicit unencrypted
  persistence still skips remembered scopes and therefore denies without an interactive card.
  No source Session grant is copied, no once/project/global grant is created. Ordinary policy
  undefined/interactive retains the original tests and behavior.
- Native preparation recognizes notebook-compute only with a valid shared frozen context,
  provider-and-notebook-policy and no data runtime. It requires the original role baseline
  or candidate. Its command hook allows original foreground repl_execute and producer-backed
  write_artifact_file through the original application permission broker. Background native
  REPL, Shell, data-runtime/package mutation remain denied; existing Python/R/workspace
  profiles do not gain repl_execute. RPC method policy is independently enforced and is not
  inferred from JavaScript source text.

## Exact consumer signatures / remaining integration

```ts
// Original method, one appended optional main-only argument:
issueControlConnection(
  sessionId: string, projectId: string, agentFrameId: string,
  delegatedWorkIdentity?: Readonly<{ role: 'main' | 'delegate'; attemptId?: string }>,
  executionCwd?: string, policy?: TrustedControlPolicy
): Promise<OriginalControlConnection>

// New optional composeNotebookBridge input, original binding type indexed directly:
resolveControlPolicy?(
  binding: Parameters<Parameters<NotebookRuntimeService['setMcpRpcConnectionResolver']>[0]>[0]
): Promise<TrustedControlPolicy | undefined>

prepareClaudeCandidate(input: {
  resolved: ResolvedCandidateSnapshots
  materialized: MaterializedCandidate
  binding: ClaudeCandidateBinding
  role?: ExecutionRequest['role']
  sourceEnv?: NodeJS.ProcessEnv
}): Promise<PreparedClaudeCandidate>
```

The original control connection return signature (begin/complete/discard/revoke/release) is
unchanged; OriginalControlConnection above names that existing return for documentation only.
The role is a field of the input object, not a new positional argument.

Root must change the **existing** call in `src/main/earthnano/claude-candidate-driver.ts:91`
to `prepareClaudeCandidate({ resolved, materialized, binding, role: request.role })`.
This agent did not edit that separately owned driver. Missing role, task, proposer, composer,
selector, reflection and reviewer all fail closed for Compute before native runtime resources;
the new negative cases prove it. Root confirmed responsibility for this mandatory consumer wire.

The serializer/source validator, restricted native permission grants, minimal callback construction,
private Session/continuation/Job owner lifecycle are separate root/execution-owner integration.
Root can construct assertComputeHostCurrent from its one compute-context.ts validator; this slice
does not create another host validator/registry. This commit alone does not activate a usable
Compute candidate or claim full Job/producer/Review/E2E acceptance.

## Validation and actual source comparison

`green-final.json` / `.log`: **9 suites, 398 pass, 0 fail, 0 skip**:

| Suite | Tests |
| --- | ---: |
| claude-candidate-preparation | 41 |
| local-rpc-server.capabilities | 20 |
| local-rpc-server | 138 |
| compute-approval-broker | 42 |
| compute-remote-operation-owner | 75 |
| compute-job-workflow-owner | 58 |
| agent-compute-service | 14 |
| compute-service | 8 |
| approval-session-lifecycle | 2 |

After final assertions and return annotations, `green-final-touched.json` has **103/103**
for preparation/capabilities/broker. `types-final-green.log` passes the complete Node +
sandbox + Web compiled typecheck. Focused ESLint (`lint-committed.log`, final annotation
`lint-last.log`), Prettier check (`format-final.log`) and git diff --check pass. Original
test titles and assertions were retained; new behavior has additional cases.

Actual RPC tests use the original TCP NotebookLocalRpcServer and original AgentComputeService
facade: method intersection for main/delegate, capability/help projection, foreign identity/policy/
producer overwrite, source invalidation, token revocation, and successor invocation exclusion.
Original native command hooks are executed as child processes against synthetic version-only
executables. These tests make no model request or remote connection.

The three operation-to-broker tests use the real original ComputeRemoteOperationOwner or
ComputeJobWorkflowOwner and real broker, with original repository/transport fixture seams.
They assert zero connection acquire / zero Job create or dispatch / no local download cache
write when unresolved policy denies.

For causal control, the exact fixed OpenScience `9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5`
broker, remote-operation-owner and Job-workflow source bytes were loaded in this isolated tree
while running only those three new propagation cases. All three also equal the shared 1ada
base bytes (`original-source-identities.json`). All **3 fail** because the original code attempts
approval broadcast (`original-propagation.json`, `.log`); the controlled broadcast throws to
avoid any waiting UI. Candidate source was restored exactly in finally, then the full green
suite above passed. The 130 pending entries in that causal run are intentional -t filtering,
not conditional platform skips or a passing original baseline.

This is an intentional new trusted-policy capability through original owners, not a claim
that original interactive approval was broken. Initial development logs retain an intermediate
test failure that exposed remember(deny) after the first lower-level guard; the final earlier
return avoids that path. They also retain a final test-only inference error corrected by an
explicit grant-union mock return type. No test exclusion or production type cast was added
to conceal these failures.
