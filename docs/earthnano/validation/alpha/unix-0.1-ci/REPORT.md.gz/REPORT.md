# 0.1 Alpha Unix CI scope

Branch `fix/alpha-unix-0.1`, HEAD `c392f338656eacb93d6392d9cc15592526c6d4d2`, clean. Based on exact remote PR18 e74 plus only previously reviewed generic A; no B/C/D/NSIS commits included.

The 0.1 caller selects macOS/Linux: 9 physical source jobs yield the original 16 logical reports (Linux baseline/candidate 4 shards each on one cohort runner; macOS baseline/candidate 4 jobs each). Native caller retains exactly Mac ARM64/Intel and Linux x64/ARM64. Windows jobs and runtime dependencies are absent from this caller; reusable recipes, packaging configuration and scripts are preserved.

Comparison now accepts explicit `--platforms darwin,linux`; the default remains strict darwin/linux/win32, including 8 baseline and 8 candidate Windows reports. Empty, unknown, repeated values, repeated flags and reports outside the chosen scope fail. Each selected platform retains complete original shards, pins, source/lock identities, actual environment matching, raw inventory/runtime/stage validation and exact failure/skip/removal regression rules. Baseline failures and skips remain explicit facts.

Verification: `node node_modules/vitest/vitest.mjs run scripts/ci/earthnano-ci.test.ts scripts/ci/earthnano-ci-topology.test.ts scripts/ci/classify-pr-changes.test.ts` passed 221/221. `npm run typecheck:compiled`, scoped ESLint, Prettier and git diff --check exited 0. Receipt/logs/JSON are here; `scope-byteproof.json` proves 8 original functions and 8 protected files unchanged. Reversing only scope selection restores the entire old compareReports function byte-for-byte.

Local Node v26.0.0 / macOS; this is not a hosted-CI or native acceptance claim. No Windows execution/build, no network/CI/push/paid operation occurred. The private durable-files package output was rebuilt from the e74 source before tests; shared artifacts were not rebuilt.
