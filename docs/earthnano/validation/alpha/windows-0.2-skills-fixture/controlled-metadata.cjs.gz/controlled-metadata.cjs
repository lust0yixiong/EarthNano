const fs = require('node:fs/promises')
const path = require('node:path')
const os = require('node:os')
const crypto = require('node:crypto')
const assert = require('node:assert/strict')
const vm = require('node:vm')
const repo = '/Users/yxmac_mini/Developer/EarthNano-worktrees/windows-02-source'
const evidence = '/Users/yxmac_mini/Developer/EarthNano-validation/windows-0.2-20261022/skills-prototype-fixture'
const esbuild = require(path.join(repo, 'node_modules/esbuild'))
const sourcePath = path.join(repo, 'packages/skills/src/user-skill-compatibility-index.ts')
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex')
async function runCase(source, label, after) {
  const storageRoot = await fs.mkdtemp(path.join(os.tmpdir(), 'skills-prototype-controlled-'))
  try {
    const sourceDir = path.join(storageRoot, 'skills/imported/prototype-file')
    const prototypePath = path.join(sourceDir, '__proto__')
    await fs.mkdir(sourceDir, { recursive: true })
    await fs.writeFile(path.join(sourceDir, 'SKILL.md'), '---\nname: prototype-file\n---\nBody\n')
    await fs.writeFile(prototypePath, 'before')
    const lstatObservations = []
    const controlledFs = { ...fs, lstat: async (target, options) => {
      const real = await fs.lstat(target, options)
      if (target !== prototypePath) return real
      assert.equal(options.bigint, true)
      lstatObservations.push({ realSize: String(real.size), realMtimeNs: String(real.mtimeNs), realCtimeNs: String(real.ctimeNs), presentedSize: String(real.size), presentedMtimeNs: '1000000000', presentedCtimeNs: '1000000000' })
      // Keep real content, size and mode. Only simulate two writes sharing a filesystem clock tick.
      return new Proxy(real, { get: (object, key) => key === 'mtimeNs' || key === 'ctimeNs' ? 1000000000n : Reflect.get(object, key) })
    }}
    const built = esbuild.buildSync({ stdin: { contents: source, resolveDir: path.dirname(sourcePath), sourcefile: sourcePath, loader: 'ts' }, bundle: true, write: false, platform: 'node', format: 'cjs', target: 'node24' }).outputFiles[0].text
    const module = { exports: {} }
    const customRequire = name => name === 'node:fs/promises' ? controlledFs : require(name)
    vm.runInNewContext(built, { module, exports: module.exports, require: customRequire, Buffer, process, console }, { filename: label + '.cjs' })
    const hashes = []
    const hashFile = async target => { hashes.push(path.basename(target)); return digest(await fs.readFile(target)) }
    const index = new module.exports.UserSkillCompatibilityIndex(storageRoot, { hashFile })
    const [before] = await index.scan([sourceDir])
    await fs.writeFile(prototypePath, after)
    const [result] = await index.scan([sourceDir])
    assert.equal(typeof before.compatibility, 'string')
    assert.equal(typeof result.compatibility, 'string')
    return { label, after, beforeBytes: 6, afterBytes: Buffer.byteLength(after), compatibilityChanged: before.compatibility !== result.compatibility, hashes, lstatObservations, realFileContent: await fs.readFile(prototypePath, 'utf8'), productionOrMutantSourceSha256: digest(Buffer.from(source)) }
  } finally { await fs.rm(storageRoot, { recursive: true, force: true }) }
}
;(async () => {
  const source = await fs.readFile(sourcePath, 'utf8')
  const needle = 'Object.create(null) as Record<string, T>'
  assert.equal(source.split(needle).length, 2)
  const mutant = source.replace(needle, '({}) as Record<string, T>')
  const old = await runCase(source, 'original-equal-size-same-tick', 'after!')
  const fixed = await runCase(source, 'fixed-different-size-same-tick', 'after!!')
  const negative = await runCase(mutant, 'prototype-dictionary-negative-control', 'after!!')
  assert.equal(old.compatibilityChanged, false, 'original assertion fails under equal metadata')
  assert.equal(old.hashes.filter(x => x === '__proto__').length, 1)
  assert.equal(fixed.compatibilityChanged, true, 'different size establishes the original cache invalidation precondition')
  assert.equal(fixed.hashes.filter(x => x === '__proto__').length, 2)
  assert.equal(negative.compatibilityChanged, false, 'the unchanged assertion still detects loss of prototype-like filename')
  assert.equal(negative.hashes.filter(x => x === '__proto__').length, 2)
  const receipt = { node: process.version, platform: process.platform, sourcePath, productionSha256: digest(Buffer.from(source)), cases: [old, fixed, negative], assertions: 'all controlled assertions passed', limitation: 'Timestamp alias is simulated for this controlled proof, not measured on the historical Windows runner. Production cache semantics are unchanged: equal size, mtimeNs, ctimeNs and executable flag reuse a cached hash. This one-byte fixture change does not fix that inherited cache limitation. The dictionary mutation exists only inside this external VM negative control.' }
  await fs.writeFile(path.join(evidence, 'controlled-metadata-receipt.json'), JSON.stringify(receipt, null, 2) + '\n')
  console.log(JSON.stringify({ node: process.version, cases: receipt.cases.map(({label,compatibilityChanged,hashes}) => ({label,compatibilityChanged,hashes})), assertions: receipt.assertions }, null, 2))
})().catch(error => { console.error(error); process.exitCode = 1 })
