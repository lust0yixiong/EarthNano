# EarthNano 0.1-Alpha Unix release runbook — read-only final902 review

Reviewed source: `902799ea69eac6a1eedb0750ce278aced04a3190`, clean `feat/alpha-final-integration` in `/Users/yxmac_mini/Developer/EarthNano-worktrees/alpha-public-sync`. Version is **`0.1.0-alpha.1`**, intended immutable asset tag **`v0.1.0-alpha.1`**. These commands are a future preparation recipe, **not executed** by this review. No network/API/CI, package download, build, signing, publication, or Windows operation occurred.

## Conclusion and current blocking boundary

The original helpers support an explicitly selected **`mac,linux`** Alpha, with full validation of six installer keys, two Mac update ZIPs, three feeds, and four native platform certification records. Their default remains all `mac,linux,win` (five native targets/seven installer keys); stable manifests reject a reduced scope. Do not invoke the default stable release/mirror workflows for this Alpha.

**Four successful final902 native jobs alone will not leave a complete downloadable release staging set.** The current native workflow uploads the eight package files, source/license/artifact digest manifest, database certification and builder debug YAML. It does not upload the generated updater feeds or blockmaps, and does not call the existing per-platform certification writer. A feed hash in `artifact-manifest.json` is not the feed bytes. Missing files must remain missing; an old c1e feed/cert/package cannot fill this gap. There is also no enabled Alpha publication entry in this source that binds the versioned release and the app's rolling `alpha` endpoint. This report supplies the existing local validation commands and identifies those materialization/publication gaps; it does not invent a publisher or silently regenerate metadata as if it were a retained original CI artifact.

## Exact file set and origin

Native caller `.github/workflows/earthnano-ci.yml:115` selects only the following four tuples. The reusable native workflow uses `npm run build`, original electron-builder `--publish never`, original package smoke, and original source manifest. No Windows job belongs to this release.

| Native artifact name | Actual required package basenames | Certification platform |
|---|---|---|
| `earthnano-unsigned-macos-26` | `EarthNano-0.1.0-alpha.1-mac-arm64.dmg`, `EarthNano-0.1.0-alpha.1-mac-arm64.zip` | `macos-arm64` |
| `earthnano-unsigned-macos-26-intel` | `EarthNano-0.1.0-alpha.1-mac-x64.dmg`, `EarthNano-0.1.0-alpha.1-mac-x64.zip` | `macos-x64` |
| `earthnano-unsigned-ubuntu-24.04` | `EarthNano-0.1.0-alpha.1-linux-x86_64.AppImage` (the existing manifest also accepts `-linux-x64.AppImage`), `EarthNano_0.1.0-alpha.1_amd64.deb` | `linux-x64` |
| `earthnano-unsigned-ubuntu-24.04-arm` | `EarthNano-0.1.0-alpha.1-linux-arm64.AppImage`, `EarthNano_0.1.0-alpha.1_arm64.deb` | `linux-arm64` |

The two DMGs plus four Linux files are the six website installer keys; the two ZIPs are mandatory Mac updater assets, not extra website keys. Use actual final902 filenames and bytes, not the historical sizes/hashes.

For each target, retain `earthnano-native-evidence-<os>` separately. Current upload includes `test-results/native-evidence/artifact-manifest.json`, `dist/database-migration-certification.json`, `dist/*builder*.yml`. Package artifacts expire after **3 days**, evidence after **14 days**. Archive final902 evidence promptly after success. The source manifest must say exact source SHA, `sourceDirty:false`, correct platform/architecture/version/product, original upstream pins, matching installed/expected/actual Electron, and streamed hashes matching the actual eight distributed files. Retain completed job logs for the corresponding package smoke and Linux DEB lifecycle/install checks; an artifact upload alone is not a pass.

Required additional material:

* Original per-architecture Mac feeds, retained separately as `arm64-mac.yml` and `x64-mac.yml`; the existing merger generates `alpha-mac.yml`, with both final ZIP entries.
* `alpha-linux.yml` containing final x64 AppImage **and** AMD64 DEB; `alpha-linux-arm64.yml` containing final ARM64 AppImage **and** ARM64 DEB. Each entry needs exact version, literal local filename, positive actual size and actual base64 SHA-512. Do not substitute sparse files/metadata-only validation.
* Four original-writer outputs: `certification-macos-arm64.json`, `certification-macos-x64.json`, `certification-linux-x64.json`, `certification-linux-arm64.json`, each tied to the correct real successful source/run and hashes. Retain each original database certificate under a platform-specific external name to prevent flattening collisions.
* Subsequent outputs: `SHA256SUMS.txt`, `RELEASE-CERTIFICATION.json`, and `version.json`. Original notes for `0.1.0-alpha.1` are not present in `release-notes/` in the reviewed source; manifest `NOTES` is optional, but final publication notes/unsigned limitations still need to be prepared by the release owner.

All chosen files must be from the same final source. Source comparison must separately complete for `darwin,linux` using the unchanged inventory/environment/failure/skip rules. Neither local 130 helper tests nor old native packages certify this final hosted source/native outcome.

## Why the missing feeds are a retention gap

Locked `app-builder-lib/out/publish/PublishManager.js:149–164` schedules `createUpdateInfoTasks` independently of `isPublish`; `--publish never` prevents uploads, not feed generation. `updateInfoBuilder.js` hashes final artifacts and combines entries. The historical c1e manifests explicitly list both Mac `dist/alpha-mac.yml`, `dist/alpha-linux.yml`, `dist/alpha-linux-arm64.yml`, and Mac blockmaps. See `historical-layout-only.json` for only those small extracted facts. None is evidence for final902 bytes.

Current `.github/workflows/earthnano-native.yml:104–128` retains only packages, certification JSON and builder YAML; `alpha*.yml` and `*.blockmap` are omitted. Original `.github/workflows/build.yml:672–711` already resolves the configured channel and renames each Mac feed to `<arch>-mac.yml`; the native lane does not call that step. Original `notarize-mac.yml:306–345` has a final-ZIP Mac metadata regeneration recipe; using it would create newly derived metadata, not recover lost CI feed bytes, and does not supply the Linux feeds. There is no standalone existing Linux Alpha feed-regeneration CLI in the reviewed scripts. Do not run notarization/build merely to pretend these feeds were retained, and do not enable the upstream full release pipeline to obtain them.

## Minimal preparation commands once real inputs exist

Run from the reviewed source with its existing locked dependencies and Node `24.22.0`; no installation/build is needed for these transforms. The following layout is an explicit staging convention, not a claim about already downloaded files:

```
$RELEASE_INPUT/<certification-platform>/          # two actual packages + original database certificate
$RELEASE_INPUT/feeds/arm64-mac.yml
$RELEASE_INPUT/feeds/x64-mac.yml
$RELEASE_INPUT/feeds/alpha-linux.yml
$RELEASE_INPUT/feeds/alpha-linux-arm64.yml
$RELEASE_STAGE/                                  # only selected final release files
```

1. Obtain the **successful final902** packages, source manifests and logs from the approved real run. Preserve the run identity and each target's job conclusion. A future read-only retrieval can use the existing `gh` CLI; every command must explicitly name the repository. Do not execute it until that run is known:

```bash
gh run view "$NATIVE_RUN_ID" -R lust0yixiong/EarthNano --json headSha,conclusion,jobs
gh run download "$NATIVE_RUN_ID" -R lust0yixiong/EarthNano --dir "$NATIVE_DOWNLOAD"
```

Require `headSha=902799ea69eac6a1eedb0750ce278aced04a3190`, all four actual Unix smoke jobs successful, and complete digest-verified files. If final release source changes, replace the pinned source only after obtaining that new source's own evidence; old902 CI cannot certify changed code. Organize four per-target directories without merging equal database certificate filenames. Current workflow download alone lacks feeds; stop this preparation at that boundary until their real bytes or an explicitly reviewed original-recipe materialization are supplied. No substitute recipe is introduced here.

2. Reuse the existing platform certification writer **only after the corresponding actual smoke and original database certificate have passed**. This writer records already established facts; its `--package-smoke passed` argument does not run smoke. In the original package-smoke workflow it runs immediately after smoke. If used externally as evidence backfill, retain that origin and the supporting original job log; do not present the generated JSON as CI-generated. Use real source/run variables, never placeholders in a published record:

```bash
export GITHUB_SHA=902799ea69eac6a1eedb0750ce278aced04a3190
export GITHUB_REPOSITORY=lust0yixiong/EarthNano
export GITHUB_REF="$ACTUAL_NATIVE_RUN_REF"
export GITHUB_RUN_ID="$NATIVE_RUN_ID"
export GITHUB_RUN_ATTEMPT="$ACTUAL_NATIVE_RUN_ATTEMPT"
for target in macos-arm64 macos-x64 linux-x64 linux-arm64; do
  node scripts/ci/release-certification-evidence.mjs write \
    --platform "$target" \
    --artifact-dir "$RELEASE_INPUT/$target" \
    --output "$RELEASE_INPUT/$target/certification-$target.json" \
    --electron-p0 not-applicable --visual-regression not-applicable \
    --package-smoke passed \
    --database-migration-certification "$RELEASE_INPUT/$target/database-migration-certification.json" \
    --authenticode not-applicable
done
```

The per-target artifact directory must contain only that target's original two distributables, not all eight. Each database certificate must have schema1, original migration ID `0001_runtime_schema_baseline`, checksum `e29d0483786c3ed2e1c9cd358369b254a54ccf54213931c5ef71a8fd4e161525`, actual SQLite version and passed fresh-install/legacy-adoption/reopen/special-path checks. Do not manufacture a database certificate from a log summary.

3. Stage the eight verified package files and four certification JSONs without overwrites; stage the four existing input feeds. Rename per-arch Mac feeds without changing bytes, as the original build does. Do not copy database JSONs to a single colliding basename. Merge using the existing Alpha-aware original merger:

```bash
node scripts/merge-mac-feed.mjs "$RELEASE_STAGE" --channel alpha
node scripts/ci/release-certification-evidence.mjs aggregate \
  --directory "$RELEASE_STAGE" \
  --output "$RELEASE_STAGE/RELEASE-CERTIFICATION.json" \
  --expected-sha 902799ea69eac6a1eedb0750ce278aced04a3190 \
  --platforms mac,linux
```

No `--require-signed-windows`/`--require-windows-update`; those contradict the selected scope and correctly throw. Aggregation still requires all four records, exact same SHA, original database checks, passed smoke and actual package digest matches. The aggregate is not a code signature or SLSA attestation.

4. Generate the original checksum list over the actual final packages (same `sha256sum` recipe used in `release.yml`, limited to the explicit selected families here). On a Linux preparation shell:

```bash
( cd "$RELEASE_STAGE"
  sha256sum -- *.dmg *.zip *.AppImage *.deb > SHA256SUMS.txt
  sha256sum --check --strict SHA256SUMS.txt
)
VERSION=0.1.0-alpha.1 UPDATE_CHANNEL=alpha \
ASSET_BASE_URL=https://github.com/lust0yixiong/EarthNano/releases/download/v0.1.0-alpha.1 \
RELEASE_DATE="$ACTUAL_RELEASE_ISO_DATE" NOTES="$ALPHA_RELEASE_NOTES" \
node scripts/generate-version-manifest.mjs \
  "$RELEASE_STAGE" "$RELEASE_STAGE/version.json" \
  --require-complete --platforms mac,linux
```

The two positional paths must precede flags. Do not use `--metadata-only`, `--backfill`, `requireComplete=false`, stable `CDN_BASE_URL`/`S3_PREFIX`, or directory-driven scope inference. Inspect the result's six exact download keys, immutable `v0.1.0-alpha.1` URLs and actual hashes/sizes. `release-artifact-validation.mjs` is reused by these scripts rather than a separate CLI: it rejects missing/empty/tampered files, wrong versions/architecture/feed hashes and scope-excluded filenames/references (including query/fragment/escaped spellings). No exclusion/filter can make a Windows file acceptable here.

Retain the three final feeds, both Mac intermediate inputs, eight packages, SHA256 list, manifest, aggregate, four source manifests, four certification records and original smoke/database evidence. Any signing/repacking/stapling that changes package bytes invalidates prior hashes/feed metadata/certification and requires the original final-byte refresh and smoke sequence.

## Minimal native metadata-retention change proposal (not implemented)

Parent confirmed the missing original publication materials are within 0.1 closeout scope. Keep the existing builder arguments, package/launch smoke commands, source/native matrices and all default full-five-target helper behavior unchanged. Add only a Unix evidence-writing step **after the existing actual smoke steps succeed**, before the package upload:

```yaml
- name: Record original Unix release certification evidence
  if: success() && (runner.os == 'macOS' || runner.os == 'Linux')
  shell: bash
  env:
    NATIVE_PLATFORM: ${{ inputs.platform }}
    NATIVE_ARCH: ${{ inputs.arch }}
  run: |
    set -euo pipefail
    case "$NATIVE_PLATFORM" in
      mac) certification_platform="macos-$NATIVE_ARCH" ;;
      linux) certification_platform="linux-$NATIVE_ARCH" ;;
      *) exit 1 ;;
    esac
    database_certification="dist/database-migration-certification-$certification_platform.json"
    mv dist/database-migration-certification.json "$database_certification"
    node scripts/ci/release-certification-evidence.mjs write \
      --platform "$certification_platform" \
      --artifact-dir dist \
      --output "dist/certification-$certification_platform.json" \
      --electron-p0 not-applicable \
      --visual-regression not-applicable \
      --package-smoke passed \
      --database-migration-certification "$database_certification" \
      --authenticode not-applicable
```

This is the original `.github/workflows/package-smoke.yml` writer invocation with Unix target mapping; it relies on the real runner's original `GITHUB_SHA`, `GITHUB_RUN_ID`, `GITHUB_RUN_ATTEMPT`, repository and ref. Missing/invalid database evidence or writer failure stays a failure. No signing claims, new checks, relaxed validation, synthetic success or additional Windows job is introduced.

Append these exact already-produced file families to the existing **successful package artifact upload**, retaining its eight original package globs and artifact names:

```yaml
dist/alpha-mac.yml
dist/alpha-linux.yml
dist/alpha-linux-arm64.yml
dist/*.blockmap
```

Only the applicable feed exists on each architecture runner. Both original Mac `alpha-mac.yml` files must remain in their separate per-runner artifact directories until copied to `arm64-mac.yml`/`x64-mac.yml` for the original merger; do not flatten them first. Existing `if: always()` evidence upload already includes `dist/*certification*.json`, which covers both new `certification-<target>.json` and renamed `database-migration-certification-<target>.json`; no extra upload action is required. Existing streamed source manifest then records these actual retained final files. Preserve explicit feed/smoke/expected-file assertions in any topology regression; a package-only upload success must not be described as proving its metadata complete.

If this proposal becomes a real commit, its source SHA supersedes902 for release certification and the runbook's SHA inputs must be updated to that exact new commit after its own real four-target CI succeeds. Do not rerun old902 merely for collection. Parent reports the current native Linux ARM64 job has terminally failed after full build at original beforePack `stageNodeRuntime` (`undici` stream terminated); original source helpers match fixed upstream byte-for-byte. That original failure remains a failure, not a retry success or final-ready package. The existing local job log was independently read: lines2201–2251 show full build success, native packaging, original resource staging and the Undici failure; line2262 reports command exit1. See `native-arm64-observed.json` for exact indexed failure lines/raw-log SHA and byte-identical fixed-upstream `build/prepare-desktop.cjs`/`build/stage-desktop-runtime.cjs` proof. This task has not queried remote state, inferred a new product defect or claimed a successful ARM64 package.

## Unsigned Alpha and actual publication boundary

The original selected-platform certification aggregator has **no Mac Developer ID/notarization requirement**; its signing flag is specifically optional Windows Authenticode. The Alpha manifest validates bytes/version/feed completeness, not developer trust. Therefore unsigned CI packages can satisfy this original Alpha helper path once the missing real inputs are provided. Mac `afterPack` still applies original deep **ad-hoc** signatures and the ordinary Mac smoke verifies `codesign --verify --deep --strict`; native `-c.mac.identity=null -c.dmg.sign=false` and absence of `--gatekeeper` mean **no Developer ID, no notarization, no primary signed-DMG/Gatekeeper acceptance** is established. Linux package checks do not establish a release-signing identity either. Describe the release as an **unsigned 0.1-Alpha preview**; helper success is not official stable/notarized distribution or tested update delivery.

Original stable `.github/workflows/release.yml` still uses its complete defaults, notarization, signed Windows certification, stable feeds and `prerelease:false`; original `mirror-to-website.yml`/`publish-release-assets.mjs` are stable S3 promotion and reject prerelease versions. Do not use them, enable upstream workflows, or create a `v*` tag expecting a safe Unix Alpha pipeline. This review does not query current remote workflow enablement.

The manifest intentionally targets immutable package URLs under `.../download/v0.1.0-alpha.1/`. Meanwhile `src/shared/app-config.ts:11,32` and `electron-builder.yml` embed `.../download/alpha/` for `version.json` and updater feeds. A version-tag upload alone therefore does not make in-app discovery available. Original feeds use literal package basenames, so their referenced files must resolve at the chosen served feed base; this is not established by locally passing hash checks. The existing original parser's strict local-filename checks must not be relaxed to improvise absolute URLs. The final902 source has **no explicit Alpha publisher command/entry** coordinating those endpoints. This is an actual remaining release-entry/asset-retention task for the release owner, not user permission speculation and not a new publishing design in this report. No `gh release create/upload`, tag push, workflow dispatch, S3 command, signing command or Windows action is executed or prescribed as if already supported. A draft/manual upload must not be called a working updater without separately proving the actual endpoints and exact referenced bytes.

## Evidence and completion status

* `source-review.json`: exact clean source and SHA-256 of reviewed original scripts/configuration; this review made no repository changes.
* `historical-layout-only.json`: small extracted old c1e top-level package/feed layout, with original manifest paths/hashes; **not final902 certification**.
* Earlier final integration verification: `/Users/yxmac_mini/Developer/EarthNano-validation/compute-fusion-20261021/release-integration-preflight/` contains the actual four-suite **130/130**, complete compiled types/lint/format/diff raw receipts at integrated981. This was helper verification, not final902 package installation or publication.
* The local terminal Linux ARM64 packaging failure is explicitly retained in `native-arm64-observed.json`. Other final902 hosted conclusions, final902 eight package bytes/smoke results, retained feed bytes, four per-platform release records/aggregate, final SHA/manifest, release notes and actual Alpha/version endpoint delivery are not certified here. No API was queried to replace missing evidence with assumptions.
