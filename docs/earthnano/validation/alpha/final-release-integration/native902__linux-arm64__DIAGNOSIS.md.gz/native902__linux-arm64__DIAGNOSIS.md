# Linux ARM64 native failure, source 902799

The actual job failed during native unsigned packaging after dependency setup, the full application build and Prisma target pruning succeeded. The original hook staged native components and rebuilt the backend, then its unchanged Node runtime fetch emitted `TypeError: terminated` from undici. There is no recorded HTTP status or inner cause; a specific TLS/proxy/server diagnosis is not proven.

The four relevant hook/downloader/pin files are byte-for-byte identical to fixed OpenScience9e18 and the earlier c1e source whose four Unix targets passed. No decoder, checksum, resource pin, app logic, timeout or retry policy was changed to obtain this result. The original Node archive hash remains required. This is a failed native attempt, not evidence of a validated Linux package.

The local CLI initially refused `gh run view --log` while the parent run was live. The terminal job's own REST log endpoint then returned the original323078-byte log; both fetch receipts are retained. This is an observation-method correction, not a restarted build.

A separate source-confirmed release-evidence gap was identified: original builder update feeds/blockmaps are omitted by the current upload globs, and the existing per-platform certification writer is not called. That concrete CI integration fix will be validated before dispatching a new exact-source native build. It does not fix or conceal this network failure, and no Windows work is involved.
