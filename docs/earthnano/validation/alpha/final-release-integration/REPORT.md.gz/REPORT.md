# Final release integration preflight

PR21 d89f3a8eb10e667aed1192cf589976af937ba8f9 relative to common base a554cde128bad308e0be3c6b4e3239fa53665049 adds explicit scope to the original manifest generator, release-artifact validator and certification aggregator, with targeted tests and archived evidence. All three helpers existed at fixed OpenScience9e18. No new publisher/engine, workflow, native packing/signing config or business/runtime changes.

Alpha must explicitly choose mac,linux and retain require-complete/real-byte checks:6installer keys,2Mac updateZIPs,3feeds,4certification targets. Unknown/empty/duplicate scopes fail; excluded packages/feeds/checksum and feed references reject rather than filter, including disguised query/fragment/escaped suffixes. Source SHA, migration, package smoke, actual hash/size/feed/version and applicable signing checks remain original. Windows-specific certification flags conflict with Unix scope. Original Mac merger is unchanged.

Omitted scope remains mac,linux,win(5native targets/7installer keys); stable rejects narrowing. Existing release/nightly/stable publisher workflow sources are unchanged, not enabled/invoked by this PR. They still contain dormant tag/manual/schedule definitions and future Windows targets; this no-API review does not independently re-query remote Actions disabled state. The0.1 earthnano-ci source matrix remains darwin/linux and native4Unix targets. No Windows job is added or executed here.

Archived evidence: original126pass then boundary130pass/0fail/0skip across alpha-release-feed, generate-version-manifest, release-publication-regressions and release-certification-evidence. All22gzip files match both raw and compressed SHA/length metadata. These are local helper fixtures, not final installers/native acceptance or a hosted CI pass; oldMac package receipt does not certify current binary/Compute head.

Before authorization alpha-public-sync was clean at0354708fcb1bd0c5f8b8245ffe5603fcff63af87 on preserved feat/alpha-compute-snapshots. No matching process cwd, worktree/common Git operation locks or in-progress merge/rebase/cherry-pick were observed. Agent work is elsewhere. It is suitable for an isolated final integration branch; preserve the original branch and do not reset/clean/retarget shared dependencies.

Earlier merge-tree preview for PR22old138179fdbeb352e3edddd280d0ed948c167d21c7 vs PR21 found only NEXT_TASKS.md conflict. It is not a current validation guarantee. Root subsequently authorized final integration from clean aea6998ad12b2b3461e954783ce945cfd2d1f69d, after final test-only changes. New branch feat/alpha-final-integration may merge d89, resolve only NEXT_TASKS by retaining valid current Compute outcomes/Unix release requirements/Windows0.2deferral, then run the original4release suites and applicable compiled types/lint without install/build. Unexpected dirty state/source conflict must stop, not reset. No push/PR/CI/publish/main merge is authorized.

Integration/check results will be appended below with raw external receipts; no old evidence is rewritten.

## Authorized local integration completed

Root final Compute commit `aea6998ad12b2b3461e954783ce945cfd2d1f69d` and PR21 `d89f3a8eb10e667aed1192cf589976af937ba8f9` are merged locally as `9815ac08e7707467c4830ea3b162c13bef2dfb6e` on `feat/alpha-final-integration`, clean. These are its exact two parents. Preserved original `feat/alpha-compute-snapshots` still points to0354708fcb1bd0c5f8b8245ffe5603fcff63af87. No push/PR/main merge/CI or publication was performed.

Actual merge confirmed only NEXT_TASKS.md conflict. Resolution keeps current Compute/R/binary progress and retained failures from the final Compute branch plus PR21's Unix release-preparation/evidence paragraph; Windows0.2deferral remains. Byteproof: all30 staged paths equal PR21's changed-path set; the other29files are exactly PR21 blobs. No business/workflow/default release change was invented during resolution.

Integrated original4release suites:130passed/0failed/0pending, process exit0. Full `npm run typecheck:compiled` exit0; full-repository `npm run lint` exit0 (cold cache, allowed to finish); targeted Prettier and staged git diff check0. Tests invoked Vitest directly, no pretest/install/build or shared dependency retarget/rebuild. Original helper tests remain local synthetic-byte/CLI tests, not native installation acceptance.

Raw results: integrated-release-tests.log/json, integrated-compiled-types.log, integrated-lint.log, integrated-format.log, merge.log. Exact commands/state/parents are in integration-receipt.json; integrated-byteproof.json and resolved-next-tasks.diff document the only manual resolution. No hosted CI result for this new local merge head is claimed. Any older queued run for138179cannot certify current source. Root must review the local merge before deciding later remote/CI/publication steps.
