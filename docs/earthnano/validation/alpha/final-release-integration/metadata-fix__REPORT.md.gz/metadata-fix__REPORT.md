# Native Unix release evidence retention fix

Commit `954776c3823f20e9ca6b5d5abcf2a485d905f775`, branch `fix/alpha-native-release-evidence`, based on final `902799ea69eac6a1eedb0750ce278aced04a3190`. Only `.github/workflows/earthnano-native.yml` and its existing `scripts/ci/earthnano-ci-topology.test.ts` changed. Independent alpha-ci-runtime worktree is clean; the b3 test branch remains preserved. No root/public-sync tree changes, push, CI dispatch, package build/install, dependency modification, external API/model/SSH or Windows operation occurred.

## Actual gap and minimum wiring

Original locked builder `--publish never` still generates updater metadata, but the old native upload patterns retained only distributable packages. Thus a successful upload could silently omit an existing alpha feed/blockmap. The native lane also never invoked the original release certification writer. These facts are the missing-retention boundary, not a reason to publish upstream or invent evidence for the already running old source.

After the existing actual Unix smoke steps, a new step with the ordinary default success condition and Unix-only runner condition:

1. Maps original mac-arm64/mac-x64 to macos-arm64/macos-x64; keeps linux-x64/linux-arm64.
2. Requires the actual nonempty builder feed: alpha-mac.yml, alpha-linux.yml or alpha-linux-arm64.yml. Missing or empty metadata stops before recording a pass, even if packages exist.
3. Renames the actual `dist/database-migration-certification.json` to its target-specific name, then invokes the unchanged original `release-certification-evidence.mjs write` CLI with that actual file and `--artifact-dir dist`.
4. Uses passed package smoke only because the step is after the applicable original smoke and has no always()/continue-on-error override. Electron P0, visual regression and authenticode are explicitly not-applicable. The original GITHUB_* environment is inherited; no source/run identity is synthesized in the workflow.

The existing package upload gains the three named alpha feed patterns and `dist/*.blockmap`. Blockmaps are retained when produced, without requiring nonexistent Linux sidecars. Existing per-OS artifact names remain separate: both Mac feeds keep their original alpha-mac.yml basename inside different architecture artifacts rather than overwriting each other in a flattened upload. Original always-on evidence already captures `dist/*certification*.json`, so it retains both platform and renamed database records without a new uploader.

This does not validate feed YAML contents with `test -s`; it adds a presence gate. Original final manifest/release feed/hash/size validation remains necessary. It neither enables publication nor backfills old 902 evidence. The revised source still needs its own four actual Unix native results before release evidence can be claimed.

## Red/green and original behavior

- `red.json` / `red.log`: nine new contract cases fail on the old workflow (missing writer, feed/sidecar omissions). The 24 original topology identities are filtered in this initial red run, not waived.
- `final-green.json` / `final-green.log`: **six suites, 205 passed, zero failed**, process exit 0. Includes topology, original release writer, CI Integrity, PR Gate, release workflows and runtime certification workflow.
- Four real Bash executions use the actual unchanged writer CLI against bounded filesystem fixtures. They verify the target mapping, actual DB-file rename and payload preservation, inherited run/source identity, exact artifact filenames and their SHA-256. Feed/sidecar coverage uses the workflow's actual upload globs. Fixture layouts follow retained original Mac DMG+ZIP blockmaps and Linux feed-only layouts; Linux succeeds without an external blockmap.
- Four rejection cases cover missing feed, empty feed, missing DB certificate and a DB certificate whose reopen check failed. No certification JSON may be written. Missing/empty feeds also leave the DB source file untouched, proving the presence gate runs first; invalid DB failure must come from the actual original writer validation.
- Step-order/condition assertions prevent recording before macOS/Linux smoke or switching to always(). Original per-target artifact names and existing always-on certification retention are asserted.
- Existing frozen native inventory is updated for the explicit added step/globs; removing only those separately exercised additions restores the original unchanged d4 inventory digest. Build, packaging, smoke, permissions, deadlines, pins and four Unix matrix behavior are not exempted.

One intermediate fixture-only attempt (`focused-green.*`) invoked the CLI through a scripts-directory symlink. The original import.meta/argv entry guard therefore correctly did not execute its main entry; explicit output-file assertions caught the missing cert and invalid-DB zero exit. The test harness was corrected to execute the real absolute CLI filename, preserving the actual workflow script and writer. That intermediate failure is not a production writer regression or a successful certification. Raw output remains retained. `focused-cli-green.*` and final-green record the actual writer execution.

## Other checks and limits

`final-types.log`: full compiled node + sandbox + web types, exit 0. `final-lint.log`: focused ESLint exit 0. `format.log`: both edited files pass Prettier. git diff --check passes. Local host Node is v26.0.0; the unchanged hosted workflow still pins 24.22.0, so these local results are not a substitute for new-source hosted CI.

`facts.json` records exact changed paths and hashes of protected files. Original caller/matrix, writer, macOS/Linux/DEB smoke, source manifest and electron-builder config are all byte-identical to 902799. No acceptance gate or helper implementation changed. `commit.patch` retains the reviewable patch; `manifest.json` binds the external evidence files.
