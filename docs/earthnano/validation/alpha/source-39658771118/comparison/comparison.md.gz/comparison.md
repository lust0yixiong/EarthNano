# EarthNano pinned source comparison

## darwin
- Outcome: no-new-regressions
- Baseline tests: 115595; candidate: 116940; added: 1345
- Baseline failures: 2; skips: 3756; candidate failures: 2; skips: 3765
- New test regressions: 0; stage regressions: 0
- Baseline failures/skips remain unresolved evidence, not full acceptance. Equal failing statuses do not prove an identical cause.

## linux
- Outcome: no-new-regressions
- Baseline tests: 115595; candidate: 116940; added: 1345
- Baseline failures: 30; skips: 3778; candidate failures: 29; skips: 3787
- New test regressions: 0; stage regressions: 0
- Baseline failures/skips remain unresolved evidence, not full acceptance. Equal failing statuses do not prove an identical cause.
