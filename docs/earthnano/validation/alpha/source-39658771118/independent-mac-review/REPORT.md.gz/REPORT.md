# Independent bdc complete Mac source review

No actionable P1/P2 found in this Mac sub-comparison. Existing run39658771118/attempt1 remains in_progress in the supplied snapshot; Linux job119426019699 is in_progress. This is not a completed full Unix/release gate. No application, test suite, CI, API or model was run by this reviewer.

## Original artifacts and complete inventories

Independently rehashed all8Mac archives plus the separate original Harness archive against their download receipts and all matching already archived API metadata(size/digest). Every extracted member matches its archive bytes. Baseline1–4 and candidate1–4 each have all7original files: source-report, raw Vitest, companion runtime, npm-ci/pretest/typecheck/tests logs.

Called only the archived original normalizeVitest and validateSourceExecution as pure JSON functions: all8passed; every normalized raw inventory exactly equals stored source-report.tests. Runtime unhandledErrors are0on all8, raw total/observer leaves/normalized count agree, and IDs are unique within each whole-side inventory. No custom status relaxation, inventory mutation, test compilation or comparator rewrite occurred. Independently decoded the existing official Contents API archive at exactbdc and computed both SHA25601043b008ac79ba48c29a6c633959d38c736871141d78589383bf2e4e0e75700 and original Gitblob e27f40a992857b029eb1307978908ea47ed3b6c0. All36606bytes equal the archived helper actually executed; original-comparer-byteproof.json corroborates this. The archived candidate merge API also lists only builder and the new resource test as changed versus4a. Local post-processing Node26.0.0 only parses/normalizes original JSON; actual hosted test Node is24.22.0.

All8original GHA environments match Nodev24.22.0/arm64/Electron43.7.5/image macos15:20260907.0337.1/profile original-full. Baseline lock3466bdf3...84ebd and candidate lock0eeb2202...e77 remain distinct and each internally consistent. npm-ci/pretest/typecheck all0; baseline1/candidate1 tests1reflect the2assertion failures, other tests stages0. Runtime failed reason on those2shards is consistent with failed assertions and is not a hidden global error.

All baseline source pins are OpenScience9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5; Harness1cfe254e8d25b15f37048c3730134686abe60335/treeedc756a4d03a2826a248115482084a176e60e751. Actual candidate reports identify328cb5938913531325e6d0ae52244fca842dfb12. Existing candidate-merge-commit.json proves parents4a31... andbdc024..., tree25d834714406b65aff26b291a790e5c1749f94b1=bdc. Distinct candidate merge identity is retained, not rewritten to headbdc.

## Comparison, actual shared failures and every skip

The root's original bdc helper command `compare --platforms darwin --reports mac-raw --out mac-comparison` exited0; its unchanged output says no-new-regressions,0new test and0stage regressions. Independently counted raw totals115595baseline→116940candidate(+1345), failures2→2, skips3756→3765. This is not all assertions passed.

Both failed IDs are the writer.test.ts physical backend boundary cases installed and 安装 package. Each side's actual failureMessages explicitly says ENOENT opening the copied fixture's resources/backend/node_modules/@aipoch/pdf-translation/resources/worker.mjs. Each is therefore supported by the same concrete missing-resource signature, rather than equality of failed status alone. Random tmp directory names and baseline/candidate checkout paths differ; exact first lines and untouched raw are retained.

Compared the complete skip ID sets: all3756original skips are retained, none removed or promoted to pass; only9new skip IDs exist. They are exactly the same9IDs as old4a:7explicit opt-in DeepSeek/live cases plus2R/R-binary scientific cases. Candidate's entire3765skip ID set equals old4a candidate. These are unresolved skip observations, not hosted execution proof. Sorted whole-inventory hashes and every added skip ID are in facts.json.

Compared every old4a candidate ID/status against newbdc: all116939old IDs remain with identical status, no removed ID or status change. The only new ID is:

`scripts/packaged-harness-resources.test.ts :: loads the original method bytes from the actual packaged Node owner resource layout :: 0` — passed.

Thus+1345versus baseline is the previous+1344plus exactly the packaging-path regression guard, not a new test grouping or changed skip rule.

## Separate Harness original comparison

The H2archive belongs to the independent Linux x86_64/Python3.12.10 job, not execution on the Mac shard. Its pin/license identities match on both sides; baseline scope is fixed original Harness commit/tree, candidate scope vendor/harness2 at328cb.../bdc tree. Original5tests and candidate77all pass,0collection errors,0failures/skips/regressions; every original test ID remains passed. The72added cases are retained; no general algorithm equivalence or live-model claim beyond that actual test evidence is made.

## Boundaries

Only the observed Mac eight-shard comparison and separate H2result are concluded. Do not substitute completed old4a Unix evidence for livebdc Linux119426019699/fullsource39658771118, nor treat Mac collection job success alone as test success. Fullsource, assets, review/merge and actual release remain separate original gates; Windows remains deferred0.2. No new gate or rerun is proposed.

One read-only Git-object identity command with lazy fetch disabled failed128 because the existing shared CloudStorage .git pack reported too short. No repair/network retrieval or further Git-object access was performed. It is a local repository-object availability issue, not a hosted source failure. The existing official exactbdc Contents API bytes/hash/Gitblob proof and original archived candidate merge JSON supply the identities above; the failed local command is not recorded as a successful byte comparison. Reports/facts/receipt alone were written in this independent-mac-review directory; all stage/raw/repository bytes remain untouched.
