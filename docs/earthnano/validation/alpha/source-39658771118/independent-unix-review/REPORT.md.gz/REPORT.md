# Independent complete bdc Unix source comparison review

No actionable P1/P2 found. Original run39658771118, attempt1, headbdc0246383a25990030854f4c2fa100895f29ea6 is now actual completed/success. The original hosted full comparison covers darwin and linux and reports0new test regressions and0stage regressions on both. This is no-new-regressions, not an all-tests-pass claim.

| Platform | Baseline→candidate tests | Failures | Skips | Added |
| --- | --- | --- | --- | --- |
| Darwin ARM64 |115595→116940|2→2|3756→3765|1345|
| Linux x64 |115595→116940|30→29|3778→3787|1345|

## Complete raw inventories and identity

Linux baseline1–4/candidate1–4 each retain raw Vitest, companion runtime, normalized source-report and all4stage logs. On the fresh Developer clone, the original bdc normalizeVitest and validateSourceExecution pure functions were called without changing them:8/8passed, every normalized raw inventory exactly equals stored tests. This helper's file bytes match the previously archived official Contents API bytes/SHA01043b008ac79ba48c29a6c633959d38c736871141d78589383bf2e4e0e75700. All8runtime unhandledErrors arrays are empty; raw total/observer leaves/normalized totals agree and whole-side IDs are unique.

Hosted environment is consistently Nodev24.22.0/x64/Electron43.7.5/imageubuntu24:20261012.334.1/profileoriginal-full. Baseline lock3466bdf3...84ebd and candidate lock0eeb2202...e77 remain distinct and internally consistent. npm-ci/pretest/typecheck all0; tests1on baseline/candidate1,2,4and0on3matches retained assertion failures. Failed runtime reason on assertion-failing shards does not hide a global error.

Baselines identify fixed OpenScience9e18c7d3c143a9dba49c7a586ad6cac8096f6dd5, Harness1cfe254e8d25b15f37048c3730134686abe60335/treeedc756a4d03a2826a248115482084a176e60e751. Actual candidate checkout328cb5938913531325e6d0ae52244fca842dfb12 differs from productheadbdc; the existing official merge record proves parents4a+bdc and tree25d834714406b65aff26b291a790e5c1749f94b1=bdc. This distinction is retained.

Independently rehashed the new Linux artifact12385190878(17,848,505B,SHA725c18992fc68d6108ff741f882534b36b74731f2a92d07f27c6a148179b42ac) and full comparison artifact12384482838(249,347B,SHA4afdf27c309f2565781eb999ef92a7760124e53950ad10df5904ee6689965aee) against archived API metadata/receipts. All57Linux and2comparison extracted members match original ZIP bytes and receipt file sizes/hashes. Previously independently verified Mac/H2archives remain untouched; final Darwin comparison object exactly equals the reviewed earlier Mac object.

## Linux30→29 failures: actual messages

All29candidate failures also fail in baseline. Reading their actual messages gives26pairs explicitly reporting missing/unavailable bubblewrap(bwrap),2pairs explicitly ENOENT opening the copied PDF worker.mjs fixture resource, and1Plan-context pair with only the same elided exitCode/stderr matching AssertionError. No underlying cause is proven for that1Plan case. PDF temporary directory and baseline/candidate checkout paths differ; raw first lines are preserved. The26bwrap messages are source-cohort prerequisite limitations, not proof of a Linux package capability loss; original.deb dependency/native installation evidence stays separate. No new release gate or upstream failure sweep is proposed.

The30thbaseline-only ID is:

`src/main/session-package/browser-import.test.ts :: releases an expired receipt after import and admits another transfer without restarting :: 0`

Its new baseline raw error is exactly `TypeError: fetch failed`, duration76.7ms, with no cause/stack. Same-run candidate passes108.4ms; old4a baseline and candidate both passed this exact ID. This is the sole baseline status change from the prior29-failure run; candidate's common IDs have no changed statuses. The existing fixture uses an idleMs40 local127.0.0.1 HTTP import/expiry/next-transfer sequence. That source context does not prove which request failed or that a timer/network race caused it. Preserve the new baseline failure as unresolved; do not call it repaired, waived, or a product improvement merely because candidate passes. The original comparison legitimately reports no new candidate regression under its unchanged rules.

## Skips, new guard and Mac/H2 merge

Every original Linux3778skip ID is retained, none removed; exactly9new skips remain. The candidate's complete3787skip set equals old4a, and the9added IDs exactly match the already reviewed Mac9:7explicit opt-in DeepSeek/live cases and2R/R-binary scientific cases. They remain skips, not passes or hosted execution claims. Darwin3756→3765skips and its2actual shared PDFworker ENOENT failures are retained from the earlier independent Mac review.

Compared all old4a Linux candidate IDs/statuses:116939old IDs remain unchanged, and the sole new passed ID is scripts/packaged-harness-resources.test.ts / loads the original method bytes from the actual packaged Node owner resource layout. Thus+1345is exactly the former+1344plus the narrow resource regression guard.

The separate original H2job remains Linuxx86_64/Python3.12.10 with matched pins/license/interpreter, original5and candidate77allpassed,0collection errors/failures/skips/regressions; all original5IDs remain passed. This is independent method test evidence, not Mac H2execution or a fresh live-model/scientific improvement claim.

## Conclusion boundary

The current bdc full Unix source no-new-regressions gate is supported by its own completed official run and original comparison, rather than substituted old4a evidence or green collection jobs alone. Inherited failures and every skip remain explicit. This does not by itself prove final complete release assets, draft publication, merge/tag, signing/notarization or a public release; those remain separate original processes. Existing actual bdc native/science evidence remains separately scoped. Windows stays deferred0.2.

Only this external independent-unix-review directory was written. No source/stage/raw/repository mutation, old CloudStorage Git access, Git-object command, dependency install/rebuild, App/test/CI/API/model/native execution or new verifier/rule was introduced. Pure original JSON normalization used local Node26only for parsing; hosted test/compiler Node24.22.0is unchanged.
