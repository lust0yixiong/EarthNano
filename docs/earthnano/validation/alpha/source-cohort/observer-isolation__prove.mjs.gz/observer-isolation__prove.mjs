import { writeFileSync, readFileSync, existsSync, mkdirSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
const evidence=dirname(fileURLToPath(import.meta.url))
const repository='/Users/yxmac_mini/Developer/EarthNano-worktrees/alpha-ci-ownership'
const results=[]
for (const kind of ['old','new']) {
  const observerRoot=join(evidence,kind), root=join(evidence,`cases-${kind}`), reporter=join(observerRoot,'observer.mjs')
  mkdirSync(root,{recursive:true})
  const env={...process.env,NODE_PATH:'',EARTHNANO_CI_RUNTIME_REPORT:join(root,'runtime.json')}
  const load=spawnSync(process.execPath,['--input-type=module','-e',`await import(${JSON.stringify(reporter)})`],{cwd:root,env,encoding:'utf8'})
  writeFileSync(join(root,'native-load.log'),load.stdout+load.stderr)
  writeFileSync(join(root,'vitest.config.mjs'),`export default {test:{include:['case.test.mjs'],maxWorkers:1}}`)
  writeFileSync(join(root,'case.test.mjs'),`import {describe,it,expect} from ${JSON.stringify(join(repository,'node_modules/vitest/dist/index.js'))};describe.skip('outer original skip',()=>describe.skipIf(true)('inner',()=>{it('a',()=>expect(1).toBe(1));it('b',()=>expect(1).toBe(1))}));it('ordinary pass',()=>expect(1).toBe(1))`)
  const run=spawnSync(process.execPath,[join(repository,'node_modules/vitest/vitest.mjs'),'run','--root',root,'--config',join(root,'vitest.config.mjs'),'--reporter=json',`--reporter=${reporter}`,`--outputFile=${join(root,'vitest.json')}`],{cwd:root,env,encoding:'utf8',timeout:15000})
  writeFileSync(join(root,'vitest.log'),run.stdout+run.stderr)
  results.push({kind,root,observerRoot,node:process.version,observerLocalNodeModules:existsSync(join(observerRoot,'node_modules')),nativeLoadStatus:load.status,nativeLoadError:load.stderr,vitestStatus:run.status,rawExists:existsSync(join(root,'vitest.json')),runtimeExists:existsSync(join(root,'runtime.json'))})
}
writeFileSync(join(evidence,'receipt.json'),JSON.stringify(results,null,2)+'\n')
console.log(JSON.stringify(results,null,2))
